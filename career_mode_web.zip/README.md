# Career Mode - FC27 Style Football Manager Game

A Football Manager-style career mode game built with **Godot 4 (GDScript)** featuring:
- Full FM-style simulation depth (player attributes, tactics, training, scouting, finances, youth academy, contracts)
- Text/2D match simulation with commentary feed and tactical decisions
- Single-player career mode managing a club through multiple seasons

## Features Implemented (Phase 1: Foundation)

### Core Data Models
- **PlayerData.gd** - Complete FM-style attributes (Technical, Mental, Physical, Goalkeeping, Hidden), CA/PA system, contracts, development
- **TeamData.gd** - Squad, staff, finances, stadium, tactics, board expectations, rivalries
- **CompetitionData.gd** - Leagues, cups, continental competitions with rules and scheduling
- **StaffData.gd** - Coaches, scouts, medical staff with coaching attributes
- **Enums.gd** - All game enums (Positions, Roles, Mentalities, Injuries, etc.)

### Systems
- **Database.gd** - Singleton managing all game data with JSON persistence, procedural generation
- **GameState.gd** - Singleton for current career state, date management, UI navigation
- **SaveSystem.gd** - Save/load with multiple slots, autosave, metadata
- **Simulation.gd** - Match simulation, season simulation, player development, youth intake, contracts

### UI Framework
- **ScreenManager.gd** - Screen navigation, history, dialogs, notifications
- **Sidebar** - Navigation between all game screens
- **TopBar** - Club info, date, finances, game speed controls
- **OverviewScreen** - Dashboard with next match, league table, squad overview, news
- **SquadScreen** - Player list with filters, search, sort, grid/list views, detail panel
- **PlayerCard** - Reusable component showing key attributes, condition bars, contract info
- **NewCareerScreen** - Manager creation and club selection
- **LoadGameScreen** - Save slot management with delete/load
- **NotificationToast** - Non-blocking notifications
- **ConfirmationDialog** - Modal confirmations

## Project Structure

```
career_mode/
├── project.godot
├── README.md
├── resources/
│   ├── icon.png
│   └── database/
├── scenes/
│   ├── main/
│   │   ├── Main.tscn
│   │   └── Main.gd
│   ├── ui/
│   │   ├── layout/
│   │   │   ├── Sidebar.tscn / Sidebar.gd
│   │   │   └── TopBar.tscn / TopBar.gd
│   │   ├── screens/
│   │   │   ├── OverviewScreen.tscn / OverviewScreen.gd
│   │   │   ├── SquadScreen.tscn / SquadScreen.gd
│   │   │   ├── NewCareerScreen.tscn / NewCareerScreen.gd
│   │   │   └── LoadGameScreen.tscn / LoadGameScreen.gd
│   │   └── components/
│   │       ├── PlayerCard.tscn / PlayerCard.gd
│   │       ├── NotificationToast.tscn / NotificationToast.gd
│   │       └── ConfirmationDialog.tscn / ConfirmationDialog.gd
│   └── match/
├── scripts/
│   ├── core/
│   │   ├── Database.gd
│   │   ├── GameState.gd
│   │   ├── SaveSystem.gd
│   │   └── Simulation.gd
│   ├── data/
│   │   ├── Enums.gd
│   │   ├── PlayerData.gd
│   │   ├── TeamData.gd
│   │   ├── CompetitionData.gd
│   │   └── StaffData.gd
│   ├── systems/
│   └── ui/
│       ├── ScreenManager.gd
│       └── layout/
│           ├── Sidebar.gd
│           └── TopBar.gd
└── tests/
```

## Requirements

- **Godot 4.3+** (4.4 recommended)
- Windows, macOS, or Linux

## Installation & Running

1. **Install Godot 4.3+** from [godotengine.org](https://godotengine.org/download)

2. **Open the project:**
   - Launch Godot
   - Click "Import" and select `career_mode/project.godot`
   - Or run from command line:
     ```bash
     godot --path path/to/career_mode
     ```

3. **Run the game:**
   - Press F5 in Godot editor
   - Or: `godot --path path/to/career_mode`

## Controls

| Key | Action |
|-----|--------|
| F1-F12 | Quick screen access (Overview, Squad, Tactics, etc.) |
| Space | Pause/Resume game time |
| Escape | Go back to previous screen |
| Click | Navigate UI, select players |

## Gameplay Flow

1. **New Career** → Enter manager name, nationality, DOB → Select club → Start
2. **Overview** → View next match, league table, squad summary, news
3. **Squad** → Filter/search/sort players → Click for details → Manage contracts, training
4. **Simulate Match** → From Overview, click "Simulate Match" → View commentary & result
5. **Advance Time** → Use speed controls (▶ ▶▶ ▶▶▶) to progress days/weeks

## Next Development Phases

- **Phase 2**: Tactics screen (formation builder, roles, instructions)
- **Phase 3**: Match engine (detailed commentary, 2D pitch view, tactical changes)
- **Phase 4**: Transfer system (market, negotiations, contracts)
- **Phase 5**: Training & development (schedules, youth academy)
- **Phase 6**: Finances & board management
- **Phase 7**: Staff management, scouting, press conferences

## Architecture Notes

- **Resources** for static data (PlayerData, TeamData, etc.) - loaded once, referenced by ID
- **Singletons** (autoload) for global systems (Database, GameState, Simulation, SaveSystem, ScreenManager)
- **Scene-per-screen** UI architecture with ScreenManager handling navigation
- **JSON persistence** for saves and database
- **Procedural generation** for players, teams, staff when no JSON data exists
- **Signal-based** communication between systems

## License

MIT License - Feel free to use and modify for your own projects.