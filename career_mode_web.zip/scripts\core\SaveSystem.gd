extends Node
class_name SaveSystem

# Singleton
static var instance: SaveSystem = null

# =============================================================================
# CONSTANTS
# =============================================================================
const SAVE_VERSION = 1
const SAVE_SLOTS = 10
const AUTOSAVE_SLOT = "autosave"

# =============================================================================
# INITIALIZATION
# =============================================================================

func _ready():
	instance = self
	_ensure_save_dir()

func _ensure_save_dir():
	var dir = DirAccess.open("user://saves")
	if not dir:
		DirAccess.make_dir_recursive_absolute("user://saves")

# =============================================================================
# SAVE OPERATIONS
# =============================================================================

func save_game(slot_name: String, game_state: Dictionary) -> bool:
	var save_data = _prepare_save_data(game_state)
	var file_path = "user://saves/%s.save" % slot_name

	var file = FileAccess.open(file_path, FileAccess.WRITE)
	if not file:
		push_error("Failed to open save file for writing: %s" % file_path)
		return false

	# Compress if large
	var json_string = JSON.stringify(save_data)
	if json_string.length() > 100000:
		# Could add compression here
		pass

	file.store_string(json_string)
	file.close()

	# Update slot metadata
	_update_slot_metadata(slot_name, save_data)

	print("Game saved to slot: %s" % slot_name)
	return true

func save_autosave(game_state: Dictionary) -> bool:
	return save_game(AUTOSAVE_SLOT, game_state)

func _prepare_save_data(game_state: Dictionary) -> Dictionary:
	var save_data = {
		"version": SAVE_VERSION,
		"timestamp": Time.get_unix_time_from_system(),
		"date_string": Time.get_datetime_string_from_system(),
		"game_state": game_state,
	}
	return save_data

func _update_slot_metadata(slot_name: String, save_data: Dictionary):
	var meta_file = "user://saves/slots_meta.json"
	var meta = {}

	var file = FileAccess.open(meta_file, FileAccess.READ)
	if file:
		var parsed = JSON.parse_string(file.get_as_text())
		if parsed.error == OK:
			meta = parsed.value
		file.close()

	meta[slot_name] = {
		"timestamp": save_data.timestamp,
		"date_string": save_data.date_string,
		"season": save_data.game_state.current_season,
		"club": save_data.game_state.current_club_id,
		"manager_name": save_data.game_state.manager_name,
	}

	file = FileAccess.open(meta_file, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(meta, "\t"))
		file.close()

# =============================================================================
# LOAD OPERATIONS
# =============================================================================

func load_game(slot_name: String) -> Dictionary:
	var file_path = "user://saves/%s.save" % slot_name

	var file = FileAccess.open(file_path, FileAccess.READ)
	if not file:
		push_error("Failed to open save file: %s" % file_path)
		return {}

	var json_string = file.get_as_text()
	file.close()

	var parsed = JSON.parse_string(json_string)
	if parsed.error != OK:
		push_error("Failed to parse save file: %s" % parsed.error_string)
		return {}

	var save_data = parsed.value

	# Version check and migration
	if save_data.version != SAVE_VERSION:
		save_data = _migrate_save(save_data)

	return save_data.game_state

func load_autosave() -> Dictionary:
	return load_game(AUTOSAVE_SLOT)

func _migrate_save(save_data: Dictionary) -> Dictionary:
	# Handle save version migrations
	if save_data.version < SAVE_VERSION:
		print("Migrating save from version %d to %d" % [save_data.version, SAVE_VERSION])
		# Add migration logic here for future versions
		save_data.version = SAVE_VERSION
	return save_data

# =============================================================================
# SLOT MANAGEMENT
# =============================================================================

func get_save_slots() -> Array[Dictionary]:
	var meta_file = "user://saves/slots_meta.json"
	var file = FileAccess.open(meta_file, FileAccess.READ)
	if not file:
		return []

	var parsed = JSON.parse_string(file.get_as_text())
	file.close()

	if parsed.error != OK:
		return []

	var slots = []
	for slot_name, info in parsed.value:
		slots.append({
			"name": slot_name,
			"timestamp": info.timestamp,
			"date_string": info.date_string,
			"season": info.season,
			"club": info.club,
			"manager_name": info.manager_name,
		})

	# Sort by timestamp descending (newest first)
	slots.sort_custom(self, "_compare_slot_timestamp")
	return slots

func _compare_slot_timestamp(a: Dictionary, b: Dictionary) -> int:
	return b.timestamp - a.timestamp

func delete_save(slot_name: String) -> bool:
	var file_path = "user://saves/%s.save" % slot_name
	if FileAccess.file_exists(file_path):
		DirAccess.remove_absolute(file_path)

	# Update metadata
	var meta_file = "user://saves/slots_meta.json"
	var file = FileAccess.open(meta_file, FileAccess.READ)
	if file:
		var parsed = JSON.parse_string(file.get_as_text())
		file.close()
		if parsed.error == OK:
			var meta = parsed.value
			meta.erase(slot_name)
			file = FileAccess.open(meta_file, FileAccess.WRITE)
			if file:
				file.store_string(JSON.stringify(meta, "\t"))
				file.close()

	return true

func slot_exists(slot_name: String) -> bool:
	return FileAccess.file_exists("user://saves/%s.save" % slot_name)

# =============================================================================
# EXPORT/IMPORT
# =============================================================================

func export_save(slot_name: String, export_path: String) -> bool:
	var file_path = "user://saves/%s.save" % slot_name
	if not FileAccess.file_exists(file_path):
		return false

	# Copy file
	var source = FileAccess.open(file_path, FileAccess.READ)
	if not source:
		return false

	var content = source.get_as_text()
	source.close()

	var dest = FileAccess.open(export_path, FileAccess.WRITE)
	if not dest:
		return false

	dest.store_string(content)
	dest.close()
	return true

func import_save(import_path: String, slot_name: String) -> bool:
	if not FileAccess.file_exists(import_path):
		return false

	var source = FileAccess.open(import_path, FileAccess.READ)
	if not source:
		return false

	var content = source.get_as_text()
	source.close()

	# Validate
	var parsed = JSON.parse_string(content)
	if parsed.error != OK:
		return false

	var dest_path = "user://saves/%s.save" % slot_name
	var dest = FileAccess.open(dest_path, FileAccess.WRITE)
	if not dest:
		return false

	dest.store_string(content)
	dest.close()

	# Update metadata
	var save_data = parsed.value
	_update_slot_metadata(slot_name, save_data)

	return true

# =============================================================================
# UTILITY
# =============================================================================

func get_save_info(slot_name: String) -> Dictionary:
	var meta_file = "user://saves/slots_meta.json"
	var file = FileAccess.open(meta_file, FileAccess.READ)
	if not file:
		return {}

	var parsed = JSON.parse_string(file.get_as_text())
	file.close()

	if parsed.error != OK:
		return {}

	return parsed.value.get(slot_name, {})

func format_save_date(timestamp: int) -> String:
	var dt = Time.get_datetime_dict_from_unix_time(timestamp)
	return "%04d-%02d-%02d %02d:%02d" % [dt.year, dt.month, dt.day, dt.hour, dt.minute]

# =============================================================================
# GAME STATE SERIALIZATION HELPERS
# =============================================================================

# These are static helper functions to serialize/deserialize game objects

static func serialize_player(player: PlayerData) -> Dictionary:
	return player.to_dict()

static func deserialize_player(data: Dictionary) -> PlayerData:
	var player = PlayerData.new()
	player.from_dict(data)
	return player

static func serialize_team(team: TeamData) -> Dictionary:
	return team.to_dict()

static func deserialize_team(data: Dictionary) -> TeamData:
	var team = TeamData.new()
	team.from_dict(data)
	return team

static func serialize_competition(comp: CompetitionData) -> Dictionary:
	return comp.to_dict()

static func deserialize_competition(data: Dictionary) -> CompetitionData:
	var comp = CompetitionData.new()
	comp.from_dict(data)
	return comp

static func serialize_staff(staff: StaffData) -> Dictionary:
	return staff.to_dict()

static func deserialize_staff(data: Dictionary) -> StaffData:
	var s = StaffData.new()
	s.from_dict(data)
	return s

# Serialize match events
static func serialize_match_events(events: Array[Dictionary]) -> Array[Dictionary]:
	return events  # Already dictionaries

# Serialize fixtures/results
static func serialize_fixtures(fixtures: Array[Dictionary]) -> Array[Dictionary]:
	return fixtures

# Serialize standings
static func serialize_standings(standings: Array[Dictionary]) -> Array[Dictionary]:
	return standings