extends PanelContainer
class_name NotificationToast

# =============================================================================
# UI REFERENCES
# =============================================================================

@onready var icon: Label = $HBoxContainer/Icon
@onready var text_label: Label = $HBoxContainer/Text
@onready var close_button: Button = $HBoxContainer/CloseButton

# =============================================================================
# STATE
# =============================================================================

var duration: float = 3.0
var timer: SceneTreeTimer = null

# =============================================================================
# SETUP
# =============================================================================

func setup(text: String, type: String = "info", duration_sec: float = 3.0):
	text_label.text = text
	duration = duration_sec

	# Set color based on type
	match type:
		"success":
			icon.text = "✓"
			add_theme_color_override("bg_color", Color(0.1, 0.3, 0.1, 0.95))
			icon.add_theme_color_override("font_color", Color(0.4, 0.8, 0.4))
		"warning":
			icon.text = "⚠"
			add_theme_color_override("bg_color", Color(0.3, 0.25, 0.05, 0.95))
			icon.add_theme_color_override("font_color", Color(0.9, 0.7, 0.2))
		"error":
			icon.text = "✕"
			add_theme_color_override("bg_color", Color(0.3, 0.1, 0.1, 0.95))
			icon.add_theme_color_override("font_color", Color(0.9, 0.3, 0.3))
		_: # info
			icon.text = "ℹ"
			add_theme_color_override("bg_color", Color(0.1, 0.1, 0.2, 0.95))
			icon.add_theme_color_override("font_color", Color(0.4, 0.7, 0.9))

	# Start auto-close timer
	timer = get_tree().create_timer(duration)
	timer.timeout.connect(_auto_close)

	close_button.pressed.connect(_auto_close)

	# Animate in
	modulate = Color(1, 1, 1, 0)
	var tween = create_tween()
	tween.tween_property(self, "modulate:a", 1.0, 0.2).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)

func _auto_close():
	if timer:
		timer.stop()

	var tween = create_tween()
	tween.tween_property(self, "modulate:a", 0.0, 0.2).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tween.finished.connect(queue_free)