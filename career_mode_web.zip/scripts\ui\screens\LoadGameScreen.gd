extends PanelContainer
class_name LoadGameScreen

# =============================================================================
# SIGNALS
# =============================================================================
signal game_loaded(game_state: Dictionary)

# =============================================================================
# UI REFERENCES
# =============================================================================

@onready var save_list_container: VBoxContainer = $SaveList/SaveListContainer
@onready var new_career_button: Button = $ButtonRow/NewCareerButton
@onready var cancel_button: Button = $ButtonRow/CancelButton

# =============================================================================
# INITIALIZATION
# =============================================================================

func _ready():
	_refresh_save_list()
	_connect_signals()

func _connect_signals():
	new_career_button.pressed.connect(_on_new_career)
	cancel_button.pressed.connect(_on_cancel)

func _refresh_save_list():
	# Clear existing
	for child in save_list_container.get_children():
		child.queue_free()

	var slots = SaveSystem.instance.get_save_slots()

	if slots.is_empty():
		var empty = Label.new()
		empty.text = "No saved games found"
		empty.horizontal_alignment = 1
		empty.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
		save_list_container.add_child(empty)
		return

	for slot in slots:
		var item = _create_save_item(slot)
		save_list_container.add_child(item)

func _create_save_item(slot: Dictionary) -> Control:
	var button = Button.new()
	button.custom_minimum_size = Vector2(0, 80)
	button.button_group = "save_selection"
	button.focus_mode = Control.FOCUS_ALL
	button.pressed.connect(_on_save_selected.bind(slot.name))

	var hbox = HBoxContainer.new()
	hbox.theme_override_constants.separation = 15
	button.add_child(hbox)

	# Save info
	var info = VBoxContainer.new()
	info.theme_override_constants.separation = 5

	var name_row = HBoxContainer.new()
	name_row.theme_override_constants.separation = 10

	var name = Label.new()
	name.text = slot.manager_name
	name.theme_override_font_sizes.font_size = 18
	name.horizontal_alignment = 0
	name_row.add_child(name)

	var club = Label.new()
	club.text = slot.club
	club.theme_override_font_sizes.font_size = 14
	club.horizontal_alignment = 0
	club.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	name_row.add_child(club)

	info.add_child(name_row)

	var details = Label.new()
	details.text = "Season %d/%d • %s" % [
		slot.season,
		slot.season + 1,
		SaveSystem.instance.format_save_date(slot.timestamp)
	]
	details.theme_override_font_sizes.font_size = 12
	details.horizontal_alignment = 0
	details.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
	info.add_child(details)

	hbox.add_child(info)

	# Delete button
	var delete_btn = Button.new()
	delete_btn.text = "🗑"
	delete_btn.custom_minimum_size = Vector2(40, 40)
	delete_btn.theme_override_font_sizes.font_size = 16
	delete_btn.pressed.connect(_on_delete_save.bind(slot.name))
	hbox.add_child(delete_btn)

	return button

func _on_save_selected(slot_name: String):
	var game_state = SaveSystem.instance.load_game(slot_name)
	if game_state:
		emit_signal("game_loaded", game_state)
		queue_free()

func _on_delete_save(slot_name: String):
	# Show confirmation
	ScreenManager.instance.show_confirmation(
		"Delete Save",
		"Are you sure you want to delete this save? This cannot be undone.",
		Callable(self, "_confirm_delete_save").bind(slot_name)
	)

func _confirm_delete_save(slot_name: String):
	SaveSystem.instance.delete_save(slot_name)
	_refresh_save_list()

func _on_new_career():
	queue_free()
	var new_career_scene = ResourceLoader.load("res://scenes/ui/screens/NewCareerScreen.tscn")
	if new_career_scene:
		var dialog = new_career_scene.instantiate()
		dialog.career_started.connect(_on_career_started_from_load)
		get_tree().root.add_child(dialog)
		dialog.popup_centered()

func _on_career_started_from_load(club_id: String, first_name: String, last_name: String, nationality: String, dob: Dictionary):
	emit_signal("game_loaded", {
		"current_save_id": "career_%d" % Time.get_unix_time_from_system(),
		"manager_name": "%s %s" % [first_name, last_name],
		"manager_nationality": nationality,
		"manager_date_of_birth": dob,
		"current_club_id": club_id,
		"current_season": 2024,
		"current_date": {"year": 2024, "month": 7, "day": 1},
		"game_speed": 1,
		"is_paused": false,
		"season_stage": "PRE_SEASON",
		"transfer_window_open": true,
		"current_screen": "overview",
		"settings": GameState.instance.settings,
	})

func _on_cancel():
	queue_free()