extends HBoxContainer
class_name TopBar

# =============================================================================
# UI REFERENCES
# =============================================================================

@onready var club_crest: TextureRect = $LeftSection/ClubCrest
@onready var club_name: Label = $LeftSection/ClubName
@onready var season_label: Label = $LeftSection/SeasonLabel
@onready var date_label: Label = $CenterSection/DateLabel
@onready var transfer_window_label: Label = $CenterSection/TransferWindowLabel
@onready var balance_label: Label = $RightSection/BalanceLabel
@onready var wage_budget_label: Label = $RightSection/WageBudgetLabel
@onready var pause_button: Button = $RightSection/SpeedControls/PauseButton
@onready var speed1_button: Button = $RightSection/SpeedControls/Speed1Button
@onready var speed2_button: Button = $RightSection/SpeedControls/Speed2Button
@onready var speed3_button: Button = $RightSection/SpeedControls/Speed3Button
@onready var notifications_button: Button = $RightSection/NotificationsButton
@onready var inbox_button: Button = $RightSection/InboxButton

# =============================================================================
# STATE
# =============================================================================

var speed_buttons: Array[Button] = []
var current_speed: int = 1

# =============================================================================
# INITIALIZATION
# =============================================================================

func _ready():
	speed_buttons = [pause_button, speed1_button, speed2_button, speed3_button]
	_setup_speed_buttons()
	_connect_signals()
	update_display()

func _setup_speed_buttons():
	for i, btn in enumerate(speed_buttons):
		btn.pressed.connect(_on_speed_changed.bind(i))

	# Set up button group
	for btn in speed_buttons:
		btn.button_group = "game_speed"

func _connect_signals():
	if GameState.instance:
		GameState.instance.date_changed.connect(_on_date_changed)
		GameState.instance.club_changed.connect(update_display)

func _on_date_changed(new_date: Dictionary):
	date_label.text = "%d %s %d" % [new_date.day, _get_month_name(new_date.month), new_date.year]

	# Update transfer window status
	if GameState.instance.transfer_window_open:
		transfer_window_label.text = "Transfer Window: Open"
		transfer_window_label.add_theme_color_override("font_color", Color(0.4, 0.8, 0.4))
	else:
		transfer_window_label.text = "Transfer Window: Closed"
		transfer_window_label.add_theme_color_override("font_color", Color(0.8, 0.4, 0.4))

	# Update season label
	season_label.text = "%d/%d Season" % [GameState.instance.current_season, str(GameState.instance.current_season + 1)[2:]]

func _on_speed_changed(speed_index: int):
	current_speed = speed_index
	GameState.instance.game_speed = speed_index

	# Update button states
	for i, btn in enumerate(speed_buttons):
		btn.button_pressed = (i == speed_index)

	# Update pause state
	GameState.instance.is_paused = (speed_index == 0)

func _get_month_name(month: int) -> String:
	var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
	return months[month - 1]

# =============================================================================
# PUBLIC API
# =============================================================================

func update_display():
	var club = GameState.instance.get_current_club()
	if club:
		club_name.text = club.name
		season_label.text = "%d/%d Season" % [GameState.instance.current_season, str(GameState.instance.current_season + 1)[2:]]

		# Format balance
		var balance = club.balance
		balance_label.text = "Balance: %s" % _format_currency(balance)
		if balance < 0:
			balance_label.add_theme_color_override("font_color", Color(0.9, 0.3, 0.3))
		else:
			balance_label.add_theme_color_override("font_color", Color(0.4, 0.8, 0.4))

		var wage_budget = team.wage_budget
		var total_wage = team.total_wage_bill
		wage_budget_label.text = "Wage Budget: %s / %s" % [_format_currency(total_wage * 52), _format_currency(wage_budget * 52)]

		# Update speed buttons
		for i, btn in enumerate(speed_buttons):
			btn.button_pressed = (i == GameState.instance.game_speed)

	# Update unread counts
	var unread = GameState.instance.get_unread_count()
	inbox_button.text = "📥 %d" % unread
	if unread > 0:
		inbox_button.add_theme_color_override("font_color", Color(0.9, 0.7, 0.2))
	else:
		inbox_button.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))

	# Notifications (would come from notification system)
	notifications_button.text = "🔔 0"

func _format_currency(amount: int) -> String:
	var abs_amount = abs(amount)
	if abs_amount >= 1000000000:
		return "£%.1fB" % (amount / 1000000000.0)
	elif abs_amount >= 1000000:
		return "£%.1fM" % (amount / 1000000.0)
	elif abs_amount >= 1000:
		return "£%.0fK" % (amount / 1000.0)
	else:
		return "£%d" % amount

# =============================================================================
# NOTIFICATIONS
# =============================================================================

func add_notification(toast: Control):
	# Could add to a notification container
	pass