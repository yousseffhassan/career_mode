extends PanelContainer
class_name NewCareerScreen

# =============================================================================
# SIGNALS
# =============================================================================
signal career_started(club_id: String, first_name: String, last_name: String, nationality: String, dob: Dictionary)

# =============================================================================
# UI REFERENCES
# =============================================================================

@onready var first_name_input: LineEdit = $ManagerSection/VBoxContainer/FormGrid/FirstNameInput
@onready var last_name_input: LineEdit = $ManagerSection/VBoxContainer/FormGrid/LastNameInput
@onready var nationality_select: OptionButton = $ManagerSection/VBoxContainer/FormGrid/NationalitySelect
@onready var dob_input: LineEdit = $ManagerSection/VBoxContainer/FormGrid/DOBInput
@onready var competition_filter: OptionButton = $ClubSection/VBoxContainer/ClubFilter/CompetitionFilter
@onready var club_list_container: VBoxContainer = $ClubSection/VBoxContainer/ClubList/ClubListContainer
@onready var cancel_button: Button = $ButtonRow/CancelButton
@onready var start_button: Button = $ButtonRow/StartButton

# =============================================================================
# STATE
# =============================================================================

var selected_club_id: String = ""
var all_teams: Array[TeamData] = []

# =============================================================================
# INITIALIZATION
# =============================================================================

func _ready():
	_setup_nationalities()
	_setup_competitions()
	_connect_signals()
	_refresh_club_list()

func _setup_nationalities():
	var nationalities = [
		"England", "Spain", "Germany", "Italy", "France", "Portugal", "Netherlands",
		"Belgium", "Brazil", "Argentina", "Uruguay", "Croatia", "Serbia", "Poland",
		"Turkey", "France", "Denmark", "Sweden", "Switzerland", "Austria",
		"Scotland", "Wales", "Northern Ireland", "Republic of Ireland",
	]

	for nat in nationalities:
		nationality_select.add_item(nat)

	# Default to England
	nationality_select.selected = 0

func _setup_competitions():
	competition_filter.add_item("All Competitions", "")
	for comp_id, comp in Database.instance.competitions:
		if comp.type == GameEnums.CompetitionType.LEAGUE:
			competition_filter.add_item("%s (%s)" % [comp.name, comp.country], comp_id)

	competition_filter.item_selected.connect(_on_competition_filter_changed)

func _connect_signals():
	first_name_input.text_changed.connect(_validate_form)
	last_name_input.text_changed.connect(_validate_form)
	dob_input.text_changed.connect(_validate_form)
	cancel_button.pressed.connect(_on_cancel)
	start_button.pressed.connect(_on_start)

func _refresh_club_list():
	# Clear existing
	for child in club_list_container.get_children():
		child.queue_free()

	var filter_id = competition_filter.get_item_id(competition_filter.selected)

	for team in Database.instance.teams.values():
		if filter_id != "" and team.competition_id != filter_id:
			continue

		all_teams.append(team)
		var item = _create_club_item(team)
		club_list_container.add_child(item)

func _create_club_item(team: TeamData) -> Control:
	var button = Button.new()
	button.custom_minimum_size = Vector2(0, 60)
	button.button_group = "club_selection"
	button.focus_mode = Control.FOCUS_ALL
	button.pressed.connect(_on_club_selected.bind(team.id))

	var hbox = HBoxContainer.new()
	hbox.theme_override_constants.separation = 15
	button.add_child(hbox)

	# Crest placeholder
	var crest = PanelContainer.new()
	crest.custom_minimum_size = Vector2(48, 48)
	crest.theme_override_constants.panel_margin_left = 2
	crest.theme_override_constants.panel_margin_top = 2
	crest.theme_override_constants.panel_margin_right = 2
	crest.theme_override_constants.panel_margin_bottom = 2
	crest.add_theme_color_override("bg_color", team.primary_color)
	hbox.add_child(crest)

	var info = VBoxContainer.new()
	info.theme_override_constants.separation = 2

	var name = Label.new()
	name.text = team.name
	name.theme_override_font_sizes.font_size = 16
	name.horizontal_alignment = 0
	info.add_child(name)

	var details = Label.new()
	details.text = "%s • Rep: %d • Budget: %s" % [
		team.competition_id,
		team.reputation,
		_format_currency(team.transfer_budget)
	]
	details.theme_override_font_sizes.font_size = 12
	details.horizontal_alignment = 0
	details.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	info.add_child(details)

	hbox.add_child(info)

	var reputation_bar = ProgressBar.new()
	reputation_bar.custom_minimum_size = Vector2(100, 16)
	reputation_bar.max_value = 10000
	reputation_bar.value = team.reputation
	reputation_bar.add_theme_color_override("fill_color", Color(0.4, 0.7, 0.9))
	hbox.add_child(reputation_bar)

	return button

func _on_club_selected(club_id: String):
	selected_club_id = club_id
	_validate_form()

func _on_competition_filter_changed(_index: int):
	_refresh_club_list()

func _validate_form(_dummy = null):
	var valid = true

	if first_name_input.text.strip() == "":
		valid = false
	if last_name_input.text.strip() == "":
		valid = false
	if dob_input.text.strip() == "":
		valid = false
	if selected_club_id == "":
		valid = false

	start_button.disabled = not valid

func _on_cancel():
	queue_free()

func _on_start():
	var dob = _parse_dob(dob_input.text)
	if not dob:
		dob = {"year": 1985, "month": 6, "day": 15}

	emit_signal("career_started", selected_club_id, first_name_input.text.strip(),
	            last_name_input.text.strip(), nationality_select.get_item_text(nationality_select.selected), dob)
	queue_free()

func _parse_dob(text: String) -> Dictionary:
	# Try DD/MM/YYYY format
	var parts = text.split("/")
	if parts.size() == 3:
		var day = parts[0].to_int()
		var month = parts[1].to_int()
		var year = parts[2].to_int()
		if day > 0 and day <= 31 and month > 0 and month <= 12 and year >= 1940 and year <= 2010:
			return {"year": year, "month": month, "day": day}
	return null

func _format_currency(amount: int) -> String:
	var abs_amount = abs(amount)
	if abs_amount >= 1000000:
		return "£%.1fM" % (amount / 1000000.0)
	elif abs_amount >= 1000:
		return "£%.0fK" % (amount / 1000.0)
	else:
		return "£%d" % amount