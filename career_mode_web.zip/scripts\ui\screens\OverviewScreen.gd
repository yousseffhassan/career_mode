extends VBoxContainer
class_name OverviewScreen

# =============================================================================
# UI REFERENCES
# =============================================================================

@onready var club_name: Label = $Header/ClubInfo/ClubName
@onready var club_details: Label = $Header/ClubInfo/ClubDetails
@onready var balance_value: Label = $Header/QuickStats/Stat1/Stat1Value
@onready var transfer_budget_value: Label = $Header/QuickStats/Stat2/Stat2Value
@onready var wage_budget_value: Label = $Header/QuickStats/Stat3/Stat3Value
@onready var next_match_panel: PanelContainer = $Content/LeftColumn/NextMatchPanel
@onready var home_team_name: Label = $Content/LeftColumn/NextMatchPanel/NextMatchContent/NextMatchDetails/HomeTeam/HomeTeamName
@onready var home_team_crest: TextureRect = $Content/LeftColumn/NextMatchPanel/NextMatchContent/NextMatchDetails/HomeTeam/HomeTeamCrest
@onready var away_team_name: Label = $Content/LeftColumn/NextMatchPanel/NextMatchContent/NextMatchDetails/AwayTeam/AwayTeamName
@onready var away_team_crest: TextureRect = $Content/LeftColumn/NextMatchPanel/NextMatchContent/NextMatchDetails/AwayTeam/AwayTeamCrest
@onready var match_info: Label = $Content/LeftColumn/NextMatchPanel/NextMatchContent/MatchInfo
@onready var simulate_match_button: Button = $Content/LeftColumn/NextMatchPanel/NextMatchContent/SimulateMatchButton
@onready var news_list: VBoxContainer = $Content/LeftColumn/NewsPanel/NewsContent/NewsList
@onready var league_table: Tree = $Content/RightColumn/LeagueTablePanel/LeagueTableContent/LeagueTable
@onready var squad_size_value: Label = $Content/RightColumn/SquadOverviewPanel/SquadOverviewContent/SquadStats/SquadSize/SquadSizeValue
@onready var avg_age_value: Label = $Content/RightColumn/SquadOverviewPanel/SquadOverviewContent/SquadStats/AvgAge/AvgAgeValue
@onready var avg_ca_value: Label = $Content/RightColumn/SquadOverviewPanel/SquadOverviewContent/SquadStats/AvgCA/AvgCAValue

# =============================================================================
# INITIALIZATION
# =============================================================================

func _ready():
	simulate_match_button.pressed.connect(_on_simulate_match)
	_refresh()

func on_show():
	_refresh()

func _refresh():
	var club = GameState.instance.get_current_club()
	if not club:
		return

	# Club info
	club_name.text = club.name
	club_details.text = "%s | Position: %dth | Form: %s" % [
		club.competition_id,
		club.league_position,
		_format_form(club.form)
	]

	# Financial stats
	balance_value.text = _format_currency(club.balance)
	transfer_budget_value.text = _format_currency(club.transfer_budget)
	wage_budget_value.text = "%s/week" % _format_currency(club.wage_budget)

	# Squad overview
	squad_size_value.text = str(club.get_squad_size())
	avg_age_value.text = "%.1f" % club.get_average_age(Database.instance)
	avg_ca_value.text = str(_calculate_avg_ca(club))

	# Next match
	_refresh_next_match(club)

	# League table
	_refresh_league_table(club)

	# News
	_refresh_news()

func _calculate_avg_ca(club: TeamData) -> int:
	var players = club.get_first_team_players(Database.instance)
	if players.is_empty():
		return 0
	var total = 0
	for p in players:
		total += p.current_ability
	return total / players.size()

func _refresh_next_match(club: TeamData):
	var next_fixture = Database.instance.get_next_fixture(club.id, GameState.instance.current_date)
	if next_fixture:
		var home_team = Database.instance.get_team(next_fixture.home_id)
		var away_team = Database.instance.get_team(next_fixture.away_id)

		home_team_name.text = home_team.short_name if home_team else "TBD"
		away_team_name.text = away_team.short_name if away_team else "TBD"

		var date = next_fixture.date
		match_info.text = "%s • %d %s %d • %s" % [
			next_fixture.competition_id,
			date.day,
			_get_month_name(date.month),
			date.year,
			next_fixture.home_id == club.id ? "Home" : "Away"
		]

		simulate_match_button.disabled = false
		simulate_match_button.text = "Simulate Match"
	else:
		home_team_name.text = "No fixture"
		away_team_name.text = "scheduled"
		match_info.text = "Season may not have started yet"
		simulate_match_button.disabled = true
		simulate_match_button.text = "No Match Scheduled"

func _refresh_league_table(club: TeamData):
	league_table.clear()

	var comp = Database.instance.get_competition(club.competition_id)
	if not comp or comp.standings.is_empty():
		return

	# Setup columns
	league_table.set_column_titles(["Pos", "Team", "P", "W", "D", "L", "GD", "Pts"])

	for standing in comp.standings:
		var team = Database.instance.get_team(standing.team_id)
		if not team:
			continue

		var item = league_table.create_item()
		item.set_cell(0, standing.position)
		item.set_cell(1, team.short_name)
		item.set_cell(2, standing.played)
		item.set_cell(3, standing.won)
		item.set_cell(4, standing.drawn)
		item.set_cell(5, standing.lost)
		item.set_cell(6, standing.gd)
		item.set_cell(7, standing.points)

		# Highlight current club
		if team.id == club.id:
			for i in range(8):
				item.set_custom_bg_color(i, Color(0.2, 0.3, 0.5, 0.5))
				item.set_custom_font_color(i, Color(1, 1, 0.8))

		# Color coding for positions
		if standing.position <= 4:
			item.set_custom_font_color(0, Color(0.4, 0.8, 0.4))  # Champions League
		elif standing.position <= 6:
			item.set_custom_font_color(0, Color(0.4, 0.7, 0.9))  # Europa League
		elif standing.position >= comp.number_of_teams - comp.relegation_spots + 1:
			item.set_custom_font_color(0, Color(0.9, 0.3, 0.3))  # Relegation

func _refresh_news():
	# Clear existing
	for child in news_list.get_children():
		child.queue_free()

	var messages = GameState.instance.get_messages()
	var count = 0
	for msg in messages:
		if count >= 5:
			break

		var item = HBoxContainer.new()
		item.theme_override_constants.separation = 10

		var icon = Label.new()
		icon.text = _get_message_icon(msg.type)
		icon.theme_override_font_sizes.font_size = 16
		icon.custom_minimum_size = Vector2(30, 0)
		item.add_child(icon)

		var content = VBoxContainer.new()
		content.theme_override_constants.separation = 2

		var title = Label.new()
		title.text = msg.title
		title.theme_override_font_sizes.font_size = 14
		title.horizontal_alignment = 0
		content.add_child(title)

		var body = Label.new()
		body.text = msg.body
		body.theme_override_font_sizes.font_size = 12
		body.horizontal_alignment = 0
		body.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
		body.autowrap_mode = 2
		content.add_child(body)

		item.add_child(content)
		news_list.add_child(item)

		count += 1

	if count == 0:
		var empty = Label.new()
		empty.text = "No recent news"
		empty.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
		empty.horizontal_alignment = 1
		news_list.add_child(empty)

# =============================================================================
# EVENT HANDLERS
# =============================================================================

func _on_simulate_match():
	var club = GameState.instance.get_current_club()
	var next_fixture = Database.instance.get_next_fixture(club.id, GameState.instance.current_date)

	if next_fixture:
		# Start match simulation
		var match_data = {
			"home_id": next_fixture.home_id,
			"away_id": next_fixture.away_id,
			"competition_id": next_fixture.competition_id,
			"date": next_fixture.date,
		}

		GameState.instance.start_match(match_data)
		ScreenManager.instance.navigate_to(ScreenManager.Screen.MATCH)

func _get_message_icon(type: String) -> String:
	match type:
		"transfer": return "🔄"
		"contract": return "📝"
		"injury": return "🤕"
		"match": return "⚽"
		"news": return "📰"
		_: return "📌"

func _get_month_name(month: int) -> String:
	var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
	return months[month - 1]

func _format_form(form: Array[int]) -> String:
	var symbols = []
	for f in form:
		match f:
			3: symbols.append("W")
			1: symbols.append("D")
			0: symbols.append("L")
	return "-".join(symbols)

func _format_currency(amount: int) -> String:
	var abs_amount = abs(amount)
	if abs_amount >= 1000000000:
		return "£%.1fB" % (amount / 1000000000.0)
	elif abs_amount >= 1000000:
		return "£%.1fM" % (amount / 1000000.0)
	elif abs_amount >= 1000:
		return "£%.0fK" % (amount / 1000.0)
	else:
		return "£%d" % amount