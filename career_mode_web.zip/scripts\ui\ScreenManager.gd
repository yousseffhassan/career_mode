extends Node
class_name ScreenManager

# Singleton
static var instance: ScreenManager = null

# =============================================================================
# SCREEN DEFINITIONS
# =============================================================================

enum Screen {
	OVERVIEW,
	SQUAD,
	TACTICS,
	TRAINING,
	TRANSFERS,
	STAFF,
	YOUTH_ACADEMY,
	FINANCES,
	CALENDAR,
	INBOX,
	MATCH,
	CONTRACT_NEGOTIATION,
	PRESS_CONFERENCE,
	SETTINGS,
}

const SCREEN_PATHS = {
	Screen.OVERVIEW: "res://scenes/ui/screens/OverviewScreen.tscn",
	Screen.SQUAD: "res://scenes/ui/screens/SquadScreen.tscn",
	Screen.TACTICS: "res://scenes/ui/screens/TacticsScreen.tscn",
	Screen.TRAINING: "res://scenes/ui/screens/TrainingScreen.tscn",
	Screen.TRANSFERS: "res://scenes/ui/screens/TransfersScreen.tscn",
	Screen.STAFF: "res://scenes/ui/screens/StaffScreen.tscn",
	Screen.YOUTH_ACADEMY: "res://scenes/ui/screens/YouthAcademyScreen.tscn",
	Screen.FINANCES: "res://scenes/ui/screens/FinancesScreen.tscn",
	Screen.CALENDAR: "res://scenes/ui/screens/CalendarScreen.tscn",
	Screen.INBOX: "res://scenes/ui/screens/InboxScreen.tscn",
	Screen.MATCH: "res://scenes/ui/screens/MatchScreen.tscn",
	Screen.CONTRACT_NEGOTIATION: "res://scenes/ui/screens/ContractNegotiationScreen.tscn",
	Screen.PRESS_CONFERENCE: "res://scenes/ui/screens/PressConferenceScreen.tscn",
	Screen.SETTINGS: "res://scenes/ui/screens/SettingsScreen.tscn",
}

const SCREEN_NAMES = {
	Screen.OVERVIEW: "Overview",
	Screen.SQUAD: "Squad",
	Screen.TACTICS: "Tactics",
	Screen.TRAINING: "Training",
	Screen.TRANSFERS: "Transfers",
	Screen.STAFF: "Staff",
	Screen.YOUTH_ACADEMY: "Youth Academy",
	Screen.FINANCES: "Finances",
	Screen.CALENDAR: "Calendar",
	Screen.INBOX: "Inbox",
	Screen.MATCH: "Match",
	Screen.CONTRACT_NEGOTIATION: "Contract",
	Screen.PRESS_CONFERENCE: "Press",
	Screen.SETTINGS: "Settings",
}

# =============================================================================
# STATE
# =============================================================================

var current_screen: Screen = Screen.OVERVIEW
var screen_instances: Dictionary = {}
var screen_container: Control = null
var sidebar: Control = null
var top_bar: Control = null
var loading_screen: Control = null

# Screen history for back navigation
var screen_history: Array[Screen] = []
const MAX_HISTORY = 10

# =============================================================================
# SIGNALS
# =============================================================================
signal screen_changed(screen: Screen)
signal screen_load_progress(progress: float)

# =============================================================================
# INITIALIZATION
# =============================================================================

func _ready():
	instance = self
	_setup_ui_references()
	_preload_screens()

func _setup_ui_references():
	# These will be set by Main.tscn
	pass

func set_ui_references(container: Control, sidebar_ref: Control, top_bar_ref: Control, loading_ref: Control = null):
	screen_container = container
	sidebar = sidebar_ref
	top_bar = top_bar_ref
	loading_screen = loading_ref

func _preload_screens():
	# Preload commonly used screens
	var priority_screens = [Screen.OVERVIEW, Screen.SQUAD, Screen.TACTICS, Screen.TRANSFERS]
	for screen in priority_screens:
		_load_screen_async(screen)

# =============================================================================
# SCREEN NAVIGATION
# =============================================================================

func navigate_to(screen: Screen, add_to_history: bool = true):
	if current_screen == screen:
		return

	# Add to history
	if add_to_history and current_screen != Screen.OVERVIEW:
		screen_history.append(current_screen)
		if screen_history.size() > MAX_HISTORY:
			screen_history.remove_at(0)

	# Show loading for heavy screens
	var heavy_screens = [Screen.MATCH, Screen.TACTICS]
	if screen in heavy_screens and loading_screen:
		loading_screen.visible = true
		loading_screen.get_node_or_null("ProgressBar")?.value = 0

	# Load screen if not cached
	if not screen_instances.has(screen):
		_load_screen(screen)

	# Switch screen
	_switch_screen(screen)

	current_screen = screen
	GameState.instance.navigate_to(SCREEN_NAMES[screen].to_lower())
	emit_signal("screen_changed", screen)

	# Update sidebar selection
	_update_sidebar_selection()

	# Hide loading
	if loading_screen:
		loading_screen.visible = false

func _load_screen(screen: Screen):
	var path = SCREEN_PATHS.get(screen)
	if not path:
		push_error("No path for screen: %s" % screen)
		return

	var scene = ResourceLoader.load_threaded_get(path)
	if scene:
		var instance = scene.instantiate()
		instance.name = "Screen_%s" % screen
		screen_instances[screen] = instance
		if screen_container:
			screen_container.add_child(instance)
		instance.visible = false
	else:
		push_error("Failed to load screen: %s" % path)

func _load_screen_async(screen: Screen):
	# For background preloading
	var path = SCREEN_PATHS.get(screen)
	if not path:
		return

	ResourceLoader.load_threaded_request(path)

func _switch_screen(screen: Screen):
	# Hide current
	if screen_instances.has(current_screen):
		screen_instances[current_screen].visible = false
		if screen_instances[current_screen].has_method("on_hide"):
			screen_instances[current_screen].on_hide()

	# Show new
	if screen_instances.has(screen):
		screen_instances[screen].visible = true
		if screen_instances[screen].has_method("on_show"):
			screen_instances[screen].on_show()
	else:
		# Fallback - load now
		_load_screen(screen)
		if screen_instances.has(screen):
			screen_instances[screen].visible = true

func navigate_back():
	if screen_history.is_empty():
		navigate_to(Screen.OVERVIEW)
		return

	var previous = screen_history.pop_back()
	navigate_to(previous, false)

func get_current_screen() -> Screen:
	return current_screen

func get_screen_instance(screen: Screen) -> Control:
	return screen_instances.get(screen)

# =============================================================================
# SIDEBAR MANAGEMENT
# =============================================================================

func _update_sidebar_selection():
	if sidebar and sidebar.has_method("set_selected_screen"):
		sidebar.set_selected_screen(current_screen)

# =============================================================================
# TOP BAR UPDATES
# =============================================================================

func update_top_bar():
	if top_bar and top_bar.has_method("update_display"):
		top_bar.update_display()

# =============================================================================
# DIALOG MANAGEMENT
# =============================================================================

var dialog_stack: Array[Control] = []

func show_dialog(dialog: Control, modal: bool = true):
	if modal:
		dialog_stack.append(dialog)
	dialog.popup_centered()

func close_dialog(dialog: Control = null):
	if dialog:
		dialog.queue_free()
		dialog_stack.erase(dialog)
	elif dialog_stack.size() > 0:
		dialog_stack.pop_back().queue_free()

func close_all_dialogs():
	for d in dialog_stack:
		d.queue_free()
	dialog_stack.clear()

# =============================================================================
# NOTIFICATION TOASTS
# =============================================================================

func show_notification(text: String, type: String = "info", duration: float = 3.0):
	var toast_scene = ResourceLoader.load("res://scenes/ui/components/NotificationToast.tscn")
	if toast_scene:
		var toast = toast_scene.instantiate()
		if hasattr(toast, "set_text"):
			toast.set_text(text, type)
		if hasattr(toast, "set_duration"):
			toast.set_duration(duration)

		# Add to top bar or dedicated notification area
		if top_bar and top_bar.has_method("add_notification"):
			top_bar.add_notification(toast)
		else:
			get_tree().root.add_child(toast)
			toast.global_position = Vector2(get_viewport_rect().size.x - 350, 100)

# =============================================================================
# CONFIRMATION DIALOGS
# =============================================================================

func show_confirmation(title: String, message: String, on_confirm: Callable, on_cancel: Callable = null):
	var dialog_scene = ResourceLoader.load("res://scenes/ui/components/ConfirmationDialog.tscn")
	if dialog_scene:
		var dialog = dialog_scene.instantiate()
		if hasattr(dialog, "setup"):
			dialog.setup(title, message, on_confirm, on_cancel)
		show_dialog(dialog)

# =============================================================================
# UTILITY
# =============================================================================

func get_screen_name(screen: Screen) -> String:
	return SCREEN_NAMES.get(screen, "Unknown")

func is_screen_loaded(screen: Screen) -> bool:
	return screen_instances.has(screen)

func preload_screen(screen: Screen):
	_load_screen_async(screen)

func unload_screen(screen: Screen):
	if screen_instances.has(screen):
		screen_instances[screen].queue_free()
		screen_instances.erase(screen)

func unload_all_except(screen: Screen):
	var to_remove = []
	for s in screen_instances:
		if s != screen:
			to_remove.append(s)
	for s in to_remove:
		unload_screen(s)