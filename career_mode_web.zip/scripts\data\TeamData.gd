extends Resource
class_name TeamData

# =============================================================================
# IDENTITY
# =============================================================================
@export var id: String = ""
@export var name: String = ""
@export var short_name: String = ""
@export var nationality: String = ""
@export var founded_year: int = 1900
@export var reputation: int = 5000  # 1-10000
@export var nickname: String = ""

# Colors
@export var primary_color: Color = Color(1, 1, 1)
@export var secondary_color: Color = Color(0, 0, 0)
@export var tertiary_color: Color = Color(0.5, 0.5, 0.5)

# =============================================================================
# STADIUM
# =============================================================================
@export_group("Stadium")
@export var stadium_name: String = ""
@export var stadium_capacity: int = 20000
@export var stadium_seats: int = 20000
@export var stadium_built_year: int = 1950
@export var stadium_expansion_possible: bool = true
@export var stadium_expansion_cost: int = 0
@export var training_facilities_level: int = 10  # 1-20
@export var youth_facilities_level: int = 10  # 1-20
@export var youth_recruitment_level: int = 10  # 1-20

# =============================================================================
# SQUAD & STAFF
# =============================================================================
@export_group("Squad & Staff")
@export var player_ids: Array[String] = []  # References to PlayerData
@export var staff_ids: Array[String] = []  # References to StaffData

# =============================================================================
# FINANCES
# =============================================================================
@export_group("Finances")
@export var balance: int = 0  # Can be negative
@export var transfer_budget: int = 0
@export var wage_budget: int = 0
@export var total_wage_bill: int = 0  # Weekly

# Income (annual)
@export var tv_income: int = 0
@export var sponsorship_income: int = 0
@export var matchday_income: int = 0
@export var merch_income: int = 0
@export var prize_money: int = 0
@export var transfer_income: int = 0  # Player sales

# Expenses (annual)
@export var wage_expenses: int = 0
@export var transfer_expenses: int = 0  # Player purchases (amortized)
@export var staff_wages: int = 0
@export var facility_maintenance: int = 0
@export var loan_interest: int = 0

# Financial history
@export var monthly_balance_history: Array[int] = []  # Last 12 months
@export var season_finances: Array[Dictionary] = []  # Per season breakdown

# =============================================================================
# COMPETITION & LEAGUE
# =============================================================================
@export_group("Competition")
@export var competition_id: String = ""
@export var league_position: int = 0
@export var previous_league_position: int = 0
@export var form: Array[int] = []  # Last 5: 3=W, 1=D, 0=L

# Season stats
@export var season_played: int = 0
@export var season_won: int = 0
@export var season_drawn: int = 0
@export var season_lost: int = 0
@export var season_goals_for: int = 0
@export var season_goals_against: int = 0
@export var season_points: int = 0
@export var season_clean_sheets: int = 0

# Cup runs
@export var cup_progress: Dictionary = {}  # competition_id -> round reached

# =============================================================================
# TACTICS
# =============================================================================
@export_group("Tactics")
@export var preferred_formation: String = "4-4-2"
@export var tactical_familiarity: Dictionary = {}  # formation -> familiarity 0-100
@export var team_instructions: Dictionary = {}  # Mentality, tempo, etc.
@export var set_piece_takers: Dictionary = {}  # Type -> player_id

# =============================================================================
# RIVALRIES & RELATIONSHIPS
# =============================================================================
@export_group("Rivalries")
@export var rival_club_ids: Array[String] = []
@export var friendly_club_ids: Array[String] = []  # Affiliates, feeder clubs
@export var loan_club_ids: Array[String] = []

# =============================================================================
# BOARD & EXPECTATIONS
# =============================================================================
@export_group("Board")
@export var board_expectation: String = "Mid-table"  # Avoid relegation, Mid-table, Top half, Challenge for title, Win league
@export var board_confidence: int = 50  # 0-100
@export var board_patience: int = 50  # 0-100
@export var transfer_policy: String = "Balanced"  # Youth focus, Balanced, Sign stars, Sell to buy
@export var wage_policy: String = "Average"  # Low, Average, High, Top

# =============================================================================
# HISTORY & HONOURS
# =============================================================================
@export_group("History")
@export var honours: Array[Dictionary] = []  # {competition, season, type}
@export var best_league_finish: int = 20
@export var best_cup_run: String = ""
@export var all_time_top_scorer_id: String = ""
@export var all_time_appearances_id: String = ""
@export var legends: Array[String] = []  # Player IDs considered legends

# =============================================================================
# AI BEHAVIOR
# =============================================================================
@export_group("AI Behavior")
@export var ai_manager_style: String = "Balanced"  # Defensive, Balanced, Attacking
@export var ai_transfer_strategy: String = "Balanced"
@export var ai_squad_rotation: float = 0.3
@export var ai_youth_promotion_chance: float = 0.2

# =============================================================================
# COMPUTED PROPERTIES
# =============================================================================

func get_squad_size() -> int:
	return player_ids.size()

func get_first_team_players(database: Database) -> Array[PlayerData]:
	var first_team = []
	for pid in player_ids:
		var player = database.get_player(pid)
		if player and player.squad_status in [GameEnums.SquadStatus.KEY_PLAYER, GameEnums.SquadStatus.FIRST_TEAM, GameEnums.SquadStatus.ROTATION]:
			first_team.append(player)
	return first_team

func get_players_by_position(position: int, database: Database) -> Array[PlayerData]:
	var players = []
	for pid in player_ids:
		var player = database.get_player(pid)
		if player and player.primary_position == position:
			players.append(player)
	return players

func get_total_squad_value(database: Database) -> int:
	var total = 0
	for pid in player_ids:
		var player = database.get_player(pid)
		if player:
			total += estimate_player_value(player)
	return total

func estimate_player_value(player: PlayerData) -> int:
	# Simplified value estimation based on CA, age, contract, position
	var base_value = player.current_ability * 50000
	var age = player.get_age()

	# Age curve
	if age <= 21:
		base_value *= 1.5
	elif age <= 24:
		base_value *= 1.3
	elif age <= 27:
		base_value *= 1.1
	elif age <= 30:
		base_value *= 0.9
	elif age <= 32:
		base_value *= 0.6
	else:
		base_value *= 0.3

	# Contract years remaining
	var years_left = player.get_contract_years_remaining()
	if years_left < 1:
		base_value *= 0.5
	elif years_left < 2:
		base_value *= 0.75

	# Position multiplier
	match player.primary_position:
		GameEnums.Position.GK:
			base_value *= 0.8
		GameEnums.Position.STR:
			base_value *= 1.2
		GameEnums.Position.AMC, GameEnums.Position.AML, GameEnums.Position.AMR:
			base_value *= 1.15

	return int(base_value)

func get_average_age(database: Database) -> float:
	var first_team = get_first_team_players(database)
	if first_team.is_empty():
		return 0.0
	var total_age = 0
	for player in first_team:
		total_age += player.get_age()
	return total_age / first_team.size()

func get_squad_depth(database: Database) -> Dictionary:
	var depth = {}
	for pos in [GameEnums.Position.GK, GameEnums.Position.DR, GameEnums.Position.DCR, GameEnums.Position.DCL, GameEnums.Position.DL,
	            GameEnums.Position.DM, GameEnums.Position.MR, GameEnums.Position.MC, GameEnums.Position.ML,
	            GameEnums.Position.AMR, GameEnums.Position.AMC, GameEnums.Position.AML, GameEnums.Position.STR]:
		var players = get_players_by_position(pos, database)
		depth[GameEnums.get_position_short(pos)] = players.size()
	return depth

func can_afford_wage(weekly_wage: int) -> bool:
	return (total_wage_bill + weekly_wage) <= wage_budget

func get_financial_health() -> String:
	var monthly_avg = 0
	if monthly_balance_history.size() > 0:
		for b in monthly_balance_history:
			monthly_avg += b
		monthly_avg /= monthly_balance_history.size()

	if balance > 50000000 and monthly_avg > 1000000:
		return "Rich"
	elif balance > 10000000 and monthly_avg > 0:
		return "Secure"
	elif balance > 0 and monthly_avg > -500000:
		return "Okay"
	elif balance > -10000000:
		return "Concerning"
	else:
		return "Critical"

# Serialize for saving
func to_dict() -> Dictionary:
	var dict = {}
	var props = get_property_list()
	for prop in props:
		var name = prop.name
		if name.begins_with("_"):
			continue
		var value = get(name)
		# Handle Color serialization
		if value is Color:
			dict[name] = {"r": value.r, "g": value.g, "b": value.b, "a": value.a}
		else:
			dict[name] = value
	return dict

func from_dict(dict: Dictionary):
	for key, value in dict:
		if hasattr(key):
			if key in ["primary_color", "secondary_color", "tertiary_color"] and value is Dictionary:
				set(key, Color(value.r, value.g, value.b, value.a))
			else:
				set(key, value)