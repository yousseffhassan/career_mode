extends Node
class_name Simulation

# Singleton
static var instance: Simulation = null

# =============================================================================
# SIGNALS
# =============================================================================
signal simulation_step_completed(step_name: String)
signal match_simulated(result: Dictionary)
signal season_finished(league_table: Array)
signal youth_intake_generated(players: Array)
signal transfer_deadline_day

# =============================================================================
# INITIALIZATION
# =============================================================================

func _ready():
	instance = self

# =============================================================================
# SEASON SIMULATION
# =============================================================================

func simulate_season(competition_id: String):
	var comp = Database.instance.get_competition(competition_id)
	if not comp:
		return

	if comp.is_league():
		_simulate_league(comp)
	elif comp.is_cup():
		_simulate_cup(comp)
	elif comp.is_continental():
		_simulate_continental(comp)

	emit_signal("simulation_step_completed", "season_%s" % competition_id)

func _simulate_league(comp: CompetitionData):
	var teams = comp.get_teams(Database.instance)
	var team_count = teams.size()

	# Generate fixtures if not exist
	if comp.fixtures.is_empty():
		_generate_league_fixtures(comp, teams)

	# Simulate each matchday
	var matchdays = team_count - 1
	for matchday in range(matchdays * 2):  # Home and away
		_simulate_matchday(comp, matchday)

	# Finalize standings
	_finalize_league_standings(comp)

	# Process promotion/relegation
	_process_promotion_relegation(comp)

	emit_signal("season_finished", comp.standings)

func _generate_league_fixtures(comp: CompetitionData, teams: Array[TeamData]):
	var team_ids = []
	for t in teams:
		team_ids.append(t.id)

	# Simple round-robin fixture generation
	var fixtures = []
	var n = team_ids.size()

	for round_num in range(n - 1):
		for i in range(n // 2):
			var home = team_ids[i]
			var away = team_ids[n - 1 - i]
			if home != away:
				var date = _calculate_match_date(comp, round_num * 2, i)
				fixtures.append({
					"id": "fix_%s_%d_%s_vs_%s" % [comp.id, fixtures.size(), home, away],
					"competition_id": comp.id,
					"home_id": home,
					"away_id": away,
					"date": date,
					"round": round_num + 1,
					"played": false,
					"home_goals": 0,
					"away_goals": 0,
				})

		# Rotate for next round (circle method)
		var last = team_ids.pop_back()
		team_ids.insert(1, last)

	# Second half (reverse home/away)
	var first_half = fixtures.duplicate()
	for fix in first_half:
		var new_fix = fix.duplicate()
		new_fix.home_id = fix.away_id
		new_fix.away_id = fix.home_id
		new_fix.id = "fix_%s_%d_%s_vs_%s" % [comp.id, fixtures.size(), new_fix.home_id, new_fix.away_id]
		new_fix.round = fix.round + (n - 1)
		new_fix.date = _calculate_match_date(comp, new_fix.round, 0)
		fixtures.append(new_fix)

	comp.fixtures = fixtures

func _calculate_match_date(comp: CompetitionData, round_num: int, match_index: int) -> Dictionary:
	var start = {"year": GameState.instance.current_season, "month": comp.start_month, "day": comp.start_day}
	var days_per_round = 7  # Weekly matches
	var total_days = round_num * days_per_round + (match_index % 2) * 3  # Weekend spread
	return _add_days(start, total_days)

func _add_days(date: Dictionary, days: int) -> Dictionary:
	var result = date.duplicate()
	for _ in range(days):
		result.day += 1
		var dim = _get_days_in_month(result.month, result.year)
		if result.day > dim:
			result.day = 1
			result.month += 1
			if result.month > 12:
				result.month = 1
				result.year += 1
	return result

func _get_days_in_month(month: int, year: int) -> int:
	match month:
		1, 3, 5, 7, 8, 10, 12: return 31
		4, 6, 9, 11: return 30
		2:
			if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
				return 29
			return 28

func _simulate_matchday(comp: CompetitionData, matchday: Int):
	var matchday_fixtures = []
	for fix in comp.fixtures:
		if fix.round == matchday + 1 and not fix.played:
			matchday_fixtures.append(fix)

	for fix in matchday_fixtures:
		var result = simulate_match(fix.home_id, fix.away_id, comp.id)
		fix.played = true
		fix.home_goals = result.home_goals
		fix.away_goals = result.away_goals
		fix.result = result

		comp.results.append(fix)

		# Update team stats
		_update_team_stats_from_result(fix.home_id, fix.away_id, result.home_goals, result.away_goals)

func _update_team_stats_from_result(home_id: String, away_id: String, hg: int, ag: int):
	var home = Database.instance.get_team(home_id)
	var away = Database.instance.get_team(away_id)

	if home:
		home.season_played += 1
		home.season_goals_for += hg
		home.season_goals_against += ag
		if hg > ag:
			home.season_won += 1
			home.season_points += 3
			home.form.insert(0, 3)
		elif hg == ag:
			home.season_drawn += 1
			home.season_points += 1
			home.form.insert(0, 1)
		else:
			home.season_lost += 1
			home.form.insert(0, 0)
		if home.form.size() > 5:
			home.form.resize(5)

	if away:
		away.season_played += 1
		away.season_goals_for += ag
		away.season_goals_against += hg
		if ag > hg:
			away.season_won += 1
			away.season_points += 3
			away.form.insert(0, 3)
		elif ag == hg:
			away.season_drawn += 1
			away.season_points += 1
			away.form.insert(0, 1)
		else:
			away.season_lost += 1
			away.form.insert(0, 0)
		if away.form.size() > 5:
			away.form.resize(5)

func _finalize_league_standings(comp: CompetitionData):
	var teams = comp.get_teams(Database.instance)

	# Sort by points, GD, GF
	teams.sort_custom(self, "_compare_team_standings")

	comp.standings.clear()
	for i, team in enumerate(teams):
		comp.standings.append({
			"position": i + 1,
			"team_id": team.id,
			"played": team.season_played,
			"won": team.season_won,
			"drawn": team.season_drawn,
			"lost": team.season_lost,
			"gf": team.season_goals_for,
			"ga": team.season_goals_against,
			"gd": team.season_goals_for - team.season_goals_against,
			"points": team.season_points,
			"form": team.form.duplicate(),
		})
		team.league_position = i + 1

func _compare_team_standings(a: TeamData, b: TeamData) -> int:
	if a.season_points != b.season_points:
		return b.season_points - a.season_points
	var gd_a = a.season_goals_for - a.season_goals_against
	var gd_b = b.season_goals_for - b.season_goals_against
	if gd_a != gd_b:
		return gd_b - gd_a
	return b.season_goals_for - a.season_goals_for

func _process_promotion_relegation(comp: CompetitionData):
	if comp.promotion_spots == 0 and comp.relegation_spots == 0:
		return

	# This would handle promotion/relegation between divisions
	# For now, just record final positions
	pass

func _simulate_cup(comp: CompetitionData):
	# Cup simulation - knockout format
	var teams = comp.get_teams(Database.instance)
	var team_ids = []
	for t in teams:
		team_ids.append(t.id)

	# Shuffle for random draw
	team_ids.shuffle()

	var current_round_teams = team_ids
	var round_num = 1

	while current_round_teams.size() > 1:
		var next_round = []
		for i in range(0, current_round_teams.size(), 2):
			if i + 1 < current_round_teams.size():
				var home = current_round_teams[i]
				var away = current_round_teams[i + 1]
				var result = simulate_match(home, away, comp.id)

				var winner = result.home_goals > result.away_goals ? home : away
				if result.home_goals == result.away_goals:
					# Replay or penalties - simplified to random
					winner = randi() % 2 == 0 ? home : away

				next_round.append(winner)

				comp.cup_results.append({
					"round": round_num,
					"home_id": home,
					"away_id": away,
					"home_goals": result.home_goals,
					"away_goals": result.away_goals,
					"winner": winner,
				})
		current_round_teams = next_round
		round_num += 1

	if current_round_teams.size() == 1:
		comp.current_champion_id = current_round_teams[0]

func _simulate_continental(comp: CompetitionData):
	# Simplified continental competition
	_simulate_cup(comp)

# =============================================================================
# MATCH SIMULATION
# =============================================================================

func simulate_match(home_id: String, away_id: String, competition_id: String = "") -> Dictionary:
	var home_team = Database.instance.get_team(home_id)
	var away_team = Database.instance.get_team(away_id)

	if not home_team or not away_team:
		return {"home_goals": 0, "away_goals": 0, "events": []}

	# Get tactics for both teams
	var home_tactics = _get_team_tactics(home_team)
	var away_tactics = _get_team_tactics(away_team)

	# Calculate team strengths
	var home_strength = _calculate_team_strength(home_team, home_tactics, true)
	var away_strength = _calculate_team_strength(away_team, away_tactics, false)

	# Home advantage
	home_strength *= 1.15

	# Simulate match
	var events = []
	var home_goals = 0
	var away_goals = 0

	var total_strength = home_strength + away_strength
	var home_ratio = home_strength / total_strength

	# Expected goals based on strength
	var base_xg = 2.5  # Average total goals per match
	var home_xg = base_xg * home_ratio
	var away_xg = base_xg * (1.0 - home_ratio)

	# Add randomness
	home_xg *= randf_range(0.7, 1.4)
	away_xg *= randf_range(0.7, 1.4)

	# Generate goals using Poisson distribution
	home_goals = _poisson_random(home_xg)
	away_goals = _poisson_random(away_xg)

	# Cap goals
	home_goals = clamp(home_goals, 0, 8)
	away_goals = clamp(away_goals, 0, 8)

	# Generate match events
	events = _generate_match_events(home_team, away_team, home_goals, away_goals, home_tactics, away_tactics)

	var result = {
		"home_id": home_id,
		"away_id": away_id,
		"home_goals": home_goals,
		"away_goals": away_goals,
		"events": events,
		"home_xg": home_xg,
		"away_xg": away_xg,
		"competition_id": competition_id,
		"date": GameState.instance.current_date.duplicate(),
	}

	emit_signal("match_simulated", result)
	return result

func _get_team_tactics(team: TeamData) -> Dictionary:
	var tactics = {
		"formation": team.preferred_formation,
		"mentality": GameEnums.Mentality.STANDARD,
		"tempo": GameEnums.Tempo.STANDARD,
		"width": GameEnums.Width.STANDARD,
		"defensive_line": GameEnums.DefensiveLine.STANDARD,
		"pressing": GameEnums.PressingIntensity.STANDARD,
		"passing": GameEnums.PassingDirectness.STANDARD,
	}

	# Merge with saved instructions
	if team.team_instructions:
		for key, value in team.team_instructions:
			tactics[key] = value

	return tactics

func _calculate_team_strength(team: TeamData, tactics: Dictionary, is_home: bool) -> float:
	var players = team.get_first_team_players(Database.instance)
	if players.is_empty():
		return 1000.0

	var total_rating = 0.0
	var count = 0

	for player in players:
		# Get best position rating
		var rating = _get_player_match_rating(player, tactics)
		total_rating += rating
		count += 1

	var avg_rating = total_rating / max(1, count)

	# Factor in form, morale, injuries
	var form_factor = _calculate_form_factor(team)
	var morale_factor = _calculate_morale_factor(players)

	return avg_rating * form_factor * morale_factor

func _get_player_match_rating(player: PlayerData, tactics: Dictionary) -> float:
	# Simplified: use CA with position suitability
	var base = player.current_ability

	# Adjust for condition, morale, sharpness
	var condition_factor = player.condition / 100.0
	var morale_factor = 0.7 + (player.morale / 100.0) * 0.3
	var sharpness_factor = 0.6 + (player.match_sharpness / 100.0) * 0.4

	# Injury penalty
	if player.injury_type != GameEnums.InjuryType.NONE:
		return 0.0

	# Suspension
	if player.suspended:
		return 0.0

	return base * condition_factor * morale_factor * sharpness_factor

func _calculate_form_factor(team: TeamData) -> float:
	if team.form.is_empty():
		return 1.0

	var form_points = 0
	for f in team.form:
		form_points += f

	var avg_form = form_points / team.form.size()
	# 3pts = win, 1pt = draw, 0pts = loss
	# Average form: 3.0 = perfect, 0.0 = terrible
	return 0.8 + (avg_form / 3.0) * 0.4  # 0.8 to 1.2

func _calculate_morale_factor(players: Array[PlayerData]) -> float:
	if players.is_empty():
		return 1.0

	var total_morale = 0
	for p in players:
		total_morale += p.morale

	var avg_morale = total_morale / players.size()
	return 0.9 + (avg_morale / 100.0) * 0.2  # 0.9 to 1.1

func _poisson_random(lambda_val: float) -> int:
	# Simple Poisson approximation
	var L = exp(-lambda_val)
	var k = 0
	var p = 1.0
	while p > L:
		k += 1
		p *= randf()
	return k - 1

func _generate_match_events(home: TeamData, away: TeamData, hg: int, ag: int, ht: Dictionary, at: Dictionary) -> Array[Dictionary]:
	var events = []

	# Kick off
	events.append(_create_event(GameEnums.MatchEventType.KICK_OFF, 1, {}))

	# Generate goal events
	var goal_times = _generate_goal_times(hg + ag, 90)

	for i in range(hg):
		var time = goal_times[i] if i < goal_times.size() else randi_range(1, 90)
		var scorer = _pick_scorer(home, true)
		var assister = _pick_assister(home, scorer)
		events.append(_create_event(GameEnums.MatchEventType.GOAL, time, {
			"team": home.id,
			"player": scorer,
			"assist": assister,
			"minute": time,
			"score": "%d-%d" % [i + 1, 0],
		}))

	for i in range(ag):
		var time = goal_times[hg + i] if (hg + i) < goal_times.size() else randi_range(1, 90)
		var scorer = _pick_scorer(away, false)
		var assister = _pick_assister(away, scorer)
		events.append(_create_event(GameEnums.MatchEventType.GOAL, time, {
			"team": away.id,
			"player": scorer,
			"assist": assister,
			"minute": time,
			"score": "%d-%d" % [hg, i + 1],
		}))

	# Add some random events
	_add_random_events(events, home, away, hg, ag)

	# Half time
	events.append(_create_event(GameEnums.MatchEventType.HALF_TIME, 45, {}))

	# Full time
	events.append(_create_event(GameEnums.MatchEventType.FULL_TIME, 90, {
		"final_score": "%d-%d" % [hg, ag],
	}))

	# Sort by minute
	events.sort_custom(self, "_compare_event_minute")

	return events

func _generate_goal_times(total_goals: int, max_minute: int) -> Array[int]:
	var times = []
	for _ in range(total_goals):
		times.append(randi_range(1, max_minute))
	times.sort()
	return times

func _pick_scorer(team: TeamData, is_home: bool) -> String:
	var players = team.get_first_team_players(Database.instance)
	var attackers = []
	for p in players:
		if p.primary_position in [GameEnums.Position.STR, GameEnums.Position.AMC, GameEnums.Position.AML, GameEnums.Position.AMR, GameEnums.Position.MR, GameEnums.Position.ML]:
			attackers.append(p)
	if attackers.is_empty():
		attackers = players
	# Weight by finishing
	var total = 0
	for p in attackers:
		total += p.finishing
	var pick = randf_range(0, total)
	var cumulative = 0
	for p in attackers:
		cumulative += p.finishing
		if cumulative >= pick:
			return p.id
	return attackers[0].id

func _pick_assister(team: TeamData, scorer_id: String) -> String:
	var players = team.get_first_team_players(Database.instance)
	var midfielders = []
	for p in players:
		if p.id != scorer_id and p.primary_position in [GameEnums.Position.MC, GameEnums.Position.AMC, GameEnums.Position.MR, GameEnums.Position.ML, GameEnums.Position.DM]:
			midfielders.append(p)
	if midfielders.is_empty():
		midfielders = [p for p in players if p.id != scorer_id]
	if midfielders.is_empty():
		return ""
	var total = 0
	for p in midfielders:
		total += p.passing + p.vision
	var pick = randf_range(0, total)
	var cumulative = 0
	for p in midfielders:
		cumulative += p.passing + p.vision
		if cumulative >= pick:
			return p.id
	return midfielders[0].id

func _add_random_events(events: Array, home: TeamData, away: TeamData, hg: int, ag: int):
	var event_types = [
		GameEnums.MatchEventType.SHOT_ON_TARGET,
		GameEnums.MatchEventType.SHOT_OFF_TARGET,
		GameEnums.MatchEventType.CORNER,
		GameEnums.MatchEventType.FREE_KICK_SHOT,
		GameEnums.MatchEventType.YELLOW_CARD,
		GameEnums.MatchEventType.SAVE,
		GameEnums.MatchEventType.KEY_PASS,
	]

	var num_events = randi_range(8, 20)
	for _ in range(num_events):
		var et = event_types.pick_random()
		var minute = randi_range(1, 90)
		var team = randi() % 2 == 0 ? home : away
		var player = _pick_random_player(team)
		events.append(_create_event(et, minute, {
			"team": team.id,
			"player": player,
		}))

func _pick_random_player(team: TeamData) -> String:
	var players = team.get_first_team_players(Database.instance)
	if players.is_empty():
		return ""
	return players.pick_random().id

func _create_event(type: int, minute: int, data: Dictionary) -> Dictionary:
	return {
		"type": type,
		"type_name": GameEnums.MATCH_EVENT_NAMES.get(type, "Event"),
		"minute": minute,
		"data": data,
	}

func _compare_event_minute(a: Dictionary, b: Dictionary) -> int:
	return a.minute - b.minute

# =============================================================================
# PLAYER DEVELOPMENT
# =============================================================================

func develop_players():
	var current_date = GameState.instance.get_current_date()

	for pid, player in Database.instance.players:
		if player.club_id == "":
			continue  # Free agents don't develop in this simplified version

		var age = player.get_age(current_date)

		# Only develop players under 24 significantly
		if age <= 23:
			_develop_player_attributes(player, age)
		elif age <= 28:
			# Maintain/small improvements
			_maintain_player_attributes(player)
		else:
			# Decline
			_decline_player_attributes(player, age)

		# Update CA based on attributes
		_update_current_ability(player)

		# Handle injury recovery
		_process_injury_recovery(player)

func _develop_player_attributes(player: PlayerData, age: int):
	# Development speed based on age, professionalism, playing time
	var dev_speed = _calculate_development_speed(player, age)

	# Focus attributes based on position
	var focus_attrs = _get_focus_attributes(player.primary_position)

	for attr in focus_attrs:
		if player.get_attribute(attr) < 20:
			var increase = randf_range(0.1, 0.3) * dev_speed
			var current = player.get_attribute(attr)
			player.set_attribute(attr, min(20, current + int(increase + 0.5)))

	# Physical development for young players
	if age <= 20:
		var phys_attrs = ["pace", "acceleration", "stamina", "strength", "natural_fitness", "jumping"]
		for attr in phys_attrs:
			if player.get_attribute(attr) < 18:
				var increase = randf_range(0.05, 0.15) * dev_speed
				var current = player.get_attribute(attr)
				player.set_attribute(attr, min(18, current + int(increase + 0.5)))

func _maintain_player_attributes(player: PlayerData):
	# Small chance to improve key attributes
	var key_attrs = _get_focus_attributes(player.primary_position)
	for attr in key_attrs:
		if player.get_attribute(attr) < 20 and randf() < 0.05:
			player.set_attribute(attr, player.get_attribute(attr) + 1)

func _decline_player_attributes(player: PlayerData, age: int):
	var decline_rate = (age - 28) * 0.02
	var phys_attrs = ["pace", "acceleration", "agility", "balance", "stamina", "strength", "natural_fitness", "jumping"]
	for attr in phys_attrs:
		var current = player.get_attribute(attr)
		var decrease = randf_range(0.1, 0.3) * decline_rate
		player.set_attribute(attr, max(1, current - int(decrease + 0.5)))

func _calculate_development_speed(player: PlayerData, age: int) -> float:
	var speed = 1.0

	# Age factor (peak development at 17-19)
	if age <= 18:
		speed *= 1.5
	elif age <= 20:
		speed *= 1.2
	elif age <= 22:
		speed *= 0.8
	else:
		speed *= 0.4

	# Professionalism
	speed *= 0.5 + (player.professionalism / 20.0) * 0.5

	# Playing time (would need match data)
	# speed *= playing_time_factor

	# Coaching quality (team's coaches)
	var club = Database.instance.get_team(player.club_id)
	if club:
		var coaches = []
		for sid in club.staff_ids:
			var s = Database.instance.get_staff(sid)
			if s and s.role in [GameEnums.StaffRole.COACH_ATTACK, GameEnums.StaffRole.COACH_DEFENCE, GameEnums.StaffRole.COACH_MIDFIELD, GameEnums.StaffRole.COACH_GK]:
				coaches.append(s)
		if coaches.size() > 0:
			var avg_coaching = 0
			for c in coaches:
				avg_coaching += c.get_overall_rating()
			avg_coaching /= coaches.size()
			speed *= 0.7 + (avg_coaching / 20.0) * 0.3

	return speed

func _get_focus_attributes(position: int) -> Array[String]:
	match position:
		GameEnums.Position.GK:
			return ["reflexes", "handling", "one_on_ones", "aerial_reach", "communication", "command_of_area"]
		GameEnums.Position.DCR, GameEnums.Position.DCL:
			return ["marking", "tackling", "heading", "positioning", "concentration", "strength"]
		GameEnums.Position.DR, GameEnums.Position.DL:
			return ["pace", "acceleration", "crossing", "stamina", "marking", "tackling"]
		GameEnums.Position.DM:
			return ["tackling", "marking", "positioning", "passing", "stamina", "strength"]
		GameEnums.Position.MC:
			return ["passing", "vision", "technique", "stamina", "work_rate", "decisions"]
		GameEnums.Position.MR, GameEnums.Position.ML:
			return ["pace", "acceleration", "crossing", "dribbling", "stamina", "technique"]
		GameEnums.Position.AMC, GameEnums.Position.AML, GameEnums.Position.AMR:
			return ["passing", "vision", "technique", "flair", "off_the_ball", "decisions"]
		GameEnums.Position.STR:
			return ["finishing", "off_the_ball", "composure", "anticipation", "pace", "strength"]
		_:
			return ["technique", "decisions", "work_rate", "stamina"]

func _update_current_ability(player: PlayerData):
	# Recalculate CA from attributes
	var attrs = _get_all_weighted_attributes(player.primary_position)
	var total = 0
	var weight_sum = 0

	for attr_name, weight in attrs:
		total += player.get_attribute(attr_name) * weight
		weight_sum += weight

	var calculated_ca = int((total / weight_sum) * 10)  # Convert 1-20 to ~10-200

	# Blend with current CA (don't let it jump too much)
	var diff = calculated_ca - player.current_ability
	if diff > 0:
		player.current_ability = min(player.potential_ability, player.current_ability + ceil(diff * 0.3))
	elif diff < 0:
		player.current_ability = max(20, player.current_ability + floor(diff * 0.2))

func _get_all_weighted_attributes(position: int) -> Array[Array]:
	# Returns [[attr_name, weight], ...]
	var weights = {
		GameEnums.Position.GK: [
			["reflexes", 3], ["handling", 3], ["one_on_ones", 2], ["aerial_reach", 2], ["communication", 1], ["command_of_area", 1],
			["kicking", 1], ["throwing", 1], ["rushing_out", 1], ["eccentricity", -1],
		],
		GameEnums.Position.DCR: [
			["marking", 3], ["tackling", 3], ["heading", 2], ["positioning", 2], ["concentration", 2], ["strength", 1],
			["pace", 1], ["passing", 1], ["composure", 1],
		],
		GameEnums.Position.DM: [
			["marking", 2], ["tackling", 2], ["positioning", 2], ["passing", 2], ["stamina", 1], ["strength", 1],
			["interceptions", 2], ["work_rate", 1], ["decisions", 1],
		],
		GameEnums.Position.MC: [
			["passing", 3], ["vision", 2], ["technique", 2], ["stamina", 2], ["work_rate", 1], ["decisions", 1],
			["off_the_ball", 1], ["first_touch", 1], ["long_shots", 1],
		],
		GameEnums.Position.AMC: [
			["passing", 2], ["vision", 3], ["technique", 2], ["flair", 2], ["off_the_ball", 2], ["decisions", 1],
			["finishing", 1], ["long_shots", 1], ["dribbling", 1],
		],
		GameEnums.Position.STR: [
			["finishing", 3], ["off_the_ball", 3], ["composure", 2], ["anticipation", 2], ["pace", 1], ["strength", 1],
			["heading", 1], ["first_touch", 1], ["dribbling", 1],
		],
	}
	return weights.get(position, [["technique", 1], ["decisions", 1], ["work_rate", 1], ["stamina", 1]])

func _process_injury_recovery(player: PlayerData):
	if player.injury_type == GameEnums.InjuryType.NONE:
		return

	player.injury_remaining_days -= 1
	if player.injury_remaining_days <= 0:
		player.injury_type = GameEnums.InjuryType.NONE
		player.injury_details = ""
		player.condition = 80  # Return at reduced condition
		GameState.instance.add_message({
			"type": "injury_recovery",
			"title": "%s recovered from injury" % player.get_full_name(),
			"body": "%s is now available for selection." % player.get_full_name(),
		})

# =============================================================================
# YOUTH INTAKE
# =============================================================================

func generate_youth_intake():
	var new_players = []

	for team_id, team in Database.instance.teams:
		var intake_size = randi_range(2, 6)
		var youth_quality = team.youth_facilities_level + team.youth_recruitment_level

		for i in range(intake_size):
			var player = _generate_youth_player(team, youth_quality)
			Database.instance.players[player.id] = player
			team.player_ids.append(player.id)
			new_players.append(player)

	emit_signal("youth_intake_generated", new_players)

func _generate_youth_player(team: TeamData, youth_quality: int) -> PlayerData:
	var player = PlayerData.new()
	player.id = "youth_%s_%d_%d" % [team.id, Time.get_unix_time_from_system(), randi_range(1000, 9999)]
	player.first_name = Database.instance._get_random_first_name(team.nationality)
	player.last_name = Database.instance._get_random_last_name(team.nationality)
	player.nationality = team.nationality
	player.date_of_birth = Database.instance._generate_birth_date(15, 17)
	player.preferred_foot = randi() % 3

	# Random position
	var positions = [GameEnums.Position.GK, GameEnums.Position.DCR, GameEnums.Position.DL, GameEnums.Position.DM, GameEnums.Position.MC, GameEnums.Position.AMC, GameEnums.Position.STR]
	player.primary_position = positions.pick_random()

	# PA based on youth quality
	var base_pa = 60 + youth_quality * 2 + randi_range(-10, 10)
	player.potential_ability = clamp(base_pa, 40, 180)
	player.current_ability = randi_range(30, min(60, player.potential_ability))

	Database.instance._generate_attributes_for_position(player, player.primary_position, 0.3)

	# Youth contract
	player.club_id = team.id
	player.contract_type = GameEnums.ContractType.YOUTH
	player.contract_start_date = GameState.instance.get_current_date()
	player.contract_end_date = Database.instance._add_years_to_date(GameState.instance.get_current_date(), 2)
	player.wage = 500
	player.squad_status = GameEnums.SquadStatus.YOUTH_PLAYER

	# Hidden attributes
	player.professionalism = randi_range(5, 15)
	player.ambition = randi_range(5, 20)
	player.loyalty = randi_range(5, 20)
	player.determination = randi_range(5, 20)

	return player

# =============================================================================
# CONTRACT MANAGEMENT
# =============================================================================

func process_contract_expiries():
	var current_date = GameState.instance.get_current_date()

	for pid, player in Database.instance.players:
		if player.club_id == "":
			continue

		if player.is_contract_expiring_soon(6, current_date):
			# Notify club
			var club = Database.instance.get_team(player.club_id)
			if club:
				GameState.instance.add_message({
					"type": "contract_expiring",
					"title": "Contract Expiring: %s" % player.get_full_name(),
					"body": "%s's contract expires in 6 months. They can sign a pre-contract agreement with foreign clubs." % player.get_full_name(),
				})

		if player.get_contract_years_remaining(current_date) <= 0:
			# Contract expired - become free agent
			var old_club_id = player.club_id
			player.club_id = ""
			player.contract_type = GameEnums.ContractType.NON_CONTRACT
			Database.instance.free_agents.append(pid)

			if old_club_id != "":
				var club = Database.instance.get_team(old_club_id)
				if club:
					club.player_ids.erase(pid)

			GameState.instance.add_message({
				"type": "contract_expired",
				"title": "%s Released" % player.get_full_name(),
				"body": "%s has been released and is now a free agent." % player.get_full_name(),
			})

# =============================================================================
# REPUTATION UPDATES
# =============================================================================

func update_reputations():
	for tid, team in Database.instance.teams:
		# Adjust based on league position vs expectation
		var expectation = _get_expectation_level(team.board_expectation)
		var diff = expectation - team.league_position

		if diff <= -5:  # Far exceeded expectations
			team.reputation = min(10000, team.reputation + 200)
		elif diff < 0:  # Exceeded
			team.reputation = min(10000, team.reputation + 100)
		elif diff > 5:  # Far below
			team.reputation = max(1000, team.reputation - 150)
		elif diff > 0:  # Below
			team.reputation = max(1000, team.reputation - 50)

		# Player reputation updates
		for pid in team.player_ids:
			var player = Database.instance.get_player(pid)
			if player:
				# Based on season performance
				if player.season_appearances > 10:
					if player.season_average_rating > 7.5:
						player.current_ability = min(player.potential_ability, player.current_ability + 2)
					elif player.season_average_rating < 6.0:
						player.current_ability = max(20, player.current_ability - 1)

func _get_expectation_level(expectation: String) -> int:
	match expectation:
		"Win league": return 1
		"Challenge for title": return 3
		"Top half": return 8
		"Mid-table": return 12
		"Avoid relegation": return 17
		_: return 10

# =============================================================================
# DAILY/WEEKLY PROCESSING
# =============================================================================

func process_daily():
	# Called each game day
	process_injury_recovery_all()
	update_player_condition()
	check_suspensions()

func process_weekly():
	# Called each week (e.g., Monday)
	develop_players()
	process_training()
	update_morale()

func process_monthly():
	# Called each month (1st)
	process_finances()
	update_board_confidence()

func process_injury_recovery_all():
	for pid, player in Database.instance.players:
		_process_injury_recovery(player)

func update_player_condition():
	for pid, player in Database.instance.players:
		# Natural condition recovery
		if player.condition < 100:
			player.condition = min(100, player.condition + 2)

		# Match sharpness decay
		if player.match_sharpness > 50:
			player.match_sharpness = max(50, player.match_sharpness - 1)

func check_suspensions():
	for pid, player in Database.instance.players:
		if player.suspended and player.suspension_remaining_matches > 0:
			player.suspension_remaining_matches -= 1
			if player.suspension_remaining_matches == 0:
				player.suspended = false
				player.suspension_reason = ""

func process_training():
	# Team training happens here
	# Would use team's training schedule
	pass

func update_morale():
	for pid, player in Database.instance.players:
		# Morale tends toward neutral
		if player.morale > 60:
			player.morale = max(60, player.morale - 1)
		elif player.morale < 40:
			player.morale = min(40, player.morale + 1)

func process_finances():
	for tid, team in Database.instance.teams:
		# Monthly wage bill
		team.balance -= team.total_wage_bill * 4

		# Monthly income (simplified)
		team.balance += team.tv_income / 12
		team.balance += team.sponsorship_income / 12

		team.monthly_balance_history.append(team.balance)
		if team.monthly_balance_history.size() > 12:
			team.monthly_balance_history.remove_at(0)

func update_board_confidence():
	for tid, team in Database.instance.teams:
		# Confidence based on recent form and league position
		var form_points = 0
		for f in team.form:
			form_points += f

		var expected_pos = _get_expectation_level(team.board_expectation)
		var pos_diff = expected_pos - team.league_position

		team.board_confidence = clamp(50 + pos_diff * 5 + form_points, 0, 100)

		# Sack manager if confidence too low
		if team.board_confidence < 15 and randf() < 0.1:
			_sack_manager(team)

func _sack_manager(team: TeamData):
	# Find manager
	for sid in team.staff_ids:
		var staff = Database.instance.get_staff(sid)
		if staff and staff.role == GameEnums.StaffRole.MANAGER:
			staff.club_id = ""
			team.staff_ids.erase(sid)
			GameState.instance.add_message({
				"type": "manager_sacked",
				"title": "%s Sacked" % staff.get_full_name(),
				"body": "%s has been sacked by %s after poor results." % [staff.get_full_name(), team.name],
			})
			break