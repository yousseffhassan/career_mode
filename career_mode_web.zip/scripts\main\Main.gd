extends Node
class_name Main

# =============================================================================
# UI REFERENCES
# =============================================================================

@onready var sidebar: Control = $RootContainer/HBoxContainer/Sidebar
@onready var top_bar: Control = $RootContainer/HBoxContainer/VBoxContainer/TopBar
@onready var screen_container: Control = $RootContainer/HBoxContainer/VBoxContainer/ScreenContainer
@onready var loading_overlay: Control = $LoadingOverlay

# =============================================================================
# INITIALIZATION
# =============================================================================

func _ready():
	# Initialize singletons are already ready (autoload)
	_setup_screen_manager()
	_setup_sidebar()
	_show_start_screen()

func _setup_screen_manager():
	ScreenManager.instance.set_ui_references(screen_container, sidebar, top_bar, loading_overlay)

func _setup_sidebar():
	sidebar.screen_selected.connect(_on_sidebar_screen_selected)

func _show_start_screen():
	# Check for existing saves
	var slots = SaveSystem.instance.get_save_slots()
	if slots.size() > 0:
		_show_load_game_screen()
	else:
		_show_new_career_screen()

# =============================================================================
# SIDEBAR NAVIGATION
# =============================================================================

func _on_sidebar_screen_selected(screen_id: int):
	var screen_enum = ScreenManager.Screen(screen_id)
	ScreenManager.instance.navigate_to(screen_enum)

# =============================================================================
# START SCREENS
# =============================================================================

func _show_new_career_screen():
	var dialog_scene = ResourceLoader.load("res://scenes/ui/screens/NewCareerScreen.tscn")
	if dialog_scene:
		var dialog = dialog_scene.instantiate()
		dialog.career_started.connect(_on_career_started)
		get_tree().root.add_child(dialog)
		dialog.popup_centered()

func _show_load_game_screen():
	var dialog_scene = ResourceLoader.load("res://scenes/ui/screens/LoadGameScreen.tscn")
	if dialog_scene:
		var dialog = dialog_scene.instantiate()
		dialog.game_loaded.connect(_on_game_loaded)
		get_tree().root.add_child(dialog)
		dialog.popup_centered()

func _on_career_started(club_id: String, manager_first: String, manager_last: String, nationality: String, dob: Dictionary):
	GameState.instance.new_career(club_id, manager_first, manager_last, nationality, dob)
	ScreenManager.instance.navigate_to(ScreenManager.Screen.OVERVIEW)

func _on_game_loaded(game_state: Dictionary):
	GameState.instance.from_dict(game_state)
	ScreenManager.instance.navigate_to(ScreenManager.Screen.OVERVIEW)

# =============================================================================
# INPUT HANDLING
# =============================================================================

func _unhandled_input(event: InputEvent):
	# Global shortcuts
	if event is InputEventKey and event.pressed and not event.echo:
		# F1-F12 for quick screen access
		if event.keycode >= KEY_F1 and event.keycode <= KEY_F12:
			var screen_index = event.keycode - KEY_F1
			if screen_index < 12:
				ScreenManager.instance.navigate_to(ScreenManager.Screen(screen_index))

		# Space to pause/unpause
		if event.keycode == KEY_SPACE:
			var new_speed = 0 if GameState.instance.game_speed > 0 else 1
			GameState.instance.game_speed = new_speed
			top_bar._on_speed_changed(new_speed)

		# Escape to go back
		if event.keycode == KEY_ESCAPE:
			ScreenManager.instance.navigate_back()

# =============================================================================
# GAME LOOP
# =============================================================================

func _process(delta: float):
	if GameState.instance.is_paused:
		return

	# Process game time based on speed
	var speed_multiplier = GameState.instance.game_speed
	if speed_multiplier > 0:
		_process_game_time(delta * speed_multiplier)

func _process_game_time(delta: float):
	# This would advance the game date based on speed
	# For now, we use discrete day advancement via UI
	pass

# =============================================================================
# SAVE/LOAD
# =============================================================================

func save_game(slot_name: String = "") -> bool:
	if slot_name == "":
		slot_name = "save_%d" % GameState.instance.current_save_id.hash()

	var game_state = GameState.instance.to_dict()
	return SaveSystem.instance.save_game(slot_name, game_state)

func autosave():
	if GameState.instance.get_setting("auto_save", true):
		SaveSystem.instance.save_autosave(GameState.instance.to_dict())

# =============================================================================
# SETTINGS
# =============================================================================

func apply_settings():
	var settings = GameState.instance.settings
	# Apply graphics, audio, gameplay settings
	pass