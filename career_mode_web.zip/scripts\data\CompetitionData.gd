extends Resource
class_name CompetitionData

# =============================================================================
# IDENTITY
# =============================================================================
@export var id: String = ""
@export var name: String = ""
@export var short_name: String = ""
@export var type: int = 0  # GameEnums.CompetitionType
@export var country: String = ""
@export var continent: String = ""  # Europe, South America, etc.
@export var reputation: int = 5000  # 1-10000

# =============================================================================
# STRUCTURE
# =============================================================================
@export_group("Structure")
@export var team_ids: Array[String] = []
@export var number_of_teams: int = 20
@export var number_of_groups: int = 1  # For group stages

# League specific
@export var promotion_spots: int = 0
@export var relegation_spots: int = 0
@export var playoff_spots: int = 0
@export var playoff_format: String = ""  # "two_legged", "single_leg", "final_four"

# Cup specific
@export var rounds: int = 6
@export var two_legged_ties: bool = false
@export var away_goals_rule: bool = false
@export var extra_time: bool = true
@export var penalties: bool = true
@export var seeded_teams: Array[String] = []  # Teams entering at later rounds

# Continental specific
@export var group_stage_teams: int = 32
@export var knockout_teams: int = 16
@export var group_size: int = 4

# =============================================================================
# RULES
# =============================================================================
@export_group("Rules")
@export var points_for_win: int = 3
@export var points_for_draw: int = 1
@export var squad_size_limit: int = 25
@export var u21_squad_exempt: bool = true
@export var max_foreign_players: int = -1  # -1 = no limit
@export var max_loan_players: int = -1
@export var max_loans_from_same_club: int = -1
@export var substitution_limit: int = 5
@export var substitution_windows: int = 3
@export var concussion_substitutions: bool = true

# Financial
@export var prize_money_per_position: Array[int] = []  # Index = position-1
@export var prize_money_per_win: int = 0
@export var prize_money_per_draw: int = 0
@export var tv_money_distribution: Dictionary = {}  # "equal", "merit", "facility"

# =============================================================================
# SCHEDULE
# =============================================================================
@export_group("Schedule")
@export var start_month: int = 8  # August
@export var start_day: int = 1
@export var end_month: int = 5  # May
@export var end_day: int = 31
@export var winter_break_start: int = 0  # 0 = no break
@export var winter_break_end: int = 0
@export var match_days: Array[int] = [5, 6]  # 5=Saturday, 6=Sunday (0=Monday)
@export var fixture_congestion_threshold: int = 3  # Games per week

# =============================================================================
# HISTORY & RECORDS
# =============================================================================
@export_group("History")
@export var most_titles_club_id: String = ""
@export var most_titles_count: int = 0
@export var current_champion_id: String = ""
@export var top_scorer_record: Dictionary = {}  # {player_id, goals, season}
@export var biggest_win: Dictionary = {}  # {home_id, away_id, score, season}

# =============================================================================
# CURRENT SEASON STATE (Dynamic)
# =============================================================================
@export_group("Current Season")
@export var current_season: int = 2024
@export var standings: Array[Dictionary] = []  # League table
@export var fixtures: Array[Dictionary] = []  # All fixtures
@export var results: Array[Dictionary] = []  # Played matches
@export var top_scorers: Array[Dictionary] = []  # {player_id, goals, team_id}
@export var top_assisters: Array[Dictionary] = []

# Cup state
@export var current_round: int = 0
@export var cup_draw: Array[Dictionary] = []  # {home_id, away_id, leg, date}
@export var cup_results: Array[Dictionary] = []

# =============================================================================
# COMPUTED PROPERTIES
# =============================================================================

func get_teams(database: Database) -> Array[TeamData]:
	var teams = []
	for tid in team_ids:
		var team = database.get_team(tid)
		if team:
			teams.append(team)
	return teams

func is_league() -> bool:
	return type == GameEnums.CompetitionType.LEAGUE

func is_cup() -> bool:
	return type == GameEnums.CompetitionType.CUP

func is_continental() -> bool:
	return type in [GameEnums.CompetitionType.CONTINENTAL_LEAGUE, GameEnums.CompetitionType.CONTINENTAL_CUP]

func get_standing_position(team_id: String) -> int:
	for i, standing in standings:
		if standing.team_id == team_id:
			return i + 1
	return -1

func get_team_form(team_id: String, last_n: int = 5) -> Array[int]:
	var form = []
	for result in results:
		if result.home_id == team_id or result.away_id == team_id:
			var is_home = result.home_id == team_id
			var gf = is_home ? result.home_goals : result.away_goals
			var ga = is_home ? result.away_goals : result.home_goals
			if gf > ga:
				form.append(3)  # Win
			elif gf == ga:
				form.append(1)  # Draw
			else:
				form.append(0)  # Loss
			if form.size() >= last_n:
				break
	return form.reverse()

func get_next_fixture(team_id: String, current_date: Dictionary) -> Dictionary:
	for fixture in fixtures:
		if (fixture.home_id == team_id or fixture.away_id == team_id) and not fixture.played:
			var fixture_date = fixture.date
			if _date_compare(fixture_date, current_date) >= 0:
				return fixture
	return {}

func get_previous_result(team_id: String, current_date: Dictionary) -> Dictionary:
	for i in range(results.size() - 1, -1, -1):
		var result = results[i]
		if result.home_id == team_id or result.away_id == team_id:
			var result_date = result.date
			if _date_compare(result_date, current_date) < 0:
				return result
	return {}

func _date_compare(date1: Dictionary, date2: Dictionary) -> int:
	if date1.year != date2.year:
		return date1.year - date2.year
	if date1.month != date2.month:
		return date1.month - date2.month
	return date1.day - date2.day

# Serialize for saving
func to_dict() -> Dictionary:
	var dict = {}
	var props = get_property_list()
	for prop in props:
		var name = prop.name
		if name.begins_with("_"):
			continue
		dict[name] = get(name)
	return dict

func from_dict(dict: Dictionary):
	for key, value in dict:
		if hasattr(key):
			set(key, value)