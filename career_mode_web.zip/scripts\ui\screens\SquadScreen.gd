extends VBoxContainer
class_name SquadScreen

# =============================================================================
# UI REFERENCES
# =============================================================================

@onready var filter_position: OptionButton = $Toolbar/FilterPosition
@onready var filter_status: OptionButton = $Toolbar/FilterStatus
@onready var search_box: LineEdit = $Toolbar/SearchBox
@onready var sort_by: OptionButton = $Toolbar/SortBy
@onready var list_view_button: Button = $Toolbar/ListViewButton
@onready var grid_view_button: Button = $Toolbar/GridViewButton
@onready var player_list: VBoxContainer = $Content/PlayerListContainer/PlayerList
@onready var player_detail_panel: PanelContainer = $Content/PlayerDetailPanel
@onready var player_detail_content: VBoxContainer = $Content/PlayerDetailPanel/PlayerDetailContent
@onready var no_selection_label: Label = $Content/PlayerDetailPanel/PlayerDetailContent/NoSelectionLabel

# =============================================================================
# STATE
# =============================================================================

var current_players: Array[PlayerData] = []
var selected_player: PlayerData = null
var player_cards: Array[Control] = []
var view_mode: String = "grid"  # "list" or "grid"

# =============================================================================
# INITIALIZATION
# =============================================================================

func _ready():
	_setup_filters()
	_connect_signals()
	_refresh_squad()

func _setup_filters():
	# Position filter
	filter_position.add_item("All Positions", -1)
	for pos_id in [GameEnums.Position.GK, GameEnums.Position.DR, GameEnums.Position.DCR, GameEnums.Position.DCL, GameEnums.Position.DL,
	               GameEnums.Position.DM, GameEnums.Position.MR, GameEnums.Position.MC, GameEnums.Position.ML,
	               GameEnums.Position.AMR, GameEnums.Position.AMC, GameEnums.Position.AML, GameEnums.Position.STR]:
		filter_position.add_item(GameEnums.get_position_short(pos_id), pos_id)

	# Squad status filter
	filter_status.add_item("All", -1)
	for status_id in [GameEnums.SquadStatus.KEY_PLAYER, GameEnums.SquadStatus.FIRST_TEAM, GameEnums.SquadStatus.ROTATION,
	                  GameEnums.SquadStatus.BACKUP, GameEnums.SquadStatus.HOT_PROSPECT, GameEnums.SquadStatus.YOUTH_PLAYER]:
		filter_status.add_item(GameEnums.SQUAD_STATUS_NAMES[status_id], status_id)

	# Sort options
	sort_by.add_item("Name", 0)
	sort_by.add_item("Position", 1)
	sort_by.add_item("CA", 2)
	sort_by.add_item("PA", 3)
	sort_by.add_item("Age", 4)
	sort_by.add_item("Value", 5)
	sort_by.add_item("Wage", 6)
	sort_by.add_item("Contract", 7)

func _connect_signals():
	filter_position.item_selected.connect(_on_filter_changed)
	filter_status.item_selected.connect(_on_filter_changed)
	search_box.text_changed.connect(_on_filter_changed)
	sort_by.item_selected.connect(_on_filter_changed)
	list_view_button.toggled.connect(_on_view_mode_changed.bind("list"))
	grid_view_button.toggled.connect(_on_view_mode_changed.bind("grid"))

func on_show():
	_refresh_squad()

# =============================================================================
# SQUAD MANAGEMENT
# =============================================================================

func _refresh_squad():
	var club = GameState.instance.get_current_club()
	if not club:
		return

	# Get all players for this club
	current_players.clear()
	for pid in club.player_ids:
		var player = Database.instance.get_player(pid)
		if player:
			current_players.append(player)

	_apply_filters_and_sort()
	_render_player_list()

func _apply_filters_and_sort():
	var filtered = current_players.duplicate()

	# Position filter
	var pos_filter = filter_position.get_item_id(filter_position.selected)
	if pos_filter != -1:
		filtered = filtered.filter(func(p): return p.primary_position == pos_filter)

	# Status filter
	var status_filter = filter_status.get_item_id(filter_status.selected)
	if status_filter != -1:
		filtered = filtered.filter(func(p): return p.squad_status == status_filter)

	# Search filter
	var search = search_box.text.to_lower().strip_edges()
	if search != "":
		filtered = filtered.filter(func(p):
			return p.first_name.to_lower().contains(search) or
			       p.last_name.to_lower().contains(search) or
			       (p.common_name != "" and p.common_name.to_lower().contains(search))
		)

	# Sort
	var sort_id = sort_by.get_item_id(sort_by.selected)
	match sort_id:
		0: filtered.sort_custom(self, "_compare_name")
		1: filtered.sort_custom(self, "_compare_position")
		2: filtered.sort_custom(self, "_compare_ca")
		3: filtered.sort_custom(self, "_compare_pa")
		4: filtered.sort_custom(self, "_compare_age")
		5: filtered.sort_custom(self, "_compare_value")
		6: filtered.sort_custom(self, "_compare_wage")
		7: filtered.sort_custom(self, "_compare_contract")

	current_players = filtered

func _render_player_list():
	# Clear existing
	for card in player_cards:
		card.queue_free()
	player_cards.clear()

	if view_mode == "grid":
		_render_grid()
	else:
		_render_list()

func _render_grid():
	# Create grid container
	var grid = GridContainer.new()
	grid.columns = 3
	grid.column_spacing = 10
	grid.row_spacing = 10
	player_list.add_child(grid)

	for player in current_players:
		var card = _create_player_card(player, true)
		grid.add_child(card)
		player_cards.append(card)

func _render_list():
	for player in current_players:
		var card = _create_player_card(player, false)
		player_list.add_child(card)
		player_cards.append(card)

func _create_player_card(player: PlayerData, compact: bool) -> Control:
	var card_scene = ResourceLoader.load("res://scenes/ui/components/PlayerCard.tscn")
	if not card_scene:
		return Label.new()

	var card = card_scene.instantiate()
	if card.has_method("setup"):
		card.setup(player, compact)
	if card.has_method("selected"):
		card.selected.connect(_on_player_selected.bind(player))

	return card

func _on_player_selected(player: PlayerData):
	selected_player = player
	_show_player_details(player)

func _show_player_details(player: PlayerData):
	# Clear existing detail content
	for child in player_detail_content.get_children():
		if child != no_selection_label:
			child.queue_free()

	no_selection_label.visible = false

	# Create detail view
	var detail = _create_player_detail(player)
	player_detail_content.add_child(detail)

func _create_player_detail(player: PlayerData) -> Control:
	var container = VBoxContainer.new()
	container.theme_override_constants.separation = 10

	# Header
	var header = HBoxContainer.new()
	header.theme_override_constants.separation = 15

	var name = Label.new()
	name.text = "%s %s" % [player.first_name, player.last_name]
	if player.common_name != "":
		name.text = player.common_name
	name.theme_override_font_sizes.font_size = 24
	name.horizontal_alignment = 0
	header.add_child(name)

	var pos_label = Label.new()
	pos_label.text = "%s • %d yrs" % [GameEnums.get_position_short(player.primary_position), player.get_age()]
	pos_label.theme_override_font_sizes.font_size = 14
	pos_label.add_theme_color_override("font_color", Color(0.7, 0.7, 0.7))
	pos_label.vertical_alignment = 1
	header.add_child(pos_label)

	container.add_child(header)

	# Attributes
	var attr_section = _create_attribute_section(player)
	container.add_child(attr_section)

	# Contract info
	var contract_section = _create_contract_section(player)
	container.add_child(contract_section)

	# Actions
	var actions = HBoxContainer.new()
	actions.theme_override_constants.separation = 10

	var train_btn = Button.new()
	train_btn.text = "Training"
	train_btn.custom_minimum_size = Vector2(120, 36)
	actions.add_child(train_btn)

	var transfer_btn = Button.new()
	transfer_btn.text = "Transfer List"
	transfer_btn.custom_minimum_size = Vector2(120, 36)
	actions.add_child(transfer_btn)

	var contract_btn = Button.new()
	contract_btn.text = "New Contract"
	contract_btn.custom_minimum_size = Vector2(120, 36)
	actions.add_child(contract_btn)

	container.add_child(actions)

	return container

func _create_attribute_section(player: PlayerData) -> Control:
	var panel = PanelContainer.new()
	panel.theme_override_constants.panel_margin_left = 10
	panel.theme_override_constants.panel_margin_top = 10
	panel.theme_override_constants.panel_margin_right = 10
	panel.theme_override_constants.panel_margin_bottom = 10

	var content = VBoxContainer.new()
	content.theme_override_constants.separation = 5

	var title = Label.new()
	title.text = "KEY ATTRIBUTES"
	title.theme_override_font_sizes.font_size = 14
	title.add_theme_color_override("font_color", Color(0.8, 0.8, 0.8))
	content.add_child(title)

	var key_attrs = GameEnums._get_key_attributes_for_role(player.preferred_roles.get(player.primary_position, 0))
	if key_attrs.is_empty():
		key_attrs = GameEnums._get_key_attributes_for_role(0)  # Generic

	var grid = GridContainer.new()
	grid.columns = 3
	grid.column_spacing = 15
	grid.row_spacing = 5

	for attr in key_attrs:
		var value = player.get_attribute(attr)
		var attr_container = VBoxContainer.new()
		attr_container.theme_override_constants.separation = 2

		var attr_name = Label.new()
		attr_name.text = attr.capitalize().replace("_", " ")
		attr_name.theme_override_font_sizes.font_size = 11
		attr_name.horizontal_alignment = 1
		attr_name.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
		attr_container.add_child(attr_name)

		var attr_value = Label.new()
		attr_value.text = str(value)
		attr_value.theme_override_font_sizes.font_size = 18
		attr_value.horizontal_alignment = 1
		attr_value.add_theme_color_override("font_color", _get_attribute_color(value))
		attr_container.add_child(attr_value)

		grid.add_child(attr_container)

	content.add_child(grid)
	panel.add_child(content)
	return panel

func _create_contract_section(player: PlayerData) -> Control:
	var panel = PanelContainer.new()
	panel.theme_override_constants.panel_margin_left = 10
	panel.theme_override_constants.panel_margin_top = 10
	panel.theme_override_constants.panel_margin_right = 10
	panel.theme_override_constants.panel_margin_bottom = 10

	var content = VBoxContainer.new()
	content.theme_override_constants.separation = 5

	var title = Label.new()
	title.text = "CONTRACT"
	title.theme_override_font_sizes.font_size = 14
	title.add_theme_color_override("font_color", Color(0.8, 0.8, 0.8))
	content.add_child(title)

	var grid = GridContainer.new()
	grid.columns = 2
	grid.column_spacing = 20
	grid.row_spacing = 5

	var contract_info = [
		["Expires", _format_contract_date(player.contract_end_date)],
		["Years Left", "%.1f" % player.get_contract_years_remaining()],
		["Wage", "%s/week" % _format_currency(player.wage)],
		["Status", GameEnums.SQUAD_STATUS_NAMES[player.squad_status]],
		["Release Clause", _format_currency(player.release_clause) if player.release_clause > 0 else "None"],
	]

	for info in contract_info:
		var label = Label.new()
		label.text = info[0]
		label.theme_override_font_sizes.font_size = 12
		label.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
		grid.add_child(label)

		var value = Label.new()
		value.text = info[1]
		value.theme_override_font_sizes.font_size = 12
		value.horizontal_alignment = 2
		grid.add_child(value)

	content.add_child(grid)
	panel.add_child(content)
	return panel

func _get_attribute_color(value: int) -> Color:
	if value >= 17: return Color(0.9, 0.3, 0.3)      # Red - Elite
	if value >= 15: return Color(0.9, 0.7, 0.2)      # Gold - World class
	if value >= 13: return Color(0.4, 0.8, 0.4)      # Green - Excellent
	if value >= 11: return Color(0.4, 0.7, 0.9)      # Blue - Good
	if value >= 9: return Color(0.7, 0.7, 0.7)       # Grey - Average
	return Color(0.6, 0.6, 0.6)                      # Dark grey - Poor

func _format_currency(amount: int) -> String:
	var abs_amount = abs(amount)
	if abs_amount >= 1000000:
		return "£%.1fM" % (amount / 1000000.0)
	elif abs_amount >= 1000:
		return "£%.0fK" % (amount / 1000.0)
	else:
		return "£%d" % amount

func _format_contract_date(date_dict: Dictionary) -> String:
	if not date_dict or date_dict == {}:
		return "N/A"
	return "%d %s %d" % [date_dict.day, _get_month_name(date_dict.month), date_dict.year]

func _get_month_name(month: int) -> String:
	var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
	return months[month - 1]

# =============================================================================
# COMPARISON FUNCTIONS
# =============================================================================

func _compare_name(a: PlayerData, b: PlayerData) -> int:
	return a.last_name.compare_to(b.last_name)

func _compare_position(a: PlayerData, b: PlayerData) -> int:
	return a.primary_position - b.primary_position

func _compare_ca(a: PlayerData, b: PlayerData) -> int:
	return b.current_ability - a.current_ability

func _compare_pa(a: PlayerData, b: PlayerData) -> int:
	return b.potential_ability - a.potential_ability

func _compare_age(a: PlayerData, b: PlayerData) -> int:
	return a.get_age() - b.get_age()

func _compare_value(a: PlayerData, b: PlayerData) -> int:
	var va = _estimate_value(a)
	var vb = _estimate_value(b)
	return vb - va

func _compare_wage(a: PlayerData, b: PlayerData) -> int:
	return b.wage - a.wage

func _compare_contract(a: PlayerData, b: PlayerData) -> int:
	return a.get_contract_years_remaining() - b.get_contract_years_remaining()

func _estimate_value(player: PlayerData) -> int:
	var club = Database.instance.get_team(player.club_id)
	if club:
		return club.estimate_player_value(player)
	return 0

# =============================================================================
# EVENT HANDLERS
# =============================================================================

func _on_filter_changed(_dummy = null):
	_apply_filters_and_sort()
	_render_player_list()

func _on_view_mode_changed(mode: String, pressed: bool):
	if pressed:
		view_mode = mode
		_render_player_list()