extends Node
class_name Database

# Singleton instance
static var instance: Database = null

# =============================================================================
# DATA STORAGE
# =============================================================================
var players: Dictionary = {}      # id -> PlayerData
var teams: Dictionary = {}        # id -> TeamData
var competitions: Dictionary = {} # id -> CompetitionData
var staff: Dictionary = {}        # id -> StaffData

# Indexes for fast lookup
var players_by_nationality: Dictionary = {}
var players_by_club: Dictionary = {}
var players_by_position: Dictionary = {}
var free_agents: Array[String] = []
var transfer_listed_players: Array[String] = []

# Name databases for regen generation
var first_names_by_nationality: Dictionary = {}
var last_names_by_nationality: Dictionary = {}

# =============================================================================
# INITIALIZATION
# =============================================================================

func _ready():
	instance = self
	_load_all_data()

func _load_all_data():
	print("Loading database...")
	_load_names()
	_load_competitions()
	_load_teams()
	_load_players()
	_load_staff()
	_build_indexes()
	print("Database loaded: %d players, %d teams, %d competitions, %d staff" % [players.size(), teams.size(), competitions.size(), staff.size()])

func _load_names():
	# Load from JSON files
	var first_names_file = FileAccess.open("res://resources/database/first_names.json", FileAccess.READ)
	if first_names_file:
		var data = JSON.parse_string(first_names_file.get_as_text())
		if data.error == OK:
			first_names_by_nationality = data.value
		first_names_file.close()
	else:
		# Generate default names if file doesn't exist
		_generate_default_names()

	var last_names_file = FileAccess.open("res://resources/database/last_names.json", FileAccess.READ)
	if last_names_file:
		var data = JSON.parse_string(last_names_file.get_as_text())
		if data.error == OK:
			last_names_by_nationality = data.value
		last_names_file.close()

func _generate_default_names():
	# Basic fallback names by nationality
	first_names_by_nationality = {
		"England": ["James", "Harry", "Oliver", "Jack", "George", "Thomas", "William", "Charlie", "Daniel", "Michael"],
		"Spain": ["Alejandro", "Carlos", "David", "Javier", "Miguel", "Pablo", "Sergio", "Adrian", "Diego", "Raul"],
		"Germany": ["Thomas", "Michael", "Daniel", "Alexander", "Stefan", "Christian", "Markus", "Andreas", "Martin", "Kevin"],
		"Italy": ["Marco", "Luca", "Alessandro", "Matteo", "Andrea", "Francesco", "Antonio", "Giovanni", "Davide", "Riccardo"],
		"France": ["Nicolas", "Alexandre", "Thomas", "Lucas", "Hugo", "Louis", "Antoine", "Maxime", "Nathan", "Enzo"],
		"Portugal": ["João", "Miguel", "Tiago", "Rui", "Pedro", "André", "Ricardo", "Bruno", "Fábio", "Diogo"],
		"Brazil": ["Lucas", "Gabriel", "Matheus", "Felipe", "Rafael", "Guilherme", "Pedro", "Bruno", "Diego", "Thiago"],
		"Argentina": ["Lautaro", "Julián", "Enzo", "Nicolás", "Facundo", "Rodrigo", "Franco", "Lucas", "Matías", "Agustín"],
		"Netherlands": ["Noah", "Daan", "Sem", "Luuk", "Milan", "Levi", "Finn", "Stijn", "Jesse", "Mees"],
		"Belgium": ["Louis", "Arthur", "Victor", "Lucas", "Noah", "Adam", "Liam", "Jules", "Nathan", "Gabriel"],
	}
	last_names_by_nationality = {
		"England": ["Smith", "Jones", "Williams", "Brown", "Taylor", "Davies", "Wilson", "Evans", "Thomas", "Johnson"],
		"Spain": ["García", "Rodríguez", "González", "Fernández", "López", "Martínez", "Sánchez", "Pérez", "Gómez", "Martín"],
		"Germany": ["Müller", "Schmidt", "Schneider", "Fischer", "Weber", "Meyer", "Wagner", "Becker", "Schulz", "Hoffmann"],
		"Italy": ["Rossi", "Russo", "Ferrari", "Esposito", "Bianchi", "Romano", "Colombo", "Ricci", "Marino", "Greco"],
		"France": ["Martin", "Bernard", "Dubois", "Thomas", "Robert", "Richard", "Petit", "Durand", "Leroy", "Moreau"],
		"Portugal": ["Silva", "Santos", "Ferreira", "Pereira", "Oliveira", "Costa", "Rodrigues", "Martins", "Jesus", "Sousa"],
		"Brazil": ["Silva", "Santos", "Oliveira", "Souza", "Rodrigues", "Ferreira", "Alves", "Pereira", "Lima", "Gomes"],
		"Argentina": ["González", "Rodríguez", "Gómez", "Fernández", "López", "Martínez", "Díaz", "Pérez", "Sánchez", "Romero"],
		"Netherlands": ["De Jong", "De Vries", "Van Dijk", "Van den Berg", "Van der Meer", "Bakker", "Jansen", "Visser", "Smit", "Meijer"],
		"Belgium": ["Peeters", "Janssens", "Maes", "Jacobs", "Mertens", "Willems", "Claes", "Goossens", "Wouters", "De Smet"],
	}

func _load_competitions():
	var file = FileAccess.open("res://resources/database/competitions.json", FileAccess.READ)
	if file:
		var data = JSON.parse_string(file.get_as_text())
		if data.error == OK:
			for comp_dict in data.value:
				var comp = CompetitionData.new()
				comp.from_dict(comp_dict)
				competitions[comp.id] = comp
		file.close()
	else:
		_generate_default_competitions()

func _generate_default_competitions():
	# Create major European leagues
	var leagues = [
		{"id": "eng_premier_league", "name": "Premier League", "short": "PL", "country": "England", "type": GameEnums.CompetitionType.LEAGUE, "rep": 9500, "teams": 20, "promo": 0, "releg": 3},
		{"id": "esp_la_liga", "name": "La Liga", "short": "LL", "country": "Spain", "type": GameEnums.CompetitionType.LEAGUE, "rep": 9200, "teams": 20, "promo": 0, "releg": 3},
		{"id": "ger_bundesliga", "name": "Bundesliga", "short": "BL", "country": "Germany", "type": GameEnums.CompetitionType.LEAGUE, "rep": 9000, "teams": 18, "promo": 0, "releg": 2},
		{"id": "ita_serie_a", "name": "Serie A", "short": "SA", "country": "Italy", "type": GameEnums.CompetitionType.LEAGUE, "rep": 8800, "teams": 20, "promo": 0, "releg": 3},
		{"id": "fra_ligue_1", "name": "Ligue 1", "short": "L1", "country": "France", "type": GameEnums.CompetitionType.LEAGUE, "rep": 8500, "teams": 18, "promo": 0, "releg": 2},
		{"id": "por_primeira", "name": "Primeira Liga", "short": "PL", "country": "Portugal", "type": GameEnums.CompetitionType.LEAGUE, "rep": 7500, "teams": 18, "promo": 0, "releg": 2},
		{"id": "ned_eredivisie", "name": "Eredivisie", "short": "ED", "country": "Netherlands", "type": GameEnums.CompetitionType.LEAGUE, "rep": 7300, "teams": 18, "promo": 0, "releg": 2},
	]

	for l in leagues:
		var comp = CompetitionData.new()
		comp.id = l.id
		comp.name = l.name
		comp.short_name = l.short
		comp.country = l.country
		comp.type = l.type
		comp.reputation = l.rep
		comp.number_of_teams = l.teams
		comp.promotion_spots = l.promo
		comp.relegation_spots = l.releg
		comp.points_for_win = 3
		comp.points_for_draw = 1
		comp.squad_size_limit = 25
		comp.start_month = 8
		comp.end_month = 5
		comp.match_days = [5, 6]  # Sat, Sun
		competitions[comp.id] = comp

	# Champions League
	var ucl = CompetitionData.new()
	ucl.id = "uefa_champions_league"
	ucl.name = "UEFA Champions League"
	ucl.short_name = "UCL"
	ucl.type = GameEnums.CompetitionType.CONTINENTAL_LEAGUE
	ucl.continent = "Europe"
	ucl.reputation = 9800
	ucl.group_stage_teams = 36
	ucl.knockout_teams = 16
	ucl.group_size = 4
	ucl.start_month = 9
	ucl.end_month = 5
	competitions[ucl.id] = ucl

	# Europa League
	var uel = CompetitionData.new()
	uel.id = "uefa_europa_league"
	uel.name = "UEFA Europa League"
	uel.short_name = "UEL"
	uel.type = GameEnums.CompetitionType.CONTINENTAL_LEAGUE
	uel.continent = "Europe"
	uel.reputation = 8000
	uel.group_stage_teams = 36
	uel.knockout_teams = 16
	uel.group_size = 4
	competitions[uel.id] = uel

func _load_teams():
	var file = FileAccess.open("res://resources/database/teams.json", FileAccess.READ)
	if file:
		var data = JSON.parse_string(file.get_as_text())
		if data.error == OK:
			for team_dict in data.value:
				var team = TeamData.new()
				team.from_dict(team_dict)
				teams[team.id] = team
		file.close()
	else:
		_generate_default_teams()

func _generate_default_teams():
	# Create teams for each league
	var league_teams = {
		"eng_premier_league": [
			{"id": "arsenal", "name": "Arsenal", "short": "ARS", "rep": 8500, "stadium": "Emirates Stadium", "capacity": 60704, "colors": [Color(0.7, 0.0, 0.0), Color(1.0, 1.0, 1.0)]},
			{"id": "chelsea", "name": "Chelsea", "short": "CHE", "rep": 8700, "stadium": "Stamford Bridge", "capacity": 40341, "colors": [Color(0.0, 0.2, 0.6), Color(1.0, 1.0, 1.0)]},
			{"id": "liverpool", "name": "Liverpool", "short": "LIV", "rep": 9000, "stadium": "Anfield", "capacity": 53394, "colors": [Color(0.8, 0.0, 0.0), Color(1.0, 1.0, 1.0)]},
			{"id": "man_city", "name": "Manchester City", "short": "MCI", "rep": 9200, "stadium": "Etihad Stadium", "capacity": 53400, "colors": [Color(0.3, 0.6, 0.9), Color(1.0, 1.0, 1.0)]},
			{"id": "man_utd", "name": "Manchester United", "short": "MUN", "rep": 9000, "stadium": "Old Trafford", "capacity": 74310, "colors": [Color(0.8, 0.0, 0.0), Color(1.0, 1.0, 1.0)]},
			{"id": "tottenham", "name": "Tottenham", "short": "TOT", "rep": 8200, "stadium": "Tottenham Hotspur Stadium", "capacity": 62850, "colors": [Color(1.0, 1.0, 1.0), Color(0.0, 0.2, 0.6)]},
			{"id": "newcastle", "name": "Newcastle", "short": "NEW", "rep": 7800, "stadium": "St James' Park", "capacity": 52305, "colors": [Color(0.0, 0.0, 0.0), Color(1.0, 1.0, 1.0)]},
			{"id": "brighton", "name": "Brighton", "short": "BHA", "rep": 7200, "stadium": "Amex Stadium", "capacity": 31876, "colors": [Color(0.0, 0.3, 0.7), Color(1.0, 1.0, 1.0)]},
			{"id": "aston_villa", "name": "Aston Villa", "short": "AVL", "rep": 7500, "stadium": "Villa Park", "capacity": 42785, "colors": [Color(0.5, 0.0, 0.5), Color(0.5, 0.5, 0.0)]},
			{"id": "west_ham", "name": "West Ham", "short": "WHU", "rep": 7300, "stadium": "London Stadium", "capacity": 62500, "colors": [Color(0.5, 0.0, 0.0), Color(0.0, 0.5, 0.0)]},
		],
		"esp_la_liga": [
			{"id": "real_madrid", "name": "Real Madrid", "short": "RMA", "rep": 9500, "stadium": "Santiago Bernabéu", "capacity": 81044, "colors": [Color(1.0, 1.0, 1.0), Color(0.0, 0.2, 0.6)]},
			{"id": "barcelona", "name": "Barcelona", "short": "BAR", "rep": 9300, "stadium": "Camp Nou", "capacity": 99354, "colors": [Color(0.5, 0.0, 0.5), Color(0.0, 0.0, 0.8)]},
			{"id": "atletico", "name": "Atlético Madrid", "short": "ATM", "rep": 8500, "stadium": "Wanda Metropolitano", "capacity": 68456, "colors": [Color(0.8, 0.0, 0.0), Color(1.0, 1.0, 1.0)]},
			{"id": "sevilla", "name": "Sevilla", "short": "SEV", "rep": 7800, "stadium": "Ramón Sánchez Pizjuán", "capacity": 43883, "colors": [Color(0.8, 0.0, 0.0), Color(1.0, 1.0, 1.0)]},
			{"id": "valencia", "name": "Valencia", "short": "VAL", "rep": 7500, "stadium": "Mestalla", "capacity": 49430, "colors": [Color(1.0, 0.8, 0.0), Color(0.0, 0.0, 0.0)]},
		],
		"ger_bundesliga": [
			{"id": "bayern", "name": "Bayern Munich", "short": "BAY", "rep": 9300, "stadium": "Allianz Arena", "capacity": 75024, "colors": [Color(0.8, 0.0, 0.0), Color(1.0, 1.0, 1.0)]},
			{"id": "dortmund", "name": "Borussia Dortmund", "short": "BVB", "rep": 8500, "stadium": "Signal Iduna Park", "capacity": 81365, "colors": [Color(1.0, 1.0, 0.0), Color(0.0, 0.0, 0.0)]},
			{"id": "leipzig", "name": "RB Leipzig", "short": "RBL", "rep": 8000, "stadium": "Red Bull Arena", "capacity": 47069, "colors": [Color(1.0, 1.0, 1.0), Color(0.8, 0.0, 0.0)]},
			{"id": "leverkusen", "name": "Bayer Leverkusen", "short": "B04", "rep": 7800, "stadium": "BayArena", "capacity": 30210, "colors": [Color(0.8, 0.0, 0.0), Color(0.0, 0.0, 0.0)]},
		],
		"ita_serie_a": [
			{"id": "inter", "name": "Inter Milan", "short": "INT", "rep": 8800, "stadium": "San Siro", "capacity": 75923, "colors": [Color(0.0, 0.0, 0.8), Color(0.0, 0.0, 0.0)]},
			{"id": "milan", "name": "AC Milan", "short": "MIL", "rep": 8600, "stadium": "San Siro", "capacity": 75923, "colors": [Color(0.8, 0.0, 0.0), Color(0.0, 0.0, 0.0)]},
			{"id": "juventus", "name": "Juventus", "short": "JUV", "rep": 8800, "stadium": "Allianz Stadium", "capacity": 41507, "colors": [Color(0.0, 0.0, 0.0), Color(1.0, 1.0, 1.0)]},
			{"id": "napoli", "name": "Napoli", "short": "NAP", "rep": 8200, "stadium": "Stadio Diego Armando Maradona", "capacity": 54726, "colors": [Color(0.0, 0.5, 0.8), Color(1.0, 1.0, 1.0)]},
			{"id": "roma", "name": "Roma", "short": "ROM", "rep": 8000, "stadium": "Stadio Olimpico", "capacity": 70634, "colors": [Color(0.5, 0.0, 0.0), Color(1.0, 0.8, 0.0)]},
			{"id": "lazio", "name": "Lazio", "short": "LAZ", "rep": 7500, "stadium": "Stadio Olimpico", "capacity": 70634, "colors": [Color(0.0, 0.3, 0.7), Color(1.0, 1.0, 1.0)]},
		],
		"fra_ligue_1": [
			{"id": "psg", "name": "Paris Saint-Germain", "short": "PSG", "rep": 9000, "stadium": "Parc des Princes", "capacity": 47929, "colors": [Color(0.0, 0.2, 0.6), Color(0.8, 0.0, 0.0)]},
			{"id": "marseille", "name": "Marseille", "short": "MAR", "rep": 7800, "stadium": "Stade Vélodrome", "capacity": 67394, "colors": [Color(1.0, 1.0, 1.0), Color(0.0, 0.3, 0.7)]},
			{"id": "lyon", "name": "Lyon", "short": "LYO", "rep": 7500, "stadium": "Groupama Stadium", "capacity": 59186, "colors": [Color(0.0, 0.0, 0.8), Color(1.0, 1.0, 1.0)]},
			{"id": "monaco", "name": "Monaco", "short": "MON", "rep": 7300, "stadium": "Stade Louis II", "capacity": 18523, "colors": [Color(0.8, 0.0, 0.0), Color(1.0, 1.0, 1.0)]},
		],
	}

	for league_id, team_list in league_teams:
		for t in team_list:
			var team = TeamData.new()
			team.id = t.id
			team.name = t.name
			team.short_name = t.short
			team.nationality = competitions[league_id].country
			team.reputation = t.rep
			team.stadium_name = t.stadium
			team.stadium_capacity = t.capacity
			team.primary_color = t.colors[0]
			team.secondary_color = t.colors[1]
			team.competition_id = league_id
			team.transfer_budget = 50000000
			team.wage_budget = 2000000
			team.balance = 10000000
			team.training_facilities_level = 15
			team.youth_facilities_level = 15
			team.youth_recruitment_level = 15
			teams[team.id] = team

		# Add team IDs to competition
		var comp = competitions[league_id]
		for t in team_list:
			comp.team_ids.append(t.id)

func _load_players():
	var file = FileAccess.open("res://resources/database/players.json", FileAccess.READ)
	if file:
		var data = JSON.parse_string(file.get_as_text())
		if data.error == OK:
			for player_dict in data.value:
				var player = PlayerData.new()
				player.from_dict(player_dict)
				players[player.id] = player
		file.close()
	else:
		_generate_default_players()

func _generate_default_players():
	# Generate players for each team
	for team_id in teams:
		var team = teams[team_id]
		_generate_squad_for_team(team)

func _generate_squad_for_team(team: TeamData):
	var squad_size = 25
	var positions_needed = {
		GameEnums.Position.GK: 3,
		GameEnums.Position.DR: 2, GameEnums.Position.DCR: 4, GameEnums.Position.DCL: 0, GameEnums.Position.DL: 2,
		GameEnums.Position.DM: 2,
		GameEnums.Position.MR: 2, GameEnums.Position.MC: 4, GameEnums.Position.ML: 2,
		GameEnums.Position.AMR: 1, GameEnums.Position.AMC: 2, GameEnums.Position.AML: 1,
		GameEnums.Position.STR: 3,
	}

	# Adjust based on reputation - better teams get better players
	var rep_factor = team.reputation / 10000.0

	for pos, count in positions_needed:
		for i in range(count):
			var player = _create_player_for_position(pos, team, rep_factor)
			players[player.id] = player
			team.player_ids.append(player.id)

func _create_player_for_position(position: int, team: TeamData, rep_factor: float) -> PlayerData:
	var player = PlayerData.new()
	player.id = "%s_%s_%d" % [team.id, GameEnums.get_position_short(position).to_lower(), players.size()]
	player.first_name = _get_random_first_name(team.nationality)
	player.last_name = _get_random_last_name(team.nationality)
	player.nationality = team.nationality
	player.date_of_birth = _generate_birth_date(16, 36)
	player.preferred_foot = randi() % 3

	# Set primary position
	player.primary_position = position

	# Generate attributes based on position and team reputation
	_generate_attributes_for_position(player, position, rep_factor)

	# CA/PA based on team reputation and age
	var age = player.get_age()
	var base_ca = int(60 + rep_factor * 80 + (randf_range(-10, 10)))
	var base_pa = int(base_ca + randf_range(5, 30))
	player.current_ability = clamp(base_ca, 40, 190)
	player.potential_ability = clamp(base_pa, player.current_ability, 200)

	# Contract
	player.club_id = team.id
	player.contract_type = GameEnums.ContractType.PERMANENT
	player.contract_start_date = GameState.get_current_date()
	player.contract_end_date = _add_years_to_date(GameState.get_current_date(), randi_range(1, 5))
	player.wage = _calculate_wage(player.current_ability, age, rep_factor)
	player.squad_status = _determine_squad_status(player.current_ability, age, rep_factor)
	player.release_clause = player.wage * 52 * randi_range(3, 10)

	# Hidden attributes
	player.professionalism = randi_range(5, 20)
	player.ambition = randi_range(5, 20)
	player.loyalty = randi_range(5, 20)
	player.determination = randi_range(5, 20)
	player.consistency = randi_range(5, 20)
	player.injury_proneness = randi_range(5, 20)

	# Dynamic state
	player.morale = randi_range(40, 80)
	player.condition = 100
	player.match_sharpness = randi_range(50, 90)

	return player

func _generate_attributes_for_position(player: PlayerData, position: int, rep_factor: float):
	var base = 5 + int(rep_factor * 12)  # 5-17 base
	var variance = 4

	# Technical
	player.crossing = _attr(base, variance)
	player.finishing = _attr(base, variance)
	player.heading = _attr(base, variance)
	player.long_shots = _attr(base, variance)
	player.marking = _attr(base, variance)
	player.passing = _attr(base, variance)
	player.penalty_taking = _attr(base, variance)
	player.tackling = _attr(base, variance)
	player.technique = _attr(base, variance)

	# Mental
	player.anticipation = _attr(base, variance)
	player.composure = _attr(base, variance)
	player.concentration = _attr(base, variance)
	player.decisions = _attr(base, variance)
	player.determination = _attr(base, variance)
	player.flair = _attr(base, variance)
	player.leadership = _attr(base, variance)
	player.off_the_ball = _attr(base, variance)
	player.positioning = _attr(base, variance)
	player.teamwork = _attr(base, variance)
	player.vision = _attr(base, variance)
	player.work_rate = _attr(base, variance)

	# Physical
	player.acceleration = _attr(base, variance)
	player.agility = _attr(base, variance)
	player.balance = _attr(base, variance)
	player.jumping = _attr(base, variance)
	player.natural_fitness = _attr(base, variance)
	player.pace = _attr(base, variance)
	player.stamina = _attr(base, variance)
	player.strength = _attr(base, variance)

	# Goalkeeping
	player.aerial_reach = _attr(base, variance)
	player.command_of_area = _attr(base, variance)
	player.communication = _attr(base, variance)
	player.eccentricity = _attr(base, variance)
	player.handling = _attr(base, variance)
	player.kicking = _attr(base, variance)
	player.one_on_ones = _attr(base, variance)
	player.reflexes = _attr(base, variance)
	player.rushing_out = _attr(base, variance)
	player.throwing = _attr(base, variance)

	# Boost key attributes for position
	_boost_position_attributes(player, position, rep_factor)

func _attr(base: int, variance: int) -> int:
	return clamp(base + randi_range(-variance, variance), 1, 20)

func _boost_position_attributes(player: PlayerData, position: int, rep_factor: float):
	var boost = int(3 + rep_factor * 4)
	match position:
		GameEnums.Position.GK:
			player.reflexes = clamp(player.reflexes + boost, 1, 20)
			player.handling = clamp(player.handling + boost, 1, 20)
			player.one_on_ones = clamp(player.one_on_ones + boost, 1, 20)
			player.aerial_reach = clamp(player.aerial_reach + boost, 1, 20)
			player.communication = clamp(player.communication + boost, 1, 20)
		GameEnums.Position.DCR, GameEnums.Position.DCL:
			player.marking = clamp(player.marking + boost, 1, 20)
			player.tackling = clamp(player.tackling + boost, 1, 20)
			player.heading = clamp(player.heading + boost, 1, 20)
			player.positioning = clamp(player.positioning + boost, 1, 20)
			player.concentration = clamp(player.concentration + boost, 1, 20)
			player.strength = clamp(player.strength + boost, 1, 20)
		GameEnums.Position.DR, GameEnums.Position.DL:
			player.pace = clamp(player.pace + boost, 1, 20)
			player.acceleration = clamp(player.acceleration + boost, 1, 20)
			player.crossing = clamp(player.crossing + boost, 1, 20)
			player.stamina = clamp(player.stamina + boost, 1, 20)
			player.marking = clamp(player.marking + boost, 1, 20)
		GameEnums.Position.DM:
			player.tackling = clamp(player.tackling + boost, 1, 20)
			player.marking = clamp(player.marking + boost, 1, 20)
			player.positioning = clamp(player.positioning + boost, 1, 20)
			player.stamina = clamp(player.stamina + boost, 1, 20)
			player.passing = clamp(player.passing + boost, 1, 20)
		GameEnums.Position.MC:
			player.passing = clamp(player.passing + boost, 1, 20)
			player.vision = clamp(player.vision + boost, 1, 20)
			player.technique = clamp(player.technique + boost, 1, 20)
			player.stamina = clamp(player.stamina + boost, 1, 20)
			player.work_rate = clamp(player.work_rate + boost, 1, 20)
		GameEnums.Position.MR, GameEnums.Position.ML:
			player.pace = clamp(player.pace + boost, 1, 20)
			player.acceleration = clamp(player.acceleration + boost, 1, 20)
			player.crossing = clamp(player.crossing + boost, 1, 20)
			player.dribbling = clamp(player.dribbling + boost, 1, 20) if hasattr("dribbling") else null
			player.stamina = clamp(player.stamina + boost, 1, 20)
		GameEnums.Position.AMC, GameEnums.Position.AMR, GameEnums.Position.AML:
			player.passing = clamp(player.passing + boost, 1, 20)
			player.vision = clamp(player.vision + boost, 1, 20)
			player.technique = clamp(player.technique + boost, 1, 20)
			player.flair = clamp(player.flair + boost, 1, 20)
			player.off_the_ball = clamp(player.off_the_ball + boost, 1, 20)
		GameEnums.Position.STR:
			player.finishing = clamp(player.finishing + boost, 1, 20)
			player.off_the_ball = clamp(player.off_the_ball + boost, 1, 20)
			player.composure = clamp(player.composure + boost, 1, 20)
			player.anticipation = clamp(player.anticipation + boost, 1, 20)
			player.pace = clamp(player.pace + int(boost * 0.5), 1, 20)

func _get_random_first_name(nationality: String) -> String:
	var names = first_names_by_nationality.get(nationality, first_names_by_nationality["England"])
	return names.pick_random()

func _get_random_last_name(nationality: String) -> String:
	var names = last_names_by_nationality.get(nationality, last_names_by_nationality["England"])
	return names.pick_random()

func _generate_birth_date(min_age: int, max_age: int) -> Dictionary:
	var current = GameState.get_current_date()
	var age = randi_range(min_age, max_age)
	var year = current.year - age
	var month = randi_range(1, 12)
	var day = randi_range(1, 28)
	return {"year": year, "month": month, "day": day}

func _add_years_to_date(date: Dictionary, years: int) -> Dictionary:
	return {"year": date.year + years, "month": date.month, "day": date.day}

func _calculate_wage(ca: int, age: int, rep_factor: float) -> int:
	var base = ca * 1000
	var age_factor = 1.0
	if age < 21:
		age_factor = 0.7
	elif age < 24:
		age_factor = 0.9
	elif age > 30:
		age_factor = 0.8
	elif age > 32:
		age_factor = 0.6
	return int(base * age_factor * (0.5 + rep_factor))

func _determine_squad_status(ca: int, age: int, rep_factor: float) -> int:
	if ca > 160:
		return GameEnums.SquadStatus.KEY_PLAYER
	elif ca > 140:
		return GameEnums.SquadStatus.FIRST_TEAM
	elif ca > 120:
		return GameEnums.SquadStatus.ROTATION
	elif age <= 21 and ca > 100:
		return GameEnums.SquadStatus.HOT_PROSPECT
	elif age <= 21:
		return GameEnums.SquadStatus.YOUTH_PLAYER
	else:
		return GameEnums.SquadStatus.BACKUP

func _load_staff():
	var file = FileAccess.open("res://resources/database/staff.json", FileAccess.READ)
	if file:
		var data = JSON.parse_string(file.get_as_text())
		if data.error == OK:
			for staff_dict in data.value:
				var s = StaffData.new()
				s.from_dict(staff_dict)
				staff[s.id] = s
		file.close()
	else:
		_generate_default_staff()

func _generate_default_staff():
	# Generate staff for each team
	for team_id in teams:
		var team = teams[team_id]
		_generate_staff_for_team(team)

func _generate_staff_for_team(team: TeamData):
	var roles = [
		GameEnums.StaffRole.ASSISTANT_MANAGER,
		GameEnums.StaffRole.COACH_GK,
		GameEnums.StaffRole.COACH_DEFENCE,
		GameEnums.StaffRole.COACH_MIDFIELD,
		GameEnums.StaffRole.COACH_ATTACK,
		GameEnums.StaffRole.COACH_FITNESS,
		GameEnums.StaffRole.SCOUT,
		GameEnums.StaffRole.PHYSIO,
	]

	for role in roles:
		var s = StaffData.new()
		s.id = "%s_%s" % [team.id, role]
		s.first_name = _get_random_first_name(team.nationality)
		s.last_name = _get_random_last_name(team.nationality)
		s.nationality = team.nationality
		s.date_of_birth = _generate_birth_date(30, 65)
		s.role = role
		s.club_id = team.id
		s.contract_type = GameEnums.ContractType.PERMANENT
		s.contract_start_date = GameState.get_current_date()
		s.contract_end_date = _add_years_to_date(GameState.get_current_date(), randi_range(1, 3))
		s.wage = _calculate_staff_wage(role, team.reputation)
		_generate_staff_attributes(s, role, team.reputation / 10000.0)
		staff[s.id] = s
		team.staff_ids.append(s.id)

func _generate_staff_attributes(staff: StaffData, role: int, rep_factor: float):
	var base = 8 + int(rep_factor * 8)
	var variance = 3

	# Set all to base first
	staff.attacking = _attr(base, variance)
	staff.defending = _attr(base, variance)
	staff.tactical = _attr(base, variance)
	staff.technical = _attr(base, variance)
	staff.goalkeeping = _attr(base, variance)
	staff.fitness = _attr(base, variance)
	staff.set_pieces = _attr(base, variance)
	staff.mental = _attr(base, variance)
	staff.man_management = _attr(base, variance)
	staff.working_with_youngsters = _attr(base, variance)
	staff.judging_ability = _attr(base, variance)
	staff.judging_potential = _attr(base, variance)

	# Boost relevant attributes
	match role:
		GameEnums.StaffRole.COACH_ATTACK:
			staff.attacking = clamp(staff.attacking + 4, 1, 20)
			staff.technical = clamp(staff.technical + 3, 1, 20)
		GameEnums.StaffRole.COACH_DEFENCE:
			staff.defending = clamp(staff.defending + 4, 1, 20)
			staff.tactical = clamp(staff.tactical + 3, 1, 20)
		GameEnums.StaffRole.COACH_MIDFIELD:
			staff.tactical = clamp(staff.tactical + 4, 1, 20)
			staff.technical = clamp(staff.technical + 3, 1, 20)
		GameEnums.StaffRole.COACH_GK:
			staff.goalkeeping = clamp(staff.goalkeeping + 6, 1, 20)
		GameEnums.StaffRole.COACH_FITNESS:
			staff.fitness = clamp(staff.fitness + 5, 1, 20)
		GameEnums.StaffRole.COACH_SET_PIECES:
			staff.set_pieces = clamp(staff.set_pieces + 5, 1, 20)
		GameEnums.StaffRole.SCOUT:
			staff.judging_ability = clamp(staff.judging_ability + 4, 1, 20)
			staff.judging_potential = clamp(staff.judging_potential + 4, 1, 20)
		GameEnums.StaffRole.ASSISTANT_MANAGER:
			staff.tactical = clamp(staff.tactical + 3, 1, 20)
			staff.man_management = clamp(staff.man_management + 3, 1, 20)

	staff.professionalism = randi_range(8, 20)
	staff.ambition = randi_range(5, 20)
	staff.loyalty = randi_range(5, 20)

func _calculate_staff_wage(role: int, reputation: int) -> int:
	var base_wage = 5000
	var rep_factor = reputation / 10000.0
	match role:
		GameEnums.StaffRole.ASSISTANT_MANAGER:
			return int(base_wage * 10 * rep_factor)
		GameEnums.StaffRole.COACH_GK, GameEnums.StaffRole.COACH_DEFENCE, GameEnums.StaffRole.COACH_MIDFIELD, GameEnums.StaffRole.COACH_ATTACK, GameEnums.StaffRole.COACH_FITNESS, GameEnums.StaffRole.COACH_SET_PIECES:
			return int(base_wage * 5 * rep_factor)
		GameEnums.StaffRole.SCOUT:
			return int(base_wage * 4 * rep_factor)
		GameEnums.StaffRole.PHYSIO:
			return int(base_wage * 3 * rep_factor)
		_:
			return int(base_wage * 3 * rep_factor)

func _build_indexes():
	# Clear existing
	players_by_nationality.clear()
	players_by_club.clear()
	players_by_position.clear()
	free_agents.clear()
	transfer_listed_players.clear()

	for pid, player in players:
		# By nationality
		if not players_by_nationality.has(player.nationality):
			players_by_nationality[player.nationality] = []
		players_by_nationality[player.nationality].append(pid)

		# By club
		if player.club_id != "":
			if not players_by_club.has(player.club_id):
				players_by_club[player.club_id] = []
			players_by_club[player.club_id].append(pid)
		else:
			free_agents.append(pid)

		# By position
		if not players_by_position.has(player.primary_position):
			players_by_position[player.primary_position] = []
		players_by_position[player.primary_position].append(pid)

# =============================================================================
# PUBLIC API
# =============================================================================

func get_player(id: String) -> PlayerData:
	return players.get(id)

func get_team(id: String) -> TeamData:
	return teams.get(id)

func get_competition(id: String) -> CompetitionData:
	return competitions.get(id)

func get_staff(id: String) -> StaffData:
	return staff.get(id)

func get_players_by_club(club_id: String) -> Array[PlayerData]:
	var result = []
	if players_by_club.has(club_id):
		for pid in players_by_club[club_id]:
			var p = players.get(pid)
			if p:
				result.append(p)
	return result

func get_players_by_position(position: int) -> Array[PlayerData]:
	var result = []
	if players_by_position.has(position):
		for pid in players_by_position[position]:
			var p = players.get(pid)
			if p:
				result.append(p)
	return result

func get_free_agents() -> Array[PlayerData]:
	var result = []
	for pid in free_agents:
		var p = players.get(pid)
		if p:
			result.append(p)
	return result

func get_teams_by_competition(comp_id: String) -> Array[TeamData]:
	var result = []
	var comp = competitions.get(comp_id)
	if comp:
		for tid in comp.team_ids:
			var t = teams.get(tid)
			if t:
				result.append(t)
	return result

func search_players(query: String, filters: Dictionary = {}) -> Array[PlayerData]:
	var results = []
	query = query.to_lower()

	for pid, player in players:
		var match = true

		# Name search
		if query != "":
			var name_match = player.first_name.to_lower().contains(query) or player.last_name.to_lower().contains(query)
			if player.common_name != "":
				name_match = name_match or player.common_name.to_lower().contains(query)
			if not name_match:
				match = false

		# Filters
		if match and filters.has("position") and filters["position"] != -1:
			if player.primary_position != filters["position"]:
				match = false

		if match and filters.has("nationality") and filters["nationality"] != "":
			if player.nationality != filters["nationality"]:
				match = false

		if match and filters.has("min_ca"):
			if player.current_ability < filters["min_ca"]:
				match = false

		if match and filters.has("max_ca"):
			if player.current_ability > filters["max_ca"]:
				match = false

		if match and filters.has("age_min"):
			if player.get_age() < filters["age_min"]:
				match = false

		if match and filters.has("age_max"):
			if player.get_age() > filters["age_max"]:
				match = false

		if match and filters.has("club_id") and filters["club_id"] != "":
			if player.club_id != filters["club_id"]:
				match = false

		if match:
			results.append(player)

	# Sort by CA descending
	results.sort_custom(self, "_compare_player_ca")
	return results

func _compare_player_ca(a: PlayerData, b: PlayerData) -> int:
	return b.current_ability - a.current_ability

# Regen generation for new seasons
func generate_regen(player_template: PlayerData = null) -> PlayerData:
	var player = PlayerData.new()
	player.id = "regen_%d_%d" % [Time.get_unix_time_from_system(), randi_range(1000, 9999)]

	if player_template:
		# Based on retired player
		player.first_name = _get_random_first_name(player_template.nationality)
		player.last_name = _get_random_last_name(player_template.nationality)
		player.nationality = player_template.nationality
		player.primary_position = player_template.primary_position
		player.potential_ability = player_template.potential_ability
	else:
		# Completely random
		var nat = NATIONALITIES.pick_random()
		player.first_name = _get_random_first_name(nat)
		player.last_name = _get_random_last_name(nat)
		player.nationality = nat
		player.primary_position = _get_random_position()
		player.potential_ability = randi_range(80, 180)

	player.date_of_birth = _generate_birth_date(15, 18)
	player.current_ability = randi_range(40, min(80, player.potential_ability))
	_generate_attributes_for_position(player, player.primary_position, 0.5)
	player.professionalism = randi_range(5, 20)
	player.ambition = randi_range(5, 20)
	player.loyalty = randi_range(5, 20)
	player.determination = randi_range(5, 20)

	return player

const NATIONALITIES = ["England", "Spain", "Germany", "Italy", "France", "Portugal", "Netherlands", "Belgium", "Brazil", "Argentina", "Uruguay", "Croatia", "Serbia", "Poland", "Turkey", "France", "Denmark", "Sweden", "Switzerland", "Austria"]

func _get_random_position() -> int:
	var positions = [GameEnums.Position.GK, GameEnums.Position.DCR, GameEnums.Position.DL, GameEnums.Position.DM, GameEnums.Position.MC, GameEnums.Position.AMC, GameEnums.Position.STR]
	return positions.pick_random()

# Persistence
func save_to_json():
	var data = {
		"players": {},
		"teams": {},
		"competitions": {},
		"staff": {},
	}

	for pid, player in players:
		data.players[pid] = player.to_dict()

	for tid, team in teams:
		data.teams[tid] = team.to_dict()

	for cid, comp in competitions:
		data.competitions[cid] = comp.to_dict()

	for sid, s in staff:
		data.staff[sid] = s.to_dict()

	var file = FileAccess.open("user://database_save.json", FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data, "\t"))
		file.close()
		print("Database saved to user://database_save.json")

func load_from_json():
	var file = FileAccess.open("user://database_save.json", FileAccess.READ)
	if file:
		var data = JSON.parse_string(file.get_as_text())
		file.close()
		if data.error == OK:
			# Clear current
			players.clear()
			teams.clear()
			competitions.clear()
			staff.clear()

			# Load players
			for pid, pdata in data.value.players:
				var player = PlayerData.new()
				player.from_dict(pdata)
				players[pid] = player

			# Load teams
			for tid, tdata in data.value.teams:
				var team = TeamData.new()
				team.from_dict(tdata)
				teams[tid] = team

			# Load competitions
			for cid, cdata in data.value.competitions:
				var comp = CompetitionData.new()
				comp.from_dict(cdata)
				competitions[cid] = comp

			# Load staff
			for sid, sdata in data.value.staff:
				var s = StaffData.new()
				s.from_dict(sdata)
				staff[sid] = s

			_build_indexes()
			print("Database loaded from user://database_save.json")