extends PanelContainer
class_name PlayerCard

# =============================================================================
# SIGNALS
# =============================================================================
signal selected(player: PlayerData)

# =============================================================================
# UI REFERENCES
# =============================================================================

@onready var position_badge: Label = $Content/Header/PositionBadge
@onready var name_label: Label = $Content/Header/Name
@onready var age_label: Label = $Content/Header/Age
@onready var ca_value: Label = $Content/StatusRow/CA/CAValue
@onready var pa_value: Label = $Content/StatusRow/PA/PAValue
@onready var value_value: Label = $Content/StatusRow/Value/ValueValue
@onready var wage_value: Label = $Content/StatusRow/Wage/WageValue
@onready var condition_bar: ProgressBar = $Content/ConditionRow/Condition/ConditionBar
@onready var sharpness_bar: ProgressBar = $Content/ConditionRow/Sharpness/SharpnessBar
@onready var morale_bar: ProgressBar = $Content/ConditionRow/Morale/MoraleBar
@onready var squad_status: Label = $Content/Footer/SquadStatus
@onready var contract_label: Label = $Content/Footer/Contract

# =============================================================================
# STATE
# =============================================================================

var player_data: PlayerData = null
var compact_mode: bool = false

# =============================================================================
# SETUP
# =============================================================================

func setup(player: PlayerData, compact: bool = false):
	player_data = player
	compact_mode = compact
	_update_display()

func _update_display():
	if not player_data:
		return

	# Position badge
	position_badge.text = GameEnums.get_position_short(player_data.primary_position)
	position_badge.add_theme_color_override("font_color", _get_position_color(player_data.primary_position))
	position_badge.add_theme_color_override("bg_color", _get_position_color(player_data.primary_position, 0.2))

	# Name
	name_label.text = player_data.get_full_name()

	# Age
	age_label.text = "%d" % player_data.get_age()

	# CA/PA
	ca_value.text = str(player_data.current_ability)
	ca_value.add_theme_color_override("font_color", _get_ca_color(player_data.current_ability))

	pa_value.text = str(player_data.potential_ability)
	pa_value.add_theme_color_override("font_color", _get_ca_color(player_data.potential_ability))

	# Value
	var club = Database.instance.get_team(player_data.club_id)
	var value = 0
	if club:
		value = club.estimate_player_value(player_data)
	value_value.text = _format_currency(value)

	# Wage
	wage_value.text = "%s/w" % _format_currency(player_data.wage)

	# Condition bars
	condition_bar.value = player_data.condition
	condition_bar.add_theme_color_override("fill_color", _get_bar_color(player_data.condition))

	sharpness_bar.value = player_data.match_sharpness
	sharpness_bar.add_theme_color_override("fill_color", _get_bar_color(player_data.match_sharpness))

	morale_bar.value = player_data.morale
	morale_bar.add_theme_color_override("fill_color", _get_bar_color(player_data.morale))

	# Squad status
	squad_status.text = GameEnums.SQUAD_STATUS_NAMES[player_data.squad_status]
	squad_status.add_theme_color_override("font_color", _get_status_color(player_data.squad_status))

	# Contract
	var years_left = player_data.get_contract_years_remaining()
	contract_label.text = "%.1f yrs" % years_left
	if years_left < 1:
		contract_label.add_theme_color_override("font_color", Color(0.9, 0.3, 0.3))
	elif years_left < 2:
		contract_label.add_theme_color_override("font_color", Color(0.9, 0.7, 0.2))
	else:
		contract_label.add_theme_color_override("font_color", Color(0.4, 0.8, 0.4))

	# Injury/suspension indicators
	if player_data.injury_type != GameEnums.InjuryType.NONE:
		name_label.add_theme_color_override("font_color", Color(0.9, 0.3, 0.3))
		name_label.tooltip_text = "Injured: %s (%d days)" % [GameEnums.INJURY_SEVERITY, player_data.injury_remaining_days]
	elif player_data.suspended:
		name_label.add_theme_color_override("font_color", Color(0.9, 0.5, 0.2))
		name_label.tooltip_text = "Suspended: %d matches" % player_data.suspension_remaining_matches

# =============================================================================
# INPUT HANDLING
# =============================================================================

func _gui_input(event: InputEvent):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		if event.double_click:
			emit_signal("selected", player_data)
		elif not compact_mode:
			emit_signal("selected", player_data)

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

func _get_position_color(position: int, alpha: float = 1.0) -> Color:
	match GameEnums.get_position_group(position):
		"Goalkeepers": return Color(0.2, 0.6, 1.0, alpha)  # Blue
		"Defenders": return Color(0.4, 0.8, 0.4, alpha)    # Green
		"Midfielders": return Color(0.8, 0.6, 0.2, alpha)  # Orange
		"Forwards": return Color(1.0, 0.3, 0.3, alpha)     # Red
	return Color(0.7, 0.7, 0.7, alpha)

func _get_ca_color(ca: int) -> Color:
	if ca >= 170: return Color(0.9, 0.3, 0.3)    # Red - World class
	if ca >= 150: return Color(0.9, 0.7, 0.2)    # Gold - Elite
	if ca >= 130: return Color(0.4, 0.8, 0.4)    # Green - Very good
	if ca >= 110: return Color(0.4, 0.7, 0.9)    # Blue - Good
	if ca >= 90: return Color(0.7, 0.7, 0.7)     # Grey - Average
	return Color(0.6, 0.6, 0.6)                   # Dark grey - Below average

func _get_status_color(status: int) -> Color:
	match status:
		GameEnums.SquadStatus.KEY_PLAYER: return Color(0.9, 0.3, 0.3)
		GameEnums.SquadStatus.FIRST_TEAM: return Color(0.4, 0.8, 0.4)
		GameEnums.SquadStatus.ROTATION: return Color(0.4, 0.7, 0.9)
		GameEnums.SquadStatus.BACKUP: return Color(0.7, 0.7, 0.7)
		GameEnums.SquadStatus.HOT_PROSPECT: return Color(0.9, 0.7, 0.2)
		GameEnums.SquadStatus.YOUTH_PLAYER: return Color(0.6, 0.8, 0.9)
		GameEnums.SquadStatus.NOT_NEEDED: return Color(0.6, 0.6, 0.6)
	return Color(0.7, 0.7, 0.7)

func _get_bar_color(value: int) -> Color:
	if value >= 80: return Color(0.4, 0.8, 0.4)
	if value >= 60: return Color(0.9, 0.7, 0.2)
	if value >= 40: return Color(0.9, 0.5, 0.2)
	return Color(0.9, 0.3, 0.3)

func _format_currency(amount: int) -> String:
	var abs_amount = abs(amount)
	if abs_amount >= 1000000:
		return "£%.1fM" % (amount / 1000000.0)
	elif abs_amount >= 1000:
		return "£%.0fK" % (amount / 1000.0)
	else:
		return "£%d" % amount