extends Resource
class_name PlayerData

# =============================================================================
# IDENTITY
# =============================================================================
@export var id: String = ""
@export var first_name: String = ""
@export var last_name: String = ""
@export var common_name: String = ""  # For display (e.g., "CR7", "Neymar")
@export var nationality: String = ""
@export var second_nationality: String = ""
@export var date_of_birth: Dictionary = {"year": 2000, "month": 1, "day": 1}
@export var place_of_birth: String = ""
@export var preferred_foot: int = 0  # GameEnums.Footedness

# =============================================================================
# ATTRIBUTES (1-20 scale)
# =============================================================================

# Technical
@export_group("Technical Attributes")
@export var crossing: int = 10
@export var finishing: int = 10
@export var heading: int = 10
@export var long_shots: int = 10
@export var marking: int = 10
@export var passing: int = 10
@export var penalty_taking: int = 10
@export var tackling: int = 10
@export var technique: int = 10

# Mental
@export_group("Mental Attributes")
@export var anticipation: int = 10
@export var composure: int = 10
@export var concentration: int = 10
@export var decisions: int = 10
@export var determination: int = 10
@export var flair: int = 10
@export var leadership: int = 10
@export var off_the_ball: int = 10
@export var positioning: int = 10
@export var teamwork: int = 10
@export var vision: int = 10
@export var work_rate: int = 10

# Physical
@export_group("Physical Attributes")
@export var acceleration: int = 10
@export var agility: int = 10
@export var balance: int = 10
@export var jumping: int = 10
@export var natural_fitness: int = 10
@export var pace: int = 10
@export var stamina: int = 10
@export var strength: int = 10

# Goalkeeping
@export_group("Goalkeeping Attributes")
@export var aerial_reach: int = 10
@export var command_of_area: int = 10
@export var communication: int = 10
@export var eccentricity: int = 10
@export var handling: int = 10
@export var kicking: int = 10
@export var one_on_ones: int = 10
@export var reflexes: int = 10
@export var rushing_out: int = 10
@export var throwing: int = 10

# Hidden
@export_group("Hidden Attributes")
@export var consistency: int = 10
@export var dirtiness: int = 10
@export var important_matches: int = 10
@export var injury_proneness: int = 10
@export var versatility: int = 10
@export var adaptability: int = 10
@export var ambition: int = 10
@export var loyalty: int = 10
@export var pressure: int = 10
@export var professionalism: int = 10
@export var sportsmanship: int = 10
@export var temperament: int = 10
@export var controversy: int = 10

# =============================================================================
# ABILITY & POTENTIAL
# =============================================================================
@export_group("Ability")
@export var current_ability: int = 100  # CA 1-200
@export var potential_ability: int = 150  # PA 1-200

# =============================================================================
# POSITIONS & ROLES
# =============================================================================
@export_group("Positions & Roles")
@export var primary_position: int = 12  # GameEnums.Position (default STR)
@export var secondary_positions: Array[int] = []  # Array of Position enums
# Dictionary: Position (int) -> Role familiarity (0-100)
@export var role_familiarity: Dictionary = {}

# =============================================================================
# CONTRACT & CLUB
# =============================================================================
@export_group("Contract")
@export var club_id: String = ""
@export var contract_type: int = 0  # GameEnums.ContractType
@export var contract_start_date: Dictionary = {}
@export var contract_end_date: Dictionary = {}
@export var wage: int = 0  # Weekly wage
@export var squad_status: int = 3  # GameEnums.SquadStatus
@export var release_clause: int = 0
@export var agent_name: String = ""
@export var agent_fee_percentage: float = 0.05

# Contract clauses
@export var appearance_fee: int = 0
@export var goal_bonus: int = 0
@export var assist_bonus: int = 0
@export var clean_sheet_bonus: int = 0
@export var win_bonus: int = 0
@export var loyalty_bonus: int = 0
@export var sell_on_clause_percentage: float = 0.0
@export var minimum_fee_release_clause: int = 0
@export var contract_extension_option: bool = false
@export var release_clause_active_date: Dictionary = {}

# =============================================================================
# DYNAMIC STATE (changes during game)
# =============================================================================
@export_group("Dynamic State")
@export var morale: int = 100  # 0-100
@export var condition: int = 100  # 0-100 (fitness)
@export var match_sharpness: int = 70  # 0-100
@export var training_happiness: int = 50  # 0-100
@export var playing_time_happiness: int = 50  # 0-100

# Form (last 5 matches: 5=MoM, 4=Great, 3=Good, 2=Avg, 1=Poor, 0=Did not play)
@export var recent_form: Array[int] = []

# Injury
@export var injury_type: int = 0  # GameEnums.InjuryType
@export var injury_remaining_days: int = 0
@export var injury_details: String = ""

# Suspension
@export var suspended: bool = false
@export var suspension_remaining_matches: int = 0
@export var suspension_reason: String = ""

# International duty
@export var on_international_duty: bool = false
@export var international_duty_return_date: Dictionary = {}

# =============================================================================
# HISTORY & STATS
# =============================================================================
@export_group("History & Stats")
@export var career_history: Array[Dictionary] = []  # Season stats per club
@export var total_appearances: int = 0
@export var total_goals: int = 0
@export var total_assists: int = 0
@export var total_yellow_cards: int = 0
@export var total_red_cards: int = 0
@export var total_man_of_match: int = 0
@export var international_caps: int = 0
@export var international_goals: int = 0

# Season stats (reset each season)
@export var season_appearances: int = 0
@export var season_goals: int = 0
@export var season_assists: int = 0
@export var season_yellow_cards: int = 0
@export var season_red_cards: int = 0
@export var season_man_of_match: int = 0
@export var season_average_rating: float = 0.0
@export var season_minutes_played: int = 0

# =============================================================================
# DEVELOPMENT
# =============================================================================
@export_group("Development")
@export var development_plan: Dictionary = {}  # Focus attributes
@export var preferred_training_position: int = -1
@export var tutoring_player_id: String = ""
@export var can_be_tutored: bool = true
@export var development_trait: String = ""  # e.g., "Late Developer", "Early Peak"

# =============================================================================
# PERSONALITY & PREFERENCES
# =============================================================================
@export_group("Personality")
@export var personality: int = 1  # GameEnums.Personality
@export var media_handling: int = 10
@export var preferred_clubs: Array[String] = []
@export var disliked_clubs: Array[String] = []
@export var favored_personnel: Array[String] = []  # Staff/player IDs
@export var disliked_personnel: Array[String] = []

# =============================================================================
# COMPUTED PROPERTIES
# =============================================================================

func get_full_name() -> String:
	if common_name != "":
		return common_name
	return "%s %s" % [first_name, last_name]

func get_age(current_date: Dictionary = null) -> int:
	if current_date == null:
		current_date = GameState.get_current_date()
	var birth_year = date_of_birth.year
	var birth_month = date_of_birth.month
	var birth_day = date_of_birth.day
	var age = current_date.year - birth_year
	if current_date.month < birth_month or (current_date.month == birth_month and current_date.day < birth_day):
		age -= 1
	return age

func get_contract_years_remaining(current_date: Dictionary = null) -> float:
	if current_date == null:
		current_date = GameState.get_current_date()
	if not contract_end_date or contract_end_date == {}:
		return 0.0
	var end_year = contract_end_date.year
	var end_month = contract_end_date.month
	var months_remaining = (end_year - current_date.year) * 12 + (end_month - current_date.month)
	return max(0.0, months_remaining / 12.0)

func is_contract_expiring_soon(months: int = 6, current_date: Dictionary = null) -> bool:
	if current_date == null:
		current_date = GameState.get_current_date()
	if not contract_end_date or contract_end_date == {}:
		return false
	var end_year = contract_end_date.year
	var end_month = contract_end_date.month
	var months_remaining = (end_year - current_date.year) * 12 + (end_month - current_date.month)
	return months_remaining <= months and months_remaining > 0

func get_attribute(attr_name: String) -> int:
	return get(attr_name, 10)

func set_attribute(attr_name: String, value: int):
	if hasattr(attr_name):
		set(attr_name, clamp(value, 1, 20))

# Get weighted attribute for a specific role
func get_role_suitability(role: int) -> float:
	# This would use role-specific attribute weights
	# Simplified version - returns average of key attributes
	var attrs = _get_key_attributes_for_role(role)
	if attrs.is_empty():
		return 50.0
	var total = 0
	for attr in attrs:
		total += get_attribute(attr)
	return (total / attrs.size()) * 5.0  # Convert 1-20 to 5-100

func _get_key_attributes_for_role(role: int) -> Array[String]:
	# Simplified mapping - in reality each role has specific weights
	match role:
		GameEnums.Role.GK_Goalkeeper, GameEnums.Role.GK_SweeperKeeper:
			return ["reflexes", "handling", "one_on_ones", "aerial_reach", "communication", "command_of_area"]
		GameEnums.Role.DCR_CentralDefender, GameEnums.Role.DCL_CentralDefender:
			return ["marking", "tackling", "heading", "positioning", "concentration", "strength"]
		GameEnums.Role.DM_Anchor:
			return ["marking", "tackling", "positioning", "interceptions", "strength", "stamina"]
		GameEnums.Role.MC_BoxToBoxMidfielder:
			return ["passing", "stamina", "work_rate", "technique", "decisions", "off_the_ball"]
		GameEnums.Role.AMC_AdvancedPlaymaker:
			return ["passing", "vision", "technique", "flair", "decisions", "off_the_ball"]
		GameEnums.Role.STR_AdvancedForward:
			return ["finishing", "off_the_ball", "pace", "acceleration", "composure", "anticipation"]
		_:
			return ["technique", "decisions", "work_rate", "stamina"]

# Serialize to dictionary for saving
func to_dict() -> Dictionary:
	var dict = {}
	# Export all @export variables
	var props = get_property_list()
	for prop in props:
		var name = prop.name
		if name.begins_with("_"):  # Skip private
			continue
		dict[name] = get(name)
	return dict

# Load from dictionary
func from_dict(dict: Dictionary):
	for key, value in dict:
		if hasattr(key):
			set(key, value)

func _validate_property(property: Dictionary) -> bool:
	# Clamp attributes to 1-20
	if property.name in _get_all_attribute_names():
		if property.usage & PROPERTY_USAGE_STORAGE:
			return true
	return true

func _get_all_attribute_names() -> Array[String]:
	return [
		"crossing", "finishing", "heading", "long_shots", "marking", "passing",
		"penalty_taking", "tackling", "technique", "anticipation", "composure",
		"concentration", "decisions", "determination", "flair", "leadership",
		"off_the_ball", "positioning", "teamwork", "vision", "work_rate",
		"acceleration", "agility", "balance", "jumping", "natural_fitness",
		"pace", "stamina", "strength", "aerial_reach", "command_of_area",
		"communication", "eccentricity", "handling", "kicking", "one_on_ones",
		"reflexes", "rushing_out", "throwing", "consistency", "dirtiness",
		"important_matches", "injury_proneness", "versatility", "adaptability",
		"ambition", "loyalty", "pressure", "professionalism", "sportsmanship",
		"temperament", "controversy"
	]