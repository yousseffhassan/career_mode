extends Resource
class_name StaffData

# =============================================================================
# IDENTITY
# =============================================================================
@export var id: String = ""
@export var first_name: String = ""
@export var last_name: String = ""
@export var common_name: String = ""
@export var nationality: String = ""
@export var second_nationality: String = ""
@export var date_of_birth: Dictionary = {"year": 1970, "month": 1, "day": 1}
@export var preferred_formation: String = "4-4-2"

# =============================================================================
# ROLE & CONTRACT
# =============================================================================
@export var role: int = 0  # GameEnums.StaffRole
@export var club_id: String = ""
@export var contract_type: int = 0  # GameEnums.ContractType
@export var contract_start_date: Dictionary = {}
@export var contract_end_date: Dictionary = {}
@export var wage: int = 0  # Weekly

# =============================================================================
# ATTRIBUTES (1-20)
# =============================================================================
@export_group("Coaching Attributes")
@export var attacking: int = 10
@export var defending: int = 10
@export var tactical: int = 10
@export var technical: int = 10
@export var goalkeeping: int = 10
@export var fitness: int = 10
@export var set_pieces: int = 10
@export var mental: int = 10
@export var man_management: int = 10
@export var working_with_youngsters: int = 10
@export var judging_ability: int = 10
@export var judging_potential: int = 10

# =============================================================================
# HIDDEN ATTRIBUTES
# =============================================================================
@export_group("Hidden Attributes")
@export var adaptability: int = 10
@export var ambition: int = 10
@export var loyalty: int = 10
@export var pressure: int = 10
@export var professionalism: int = 10
@export var sportsmanship: int = 10
@export var temperament: int = 10
@export var controversy: int = 10

# =============================================================================
# PERSONALITY & PREFERENCES
# =============================================================================
@export var personality: int = 1  # GameEnums.Personality
@export var favored_clubs: Array[String] = []
@export var disliked_clubs: Array[String] = []
@export var favored_personnel: Array[String] = []
@export var disliked_personnel: Array[String] = []

# =============================================================================
# HISTORY & REPUTATION
# =============================================================================
@export var reputation: int = 3000  # 1-10000
@export var career_history: Array[Dictionary] = []  # {club, role, start_date, end_date, achievements}
@export var honours: Array[Dictionary] = []
@export var preferred_tactics: Array[String] = []  # Formation preferences

# =============================================================================
# DYNAMIC STATE
# =============================================================================
@export var morale: int = 50
@export var job_satisfaction: int = 50
@export var relationship_with_manager: int = 50  # For non-manager staff

# =============================================================================
# COMPUTED PROPERTIES
# =============================================================================

func get_full_name() -> String:
	if common_name != "":
		return common_name
	return "%s %s" % [first_name, last_name]

func get_age(current_date: Dictionary = null) -> int:
	if current_date == null:
		current_date = GameState.get_current_date()
	var birth_year = date_of_birth.year
	var birth_month = date_of_birth.month
	var birth_day = date_of_birth.day
	var age = current_date.year - birth_year
	if current_date.month < birth_month or (current_date.month == birth_month and current_date.day < birth_day):
		age -= 1
	return age

func get_coaching_rating(category: String) -> int:
	# Return average of relevant attributes for a training category
	match category:
		"attacking":
			return (attacking + technical + tactical) / 3
		"defending":
			return (defending + tactical + mental) / 3
		"goalkeeping":
			return (goalkeeping + technical + mental) / 3
		"fitness":
			return (fitness + mental + technical) / 3
		"set_pieces":
			return (set_pieces + tactical + technical) / 3
		"youth":
			return (working_with_youngsters + judging_potential + man_management) / 3
		"general":
			return (attacking + defending + tactical + technical + mental + man_management) / 6
		_:
			return 10

func get_overall_rating() -> int:
	var attrs = [attacking, defending, tactical, technical, goalkeeping, fitness, set_pieces, mental, man_management, working_with_youngsters]
	var total = 0
	for attr in attrs:
		total += attr
	return total / attrs.size()

func get_contract_years_remaining(current_date: Dictionary = null) -> float:
	if current_date == null:
		current_date = GameState.get_current_date()
	if not contract_end_date or contract_end_date == {}:
		return 0.0
	var end_year = contract_end_date.year
	var end_month = contract_end_date.month
	var months_remaining = (end_year - current_date.year) * 12 + (end_month - current_date.month)
	return max(0.0, months_remaining / 12.0)

func is_good_for_role(target_role: int) -> bool:
	# Check if staff attributes match role requirements
	match target_role:
		GameEnums.StaffRole.COACH_ATTACK:
			return attacking >= 14 and technical >= 12
		GameEnums.StaffRole.COACH_DEFENCE:
			return defending >= 14 and tactical >= 12
		GameEnums.StaffRole.COACH_MIDFIELD:
			return tactical >= 14 and technical >= 12
		GameEnums.StaffRole.COACH_GK:
			return goalkeeping >= 15
		GameEnums.StaffRole.COACH_FITNESS:
			return fitness >= 14
		GameEnums.StaffRole.COACH_SET_PIECES:
			return set_pieces >= 14 and tactical >= 12
		GameEnums.StaffRole.SCOUT:
			return judging_ability >= 13 and judging_potential >= 13
		GameEnums.StaffRole.ASSISTANT_MANAGER:
			return tactical >= 14 and man_management >= 13
		GameEnums.StaffRole.MANAGER:
			return tactical >= 15 and man_management >= 14
		_:
			return true

# Serialize for saving
func to_dict() -> Dictionary:
	var dict = {}
	var props = get_property_list()
	for prop in props:
		var name = prop.name
		if name.begins_with("_"):
			continue
		dict[name] = get(name)
	return dict

func from_dict(dict: Dictionary):
	for key, value in dict:
		if hasattr(key):
			set(key, value)