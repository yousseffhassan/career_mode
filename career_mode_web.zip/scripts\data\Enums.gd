extends Resource
class_name GameEnums

# =============================================================================
# POSITIONS
# =============================================================================
enum Position {
	GK,   # Goalkeeper
	DR,   # Right Back / Wing Back
	DCR,  # Right Centre Back
	DCL,  # Left Centre Back
	DL,   # Left Back / Wing Back
	DM,   # Defensive Midfielder
	MR,   # Right Midfielder / Winger
	MC,   # Central Midfielder
	ML,   # Left Midfielder / Winger
	AMR,  # Right Attacking Midfielder
	AMC,  # Attacking Midfielder
	AML,  # Left Attacking Midfielder
	STR,  # Striker / Centre Forward
}

# Position groups for UI filtering
const POSITION_GROUPS = {
	"Goalkeepers": [Position.GK],
	"Defenders": [Position.DR, Position.DCR, Position.DCL, Position.DL],
	"Midfielders": [Position.DM, Position.MR, Position.MC, Position.ML, Position.AMR, Position.AMC, Position.AML],
	"Forwards": [Position.STR],
}

# Position abbreviations for display
const POSITION_SHORT = {
	Position.GK: "GK",
	Position.DR: "RB",
	Position.DCR: "RCB",
	Position.DCL: "LCB",
	Position.DL: "LB",
	Position.DM: "DM",
	Position.MR: "RM",
	Position.MC: "CM",
	Position.ML: "LM",
	Position.AMR: "RAM",
	Position.AMC: "CAM",
	Position.AML: "LAM",
	Position.STR: "ST",
}

# Full position names
const POSITION_FULL = {
	Position.GK: "Goalkeeper",
	Position.DR: "Right Back",
	Position.DCR: "Right Centre Back",
	Position.DCL: "Left Centre Back",
	Position.DL: "Left Back",
	Position.DM: "Defensive Midfielder",
	Position.MR: "Right Midfielder",
	Position.MC: "Central Midfielder",
	Position.ML: "Left Midfielder",
	Position.AMR: "Right Attacking Midfielder",
	Position.AMC: "Attacking Midfielder",
	Position.AML: "Left Attacking Midfielder",
	Position.STR: "Striker",
}

# =============================================================================
# PLAYER ROLES (FM-style)
# =============================================================================
enum Role {
	# Goalkeeper
	GK_Goalkeeper,
	GK_SweeperKeeper,

	# Defenders
	DR_FullBack,
	DR_WingBack,
	DR_InvertedWingBack,
	DCR_CentralDefender,
	DCR_BallPlayingDefender,
	DCR_WideCentreBack,
	DL_FullBack,
	DL_WingBack,
	DL_InvertedWingBack,

	# Defensive Midfield
	DM_Anchor,
	DM_DeepLyingPlaymaker,
	DM_BallWinningMidfielder,
	DM_HalfBack,
	DM_SecondoVolante,

	# Central Midfield
	MC_CentralMidfielder,
	MC_BoxToBoxMidfielder,
	MC_Mezzala,
	MC_AdvancedPlaymaker,

	# Wide Midfield
	MR_Winger,
	MR_InsideForward,
	MR_WidePlaymaker,
	MR_InvertedWinger,
	ML_Winger,
	ML_InsideForward,
	ML_WidePlaymaker,
	ML_InvertedWinger,

	# Attacking Midfield
	AMR_InsideForward,
	AMR_WidePlaymaker,
	AMC_AdvancedPlaymaker,
	AMC_Trequartista,
	AMC_ShadowStriker,
	AML_InsideForward,
	AML_WidePlaymaker,

	# Striker
	STR_AdvancedForward,
	STR_Poacher,
	STR_CompleteForward,
	STR_DeepLyingForward,
	STR_TargetForward,
	STR_PressingForward,
	STR_FalseNine,
}

# Role to position mapping
const ROLE_POSITION = {
	Role.GK_Goalkeeper: Position.GK,
	Role.GK_SweeperKeeper: Position.GK,

	Role.DR_FullBack: Position.DR,
	Role.DR_WingBack: Position.DR,
	Role.DR_InvertedWingBack: Position.DR,
	Role.DCR_CentralDefender: Position.DCR,
	Role.DCR_BallPlayingDefender: Position.DCR,
	Role.DCR_WideCentreBack: Position.DCR,
	Role.DL_FullBack: Position.DL,
	Role.DL_WingBack: Position.DL,
	Role.DL_InvertedWingBack: Position.DL,

	Role.DM_Anchor: Position.DM,
	Role.DM_DeepLyingPlaymaker: Position.DM,
	Role.DM_BallWinningMidfielder: Position.DM,
	Role.DM_HalfBack: Position.DM,
	Role.DM_SecondoVolante: Position.DM,

	Role.MC_CentralMidfielder: Position.MC,
	Role.MC_BoxToBoxMidfielder: Position.MC,
	Role.MC_Mezzala: Position.MC,
	Role.MC_AdvancedPlaymaker: Position.MC,

	Role.MR_Winger: Position.MR,
	Role.MR_InsideForward: Position.MR,
	Role.MR_WidePlaymaker: Position.MR,
	Role.MR_InvertedWinger: Position.MR,
	Role.ML_Winger: Position.ML,
	Role.ML_InsideForward: Position.ML,
	Role.ML_WidePlaymaker: Position.ML,
	Role.ML_InvertedWinger: Position.ML,

	Role.AMR_InsideForward: Position.AMR,
	Role.AMR_WidePlaymaker: Position.AMR,
	Role.AMC_AdvancedPlaymaker: Position.AMC,
	Role.AMC_Trequartista: Position.AMC,
	Role.AMC_ShadowStriker: Position.AMC,
	Role.AML_InsideForward: Position.AML,
	Role.AML_WidePlaymaker: Position.AML,

	Role.STR_AdvancedForward: Position.STR,
	Role.STR_Poacher: Position.STR,
	Role.STR_CompleteForward: Position.STR,
	Role.STR_DeepLyingForward: Position.STR,
	Role.STR_TargetForward: Position.STR,
	Role.STR_PressingForward: Position.STR,
	Role.STR_FalseNine: Position.STR,
}

# Role display names
const ROLE_NAMES = {
	Role.GK_Goalkeeper: "Goalkeeper",
	Role.GK_SweeperKeeper: "Sweeper Keeper",

	Role.DR_FullBack: "Full Back",
	Role.DR_WingBack: "Wing Back",
	Role.DR_InvertedWingBack: "Inverted Wing Back",
	Role.DCR_CentralDefender: "Central Defender",
	Role.DCR_BallPlayingDefender: "Ball-Playing Defender",
	Role.DCR_WideCentreBack: "Wide Centre Back",
	Role.DL_FullBack: "Full Back",
	Role.DL_WingBack: "Wing Back",
	Role.DL_InvertedWingBack: "Inverted Wing Back",

	Role.DM_Anchor: "Anchor",
	Role.DM_DeepLyingPlaymaker: "Deep-Lying Playmaker",
	Role.DM_BallWinningMidfielder: "Ball-Winning Midfielder",
	Role.DM_HalfBack: "Half Back",
	Role.DM_SecondoVolante: "Segundo Volante",

	Role.MC_CentralMidfielder: "Central Midfielder",
	Role.MC_BoxToBoxMidfielder: "Box-to-Box Midfielder",
	Role.MC_Mezzala: "Mezzala",
	Role.MC_AdvancedPlaymaker: "Advanced Playmaker",

	Role.MR_Winger: "Winger",
	Role.MR_InsideForward: "Inside Forward",
	Role.MR_WidePlaymaker: "Wide Playmaker",
	Role.MR_InvertedWinger: "Inverted Winger",
	Role.ML_Winger: "Winger",
	Role.ML_InsideForward: "Inside Forward",
	Role.ML_WidePlaymaker: "Wide Playmaker",
	Role.ML_InvertedWinger: "Inverted Winger",

	Role.AMR_InsideForward: "Inside Forward",
	Role.AMR_WidePlaymaker: "Wide Playmaker",
	Role.AMC_AdvancedPlaymaker: "Advanced Playmaker",
	Role.AMC_Trequartista: "Trequartista",
	Role.AMC_ShadowStriker: "Shadow Striker",
	Role.AML_InsideForward: "Inside Forward",
	Role.AML_WidePlaymaker: "Wide Playmaker",

	Role.STR_AdvancedForward: "Advanced Forward",
	Role.STR_Poacher: "Poacher",
	Role.STR_CompleteForward: "Complete Forward",
	Role.STR_DeepLyingForward: "Deep-Lying Forward",
	Role.STR_TargetForward: "Target Forward",
	Role.STR_PressingForward: "Pressing Forward",
	Role.STR_FalseNine: "False Nine",
}

# =============================================================================
# FOOTEDNESS
# =============================================================================
enum Footedness {
	RIGHT,
	LEFT,
	BOTH,
}

# =============================================================================
# SQUAD STATUS
# =============================================================================
enum SquadStatus {
	KEY_PLAYER,
	FIRST_TEAM,
	ROTATION,
	BACKUP,
	HOT_PROSPECT,
	YOUTH_PLAYER,
	NOT_NEEDED,
}

const SQUAD_STATUS_NAMES = {
	SquadStatus.KEY_PLAYER: "Key Player",
	SquadStatus.FIRST_TEAM: "First Team",
	SquadStatus.ROTATION: "Rotation",
	SquadStatus.BACKUP: "Backup",
	SquadStatus.HOT_PROSPECT: "Hot Prospect",
	SquadStatus.YOUTH_PLAYER: "Youth Player",
	SquadStatus.NOT_NEEDED: "Not Needed",
}

# =============================================================================
# CONTRACT TYPES
# =============================================================================
enum ContractType {
	PERMANENT,
	LOAN,
	YOUTH,
	AMATEUR,
	NON_CONTRACT,
}

# =============================================================================
# COMPETITION TYPES
# =============================================================================
enum CompetitionType {
	LEAGUE,
	CUP,
	CONTINENTAL_LEAGUE,
	CONTINENTAL_CUP,
	SUPER_CUP,
	WORLD_CUP,
	INTERNATIONAL,
}

# =============================================================================
# STAFF ROLES
# =============================================================================
enum StaffRole {
	MANAGER,
	ASSISTANT_MANAGER,
	COACH_GK,
	COACH_DEFENCE,
	COACH_MIDFIELD,
	COACH_ATTACK,
	COACH_FITNESS,
	COACH_SET_PIECES,
	SCOUT,
	CHIEF_SCOUT,
	PHYSIO,
	SPORTS_SCIENTIST,
	DATA_ANALYST,
	TECHNICAL_DIRECTOR,
	DIRECTOR_OF_FOOTBALL,
}

const STAFF_ROLE_NAMES = {
	StaffRole.MANAGER: "Manager",
	StaffRole.ASSISTANT_MANAGER: "Assistant Manager",
	StaffRole.COACH_GK: "Goalkeeping Coach",
	StaffRole.COACH_DEFENCE: "Defensive Coach",
	StaffRole.COACH_MIDFIELD: "Midfield Coach",
	StaffRole.COACH_ATTACK: "Attacking Coach",
	StaffRole.COACH_FITNESS: "Fitness Coach",
	StaffRole.COACH_SET_PIECES: "Set Pieces Coach",
	StaffRole.SCOUT: "Scout",
	StaffRole.CHIEF_SCOUT: "Chief Scout",
	StaffRole.PHYSIO: "Physiotherapist",
	StaffRole.SPORTS_SCIENTIST: "Sports Scientist",
	StaffRole.DATA_ANALYST: "Data Analyst",
	StaffRole.TECHNICAL_DIRECTOR: "Technical Director",
	StaffRole.DIRECTOR_OF_FOOTBALL: "Director of Football",
}

# =============================================================================
# PERSONALITY TRAITS
# =============================================================================
enum Personality {
	MODEL_PROFESSIONAL,
	PROFESSIONAL,
	FAIRLY_PROFESSIONAL,
	AMBITIOUS,
	DRIVEN,
	DETERMINED,
	MODEL_CITIZEN,
	RESILIENT,
	CHARISMATIC_LEADER,
	BORN_LEADER,
	LEADER,
	IRON_WILLED,
	LIGHT_HEARTED,
	CASUAL,
	SLACK,
	UNMOTIVATED,
	LOW_DETERMINATION,
	TEMPERAMENTAL,
	ERRACTIC,
	VOLATILE,
	SPOILT,
}

# =============================================================================
# MATCH EVENTS
# =============================================================================
enum MatchEventType {
	KICK_OFF,
	HALF_TIME,
	FULL_TIME,
	GOAL,
	OWN_GOAL,
	PENALTY_GOAL,
	PENALTY_MISS,
	SHOT_ON_TARGET,
	SHOT_OFF_TARGET,
	SHOT_BLOCKED,
	SHOT_POST,
	FREE_KICK_GOAL,
	FREE_KICK_SHOT,
	CORNER,
	THROW_IN,
	OFFSIDE,
	FOUL,
	YELLOW_CARD,
	RED_CARD,
	SECOND_YELLOW,
	SUBSTITUTION,
	INJURY,
	INJURY_SUB,
	TAKEN_OFF_INJURED,
	SAVE,
	CLAIM,
	PUNCH,
	DROP,
	INTERCEPTION,
	TACKLE_WON,
	DRIBBLE_PAST,
	KEY_PASS,
	ASSIST,
	CHANCE_CREATED,
	BIG_CHANCE_MISSED,
	PENALTY_WON,
	PENALTY_CONCEDED,
	TACTICAL_CHANGE,
	FORMATION_CHANGE,
	MENTALITY_CHANGE,
	TEAM_TALK,
	VAR_CHECK,
	VAR_GOAL,
	VAR_NO_GOAL,
	VAR_PENALTY,
	VAR_NO_PENALTY,
	VAR_RED_CARD,
	VAR_NO_RED_CARD,
}

const MATCH_EVENT_NAMES = {
	MatchEventType.KICK_OFF: "Kick Off",
	MatchEventType.HALF_TIME: "Half Time",
	MatchEventType.FULL_TIME: "Full Time",
	MatchEventType.GOAL: "Goal",
	MatchEventType.OWN_GOAL: "Own Goal",
	MatchEventType.PENALTY_GOAL: "Penalty Goal",
	MatchEventType.PENALTY_MISS: "Penalty Missed",
	MatchEventType.SHOT_ON_TARGET: "Shot on Target",
	MatchEventType.SHOT_OFF_TARGET: "Shot off Target",
	MatchEventType.SHOT_BLOCKED: "Shot Blocked",
	MatchEventType.SHOT_POST: "Hit the Post",
	MatchEventType.FREE_KICK_GOAL: "Free Kick Goal",
	MatchEventType.FREE_KICK_SHOT: "Free Kick",
	MatchEventType.CORNER: "Corner",
	MatchEventType.THROW_IN: "Throw In",
	MatchEventType.OFFSIDE: "Offside",
	MatchEventType.FOUL: "Foul",
	MatchEventType.YELLOW_CARD: "Yellow Card",
	MatchEventType.RED_CARD: "Red Card",
	MatchEventType.SECOND_YELLOW: "Second Yellow Card",
	MatchEventType.SUBSTITUTION: "Substitution",
	MatchEventType.INJURY: "Injury",
	MatchEventType.INJURY_SUB: "Injury Substitution",
	MatchEventType.TAKEN_OFF_INJURED: "Taken Off Injured",
	MatchEventType.SAVE: "Save",
	MatchEventType.CLAIM: "Claim",
	MatchEventType.PUNCH: "Punch Clear",
	MatchEventType.DROP: "Dropped Ball",
	MatchEventType.INTERCEPTION: "Interception",
	MatchEventType.TACKLE_WON: "Tackle Won",
	MatchEventType.DRIBBLE_PAST: "Dribbled Past",
	MatchEventType.KEY_PASS: "Key Pass",
	MatchEventType.ASSIST: "Assist",
	MatchEventType.CHANCE_CREATED: "Chance Created",
	MatchEventType.BIG_CHANCE_MISSED: "Big Chance Missed",
	MatchEventType.PENALTY_WON: "Penalty Won",
	MatchEventType.PENALTY_CONCEDED: "Penalty Conceded",
	MatchEventType.TACTICAL_CHANGE: "Tactical Change",
	MatchEventType.FORMATION_CHANGE: "Formation Change",
	MatchEventType.MENTALITY_CHANGE: "Mentality Change",
	MatchEventType.TEAM_TALK: "Team Talk",
	MatchEventType.VAR_CHECK: "VAR Check",
	MatchEventType.VAR_GOAL: "VAR: Goal Stands",
	MatchEventType.VAR_NO_GOAL: "VAR: Goal Ruled Out",
	MatchEventType.VAR_PENALTY: "VAR: Penalty Awarded",
	MatchEventType.VAR_NO_PENALTY: "VAR: Penalty Overturned",
	MatchEventType.VAR_RED_CARD: "VAR: Red Card",
	MatchEventType.VAR_NO_RED_CARD: "VAR: Red Card Overturned",
}

# =============================================================================
# TEAM INSTRUCTIONS
# =============================================================================
enum Mentality {
	VERY_DEFENSIVE,
	DEFENSIVE,
	COUNTER,
	STANDARD,
	CONTROL,
	ATTACKING,
	VERY_ATTACKING,
	OVERLOAD,
}

enum PassingDirectness {
	VERY_SHORT,
	SHORT,
	STANDARD,
	DIRECT,
	VERY_DIRECT,
}

enum Tempo {
	VERY_SLOW,
	SLOW,
	STANDARD,
	FAST,
	VERY_FAST,
}

enum PressingIntensity {
	MINIMAL,
	LOW,
	STANDARD,
	HIGH,
	VERY_HIGH,
	INTENSE,
}

enum DefensiveLine {
	VERY_DEEP,
	DEEP,
	STANDARD,
	HIGH,
	VERY_HIGH,
}

enum Width {
	VERY_NARROW,
	NARROW,
	STANDARD,
	WIDE,
	VERY_WIDE,
}

# =============================================================================
# INJURY TYPES
# =============================================================================
enum InjuryType {
	NONE,
	BRUISE,
	KNOCK,
	MUSCLE_STRAIN,
	MUSCLE_TEAR,
	LIGAMENT_DAMAGE,
	BONE_FRACTURE,
	CONCUSSION,
	FATIGUE,
	ILLNESS,
}

const INJURY_SEVERITY = {
	InjuryType.NONE: 0,
	InjuryType.BRUISE: 1,
	InjuryType.KNOCK: 2,
	InjuryType.MUSCLE_STRAIN: 4,
	InjuryType.MUSCLE_TEAR: 6,
	InjuryType.LIGAMENT_DAMAGE: 12,
	InjuryType.BONE_FRACTURE: 16,
	InjuryType.CONCUSSION: 3,
	InjuryType.FATIGUE: 1,
	InjuryType.ILLNESS: 2,
}

# Weeks out for each injury type (min, max)
const INJURY_RECOVERY_WEEKS = {
	InjuryType.NONE: [0, 0],
	InjuryType.BRUISE: [0, 1],
	InjuryType.KNOCK: [0, 2],
	InjuryType.MUSCLE_STRAIN: [2, 4],
	InjuryType.MUSCLE_TEAR: [4, 8],
	InjuryType.LIGAMENT_DAMAGE: [12, 26],
	InjuryType.BONE_FRACTURE: [16, 32],
	InjuryType.CONCUSSION: [1, 3],
	InjuryType.FATIGUE: [0, 1],
	InjuryType.ILLNESS: [1, 2],
}

# =============================================================================
# NATIONALITIES (Major footballing nations)
# =============================================================================
const NATIONALITIES = [
	"England", "Spain", "Germany", "Italy", "France", "Portugal", "Netherlands",
	"Belgium", "Brazil", "Argentina", "Uruguay", "Colombia", "Chile", "Mexico",
	"USA", "Japan", "South Korea", "Australia", "Croatia", "Serbia", "Poland",
	"Turkey", "Russia", "Ukraine", "Czech Republic", "Switzerland", "Austria",
	"Denmark", "Sweden", "Norway", "Scotland", "Wales", "Northern Ireland",
	"Republic of Ireland", "Greece", "Romania", "Hungary", "Slovakia", "Slovenia",
]

# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

static func get_position_group(position: Position) -> String:
	for group_name, positions in POSITION_GROUPS:
		if position in positions:
			return group_name
	return "Unknown"

static func get_roles_for_position(position: Position) -> Array[Role]:
	var roles = []
	for role, pos in ROLE_POSITION:
		if pos == position:
			roles.append(role)
	return roles

static func get_role_display_name(role: Role) -> String:
	return ROLE_NAMES.get(role, "Unknown Role")

static func get_position_display_name(position: Position) -> String:
	return POSITION_FULL.get(position, "Unknown")

static func get_position_short(position: Position) -> String:
	return POSITION_SHORT.get(position, "??")