extends Node
class_name GameState

# Singleton
static var instance: GameState = null

# =============================================================================
# GAME STATE VARIABLES
# =============================================================================

# Career info
var current_save_id: String = ""
var manager_name: String = ""
var manager_nationality: String = ""
var manager_date_of_birth: Dictionary = {}
var current_club_id: String = ""
var current_season: int = 2024

# Date & Time
var current_date: Dictionary = {"year": 2024, "month": 7, "day": 1}  # Season start
var game_speed: int = 1  # 1=normal, 2=fast, 3=very fast
var is_paused: bool = false

# Season state
var season_stage: String = "PRE_SEASON"  # PRE_SEASON, IN_SEASON, POST_SEASON, OFF_SEASON
var transfer_window_open: bool = true
var transfer_window_closes: Dictionary = {}

# UI State
var current_screen: String = "overview"
var selected_player_id: String = ""
var selected_team_id: String = ""
var selected_competition_id: String = ""

# Match state
var current_match: Dictionary = {}
var match_simulation_speed: int = 1

# Inbox/News
var inbox_messages: Array[Dictionary] = []
var unread_message_count: int = 0

# Notifications
var notifications: Array[Dictionary] = []

# Settings
var settings: Dictionary = {
	"auto_save": true,
	"auto_save_interval_days": 7,
	"match_simulation_detail": "full",  # full, summary, instant
	"show_attribute_values": true,
	"confirm_transfers": true,
	"difficulty": "normal",  # easy, normal, hard
	"realism": "standard",   # arcade, standard, realistic
}

# =============================================================================
# SIGNALS
# =============================================================================
signal date_changed(new_date: Dictionary)
signal season_changed(new_season: int)
signal club_changed(new_club_id: String)
signal screen_changed(new_screen: String)
signal match_started(match_data: Dictionary)
signal match_finished(result: Dictionary)
signal message_received(message: Dictionary)
signal notification_added(notification: Dictionary)
signal game_saved(slot_name: String)
signal game_loaded(slot_name: String)

# =============================================================================
# INITIALIZATION
# =============================================================================

func _ready():
	instance = self
	_load_settings()

func _load_settings():
	var file = FileAccess.open("user://settings.json", FileAccess.READ)
	if file:
		var parsed = JSON.parse_string(file.get_as_text())
		if parsed.error == OK:
			settings = parsed.value
		file.close()

func save_settings():
	var file = FileAccess.open("user://settings.json", FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(settings, "\t"))
		file.close()

# =============================================================================
# DATE & TIME MANAGEMENT
# =============================================================================

static func get_current_date() -> Dictionary:
	if instance:
		return instance.current_date.duplicate()
	return {"year": 2024, "month": 7, "day": 1}

func advance_date(days: int = 1):
	for _ in range(days):
		_advance_one_day()
	_check_season_transitions()
	emit_signal("date_changed", current_date)

func _advance_one_day():
	current_date.day += 1

	var days_in_month = _get_days_in_month(current_date.month, current_date.year)
	if current_date.day > days_in_month:
		current_date.day = 1
		current_date.month += 1
		if current_date.month > 12:
			current_date.month = 1
			current_date.year += 1

func _get_days_in_month(month: int, year: int) -> int:
	match month:
		1, 3, 5, 7, 8, 10, 12: return 31
		4, 6, 9, 11: return 30
		2:
			if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
				return 29
			return 28
		_: return 30

func _check_season_transitions():
	# Season starts July 1
	if current_date.month == 7 and current_date.day == 1:
		_start_new_season()

	# Transfer windows
	if current_date.month == 9 and current_date.day == 1:
		transfer_window_open = false  # Summer window closes
	elif current_date.month == 1 and current_date.day == 1:
		transfer_window_open = true   # Winter window opens
	elif current_date.month == 2 and current_date.day == 1:
		transfer_window_open = false  # Winter window closes
	elif current_date.month == 6 and current_date.day == 1:
		transfer_window_open = true   # Summer window opens

func _start_new_season():
	current_season += 1
	season_stage = "PRE_SEASON"
	emit_signal("season_changed", current_season)

	# Reset season stats for all players
	Database.instance._reset_season_stats()

	# Generate youth intake
	Simulation.instance.generate_youth_intake()

	# Process contracts expiring
	Simulation.instance.process_contract_expiries()

	# Update team reputations
	Simulation.instance.update_reputations()

# =============================================================================
# CAREER MANAGEMENT
# =============================================================================

func new_career(club_id: String, manager_first: String, manager_last: String, nationality: String, dob: Dictionary):
	current_save_id = "career_%d" % Time.get_unix_time_from_system()
	manager_name = "%s %s" % [manager_first, manager_last]
	manager_nationality = nationality
	manager_date_of_birth = dob
	current_club_id = club_id
	current_season = 2024
	current_date = {"year": 2024, "month": 7, "day": 1}
	season_stage = "PRE_SEASON"
	transfer_window_open = true
	inbox_messages.clear()
	notifications.clear()
	unread_message_count = 0

	# Set manager as staff at club
	var club = Database.instance.get_team(club_id)
	if club:
		# Create manager staff entry
		var manager_staff = StaffData.new()
		manager_staff.id = "manager_%s" % current_save_id
		manager_staff.first_name = manager_first
		manager_staff.last_name = manager_last
		manager_staff.nationality = nationality
		manager_staff.date_of_birth = dob
		manager_staff.role = GameEnums.StaffRole.MANAGER
		manager_staff.club_id = club_id
		manager_staff.contract_type = GameEnums.ContractType.PERMANENT
		manager_staff.contract_start_date = current_date.duplicate()
		manager_staff.contract_end_date = _add_years(current_date, 3)
		manager_staff.wage = 20000
		Database.instance.staff[manager_staff.id] = manager_staff
		club.staff_ids.append(manager_staff.id)

	emit_signal("club_changed", club_id)
	add_notification("Welcome to %s!" % club.name, "info")

func _add_years(date: Dictionary, years: int) -> Dictionary:
	return {"year": date.year + years, "month": date.month, "day": date.day}

func resign():
	# Handle manager resignation/sacking
	add_notification("You have left %s" % Database.instance.get_team(current_club_id).name, "warning")
	current_club_id = ""

func retire():
	# End career
	add_notification("You have retired from management", "info")

# =============================================================================
# SCREEN NAVIGATION
# =============================================================================

func navigate_to(screen: String):
	if current_screen != screen:
		current_screen = screen
		emit_signal("screen_changed", screen)

func get_current_screen() -> String:
	return current_screen

# =============================================================================
# SELECTION MANAGEMENT
# =============================================================================

func select_player(player_id: String):
	selected_player_id = player_id

func select_team(team_id: String):
	selected_team_id = team_id

func select_competition(comp_id: String):
	selected_competition_id = comp_id

func get_selected_player() -> PlayerData:
	if selected_player_id != "":
		return Database.instance.get_player(selected_player_id)
	return null

func get_selected_team() -> TeamData:
	if selected_team_id != "":
		return Database.instance.get_team(selected_team_id)
	return null

func get_current_club() -> TeamData:
	if current_club_id != "":
		return Database.instance.get_team(current_club_id)
	return null

# =============================================================================
# MATCH MANAGEMENT
# =============================================================================

func start_match(match_data: Dictionary):
	current_match = match_data
	emit_signal("match_started", match_data)

func finish_match(result: Dictionary):
	current_match = {}
	emit_signal("match_finished", result)

func get_current_match() -> Dictionary:
	return current_match

# =============================================================================
# INBOX / MESSAGES
# =============================================================================

func add_message(message: Dictionary):
	var msg = message.duplicate()
	msg.id = "msg_%d_%d" % [Time.get_unix_time_from_system(), randi_range(1000, 9999)]
	msg.timestamp = current_date.duplicate()
	msg.read = false
	inbox_messages.insert(0, msg)
	unread_message_count += 1
	emit_signal("message_received", msg)

func mark_message_read(message_id: String):
	for msg in inbox_messages:
		if msg.id == message_id and not msg.read:
			msg.read = true
			unread_message_count = max(0, unread_message_count - 1)
			break

func mark_all_read():
	for msg in inbox_messages:
		msg.read = true
	unread_message_count = 0

func delete_message(message_id: String):
	for i in range(inbox_messages.size()):
		if inbox_messages[i].id == message_id:
			if not inbox_messages[i].read:
				unread_message_count = max(0, unread_message_count - 1)
			inbox_messages.remove_at(i)
			break

func get_unread_count() -> int:
	return unread_message_count

func get_messages(filter_type: String = "") -> Array[Dictionary]:
	if filter_type == "":
		return inbox_messages
	var filtered = []
	for msg in inbox_messages:
		if msg.type == filter_type:
			filtered.append(msg)
	return filtered

# =============================================================================
# NOTIFICATIONS
# =============================================================================

func add_notification(text: String, type: String = "info", duration: float = 5.0):
	var notif = {
		"id": "notif_%d_%d" % [Time.get_unix_time_from_system(), randi_range(1000, 9999)],
		"text": text,
		"type": type,  # info, warning, error, success
		"duration": duration,
		"timestamp": Time.get_unix_time_from_system(),
	}
	notifications.append(notif)
	emit_signal("notification_added", notif)

func remove_notification(notification_id: String):
	for i in range(notifications.size()):
		if notifications[i].id == notification_id:
			notifications.remove_at(i)
			break

func clear_notifications():
	notifications.clear()

# =============================================================================
# SETTINGS
# =============================================================================

func get_setting(key: String, default = null):
	return settings.get(key, default)

func set_setting(key: String, value):
	settings[key] = value
	save_settings()

# =============================================================================
# SERIALIZATION
# =============================================================================

func to_dict() -> Dictionary:
	return {
		"current_save_id": current_save_id,
		"manager_name": manager_name,
		"manager_nationality": manager_nationality,
		"manager_date_of_birth": manager_date_of_birth,
		"current_club_id": current_club_id,
		"current_season": current_season,
		"current_date": current_date,
		"game_speed": game_speed,
		"is_paused": is_paused,
		"season_stage": season_stage,
		"transfer_window_open": transfer_window_open,
		"transfer_window_closes": transfer_window_closes,
		"current_screen": current_screen,
		"selected_player_id": selected_player_id,
		"selected_team_id": selected_team_id,
		"selected_competition_id": selected_competition_id,
		"inbox_messages": inbox_messages,
		"unread_message_count": unread_message_count,
		"settings": settings,
	}

func from_dict(data: Dictionary):
	current_save_id = data.get("current_save_id", "")
	manager_name = data.get("manager_name", "")
	manager_nationality = data.get("manager_nationality", "")
	manager_date_of_birth = data.get("manager_date_of_birth", {})
	current_club_id = data.get("current_club_id", "")
	current_season = data.get("current_season", 2024)
	current_date = data.get("current_date", {"year": 2024, "month": 7, "day": 1})
	game_speed = data.get("game_speed", 1)
	is_paused = data.get("is_paused", false)
	season_stage = data.get("season_stage", "PRE_SEASON")
	transfer_window_open = data.get("transfer_window_open", true)
	transfer_window_closes = data.get("transfer_window_closes", {})
	current_screen = data.get("current_screen", "overview")
	selected_player_id = data.get("selected_player_id", "")
	selected_team_id = data.get("selected_team_id", "")
	selected_competition_id = data.get("selected_competition_id", "")
	inbox_messages = data.get("inbox_messages", [])
	unread_message_count = data.get("unread_message_count", 0)
	settings = data.get("settings", settings)

	# Re-emit signals to update UI
	emit_signal("date_changed", current_date)
	emit_signal("season_changed", current_season)
	if current_club_id != "":
		emit_signal("club_changed", current_club_id)
	emit_signal("screen_changed", current_screen)