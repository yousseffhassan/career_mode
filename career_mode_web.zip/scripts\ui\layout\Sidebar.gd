extends VBoxContainer
class_name Sidebar

# =============================================================================
# SIGNALS
# =============================================================================
signal screen_selected(screen: int)

# =============================================================================
# UI REFERENCES
# =============================================================================

@onready var club_button: Button = $ClubButton
@onready var overview_button: Button = $OverviewButton
@onready var squad_button: Button = $SquadButton
@onready var tactics_button: Button = $TacticsButton
@onready var training_button: Button = $TrainingButton
@onready var transfers_button: Button = $TransfersButton
@onready var staff_button: Button = $StaffButton
@onready var youth_button: Button = $YouthAcademyButton
@onready var finances_button: Button = $FinancesButton
@onready var calendar_button: Button = $CalendarButton
@onready var inbox_button: Button = $InboxButton
@onready var settings_button: Button = $SettingsButton

# =============================================================================
# BUTTON MAP
# =============================================================================

var screen_buttons: Dictionary = {}

# =============================================================================
# INITIALIZATION
# =============================================================================

func _ready():
	_setup_buttons()
	_connect_signals()
	_update_club_info()

func _setup_buttons():
	screen_buttons = {
		0: club_button,       # Club/Overview
		1: overview_button,   # Overview
		2: squad_button,      # Squad
		3: tactics_button,    # Tactics
		4: training_button,   # Training
		5: transfers_button,  # Transfers
		6: staff_button,      # Staff
		7: youth_button,      # Youth Academy
		8: finances_button,   # Finances
		9: calendar_button,   # Calendar
		10: inbox_button,     # Inbox
		11: settings_button,  # Settings
	}

	# Set up button group for exclusive selection
	for btn in screen_buttons.values():
		btn.button_group = "sidebar_navigation"

func _connect_signals():
	for screen_id, btn in screen_buttons:
		btn.pressed.connect(_on_button_pressed.bind(screen_id))

	# Listen for GameState signals
	if GameState.instance:
		GameState.instance.club_changed.connect(_update_club_info)

func _on_button_pressed(screen_id: int):
	emit_signal("screen_selected", screen_id)

func set_selected_screen(screen_enum: int):
	var btn = screen_buttons.get(screen_enum)
	if btn:
		btn.button_pressed = true

func _update_club_info():
	var club = GameState.instance.get_current_club()
	if club:
		club_button.text = club.short_name
		# Could add club crest here

# =============================================================================
# UTILITY
# =============================================================================

func set_button_disabled(screen_id: int, disabled: bool):
	var btn = screen_buttons.get(screen_id)
	if btn:
		btn.disabled = disabled

func set_button_badge(screen_id: int, count: int):
	var btn = screen_buttons.get(screen_id)
	if btn and btn.has_method("set_badge"):
		btn.set_badge(count)