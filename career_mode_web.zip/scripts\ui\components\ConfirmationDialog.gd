extends AcceptDialog
class_name ConfirmationDialog

# =============================================================================
# UI REFERENCES
# =============================================================================

@onready var message_label: Label = $VBoxContainer/Message
@onready var cancel_button: Button = $VBoxContainer/ButtonRow/CancelButton
@onready var confirm_button: Button = $VBoxContainer/ButtonRow/ConfirmButton

# =============================================================================
# STATE
# =============================================================================

var on_confirm_callback: Callable = null
var on_cancel_callback: Callable = null

# =============================================================================
# SETUP
# =============================================================================

func setup(title: String, message: String, on_confirm: Callable, on_cancel: Callable = null):
	dialog_title = title
	message_label.text = message
	on_confirm_callback = on_confirm
	on_cancel_callback = on_cancel

	confirm_button.pressed.connect(_on_confirm)
	cancel_button.pressed.connect(_on_cancel)

func _on_confirm():
	if on_confirm_callback:
		on_confirm_callback.call()
	queue_free()

func _on_cancel():
	if on_cancel_callback:
		on_cancel_callback.call()
	queue_free()